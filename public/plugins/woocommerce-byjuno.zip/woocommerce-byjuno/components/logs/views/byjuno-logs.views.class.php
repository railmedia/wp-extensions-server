<?php
class ByjunoOrderLogsViews {

    function interface($data, $pagination) {
        $byjunosettings = byjuno_settings();
        ob_start();
?>
        <h1>Order logs</h1>
        <?php echo $this->filters(); ?>
        <div class="byjuno-error-logs-container">
            <div id="byjuno-error-logs-row-header" class="byjuno-error-logs-row">
                <div id="byjuno-error-logs-header-row-header" class="byjuno-error-logs-header-row">
                    <div class="byjuno-error-logs-header name">
                        <?php _e( 'Name', 'woocommerce-byjuno-error-logs' ); ?>
                    </div>
                    <div class="byjuno-error-logs-header return_code step">
                        <?php _e( 'Step', 'woocommerce-byjuno-error-logs' ); ?>
                    </div>
                    <div class="byjuno-error-logs-header date">
                        <?php _e( 'Date', 'woocommerce-byjuno-error-logs' ); ?>
                    </div>
                    <div class="byjuno-error-logs-header actions">
                        <?php _e( 'Actions', 'woocommerce-byjuno-error-logs' ); ?>
                    </div>
                </div>
            </div>
            <?php
                foreach($data as $row) {

                    if( $row->order_id ) {
                        $order = new WC_Order( $row->order_id );
                        $firstname = $order->get_billing_first_name();
                        $lastname  = $order->get_billing_last_name();
                        $name = $firstname . ' ' . $lastname;
                        $gender = get_post_meta( $row->order_id, '_billing_user-gender', true );
                        $address = $order->get_billing_address_1() . ' ' . $order->get_billing_address_2();
                        $house_no = get_post_meta( $row->order_id, '_billing_user-houseno', true );
                        $postcode = $order->get_billing_postcode();
                        $city = $order->get_billing_city();
                        $birthdate = get_post_meta( $row->order_id, '_billing_user-birthdate', true );
                        $email = $order->get_billing_email();
                        $order_total = $order->get_total();
                    } else {
                        $firstname = $row->first_name;
                        $lastname  = $row->last_name;
                        $name = $firstname . ' ' . $lastname;
                        $gender = $row->gender;
                        $address = $row->address;
                        $house_no = $row->house_no;
                        $postcode = $row->postcode;
                        $city = $row->city;
                        $birthdate = $row->birthdate;
                        $email = $row->email;
                        $order_total = $row->order_total;
                    }
            ?>
            <div id="byjuno-error-logs-row-<?php echo $row->id; ?>" class="byjuno-error-logs-row">
                <div id="byjuno-error-logs-header-row-<?php echo $row->id; ?>" class="byjuno-error-logs-header-row" data-id="<?php echo $row->id; ?>">
                    <div class="byjuno-error-logs-header name">
                        <?php echo $name; ?>
                    </div>
                    <div class="byjuno-error-logs-header return_code step">
                        <?php echo $row->step; ?>
                    </div>
                    <div class="byjuno-error-logs-header date">
                        <?php echo date( 'd.m.Y / H:i:s', strtotime( $row->added ) ); ?>
                    </div>
                    <div class="byjuno-error-logs-header actions">
                        <a class="open" data-id="<?php echo $row->id; ?>" href="#"><span class="dashicons dashicons-visibility"></span></a>
                        <a class="delete" data-id="<?php echo $row->id; ?>" href="#"><span class="dashicons dashicons-trash"></span></a>
                    </div>
                </div>
                <div id="byjuno-error-logs-details-container-<?php echo $row->id; ?>" class="byjuno-error-logs-details-container" data-id="<?php echo $row->id; ?>">
                    <div class="byjuno-error-logs-fields">
                        <?php if( $row->code ) { ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label code">
                                <?php _e( 'Code', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value code">
                                <?php echo $row->code; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                        <?php if( $gender ) { ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label gender">
                                <?php _e( 'Gender', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value gender">
                                <?php echo $gender == 1 ? __( 'Male', 'woocommerce-byjuno' ) : __( 'Female', 'woocommerce-byjuno' ); ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label first_name">
                                <?php _e( 'First Name', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value first_name">
                                <?php echo $firstname; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label last_name">
                                <?php _e( 'Last Name', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value last_name">
                                <?php echo $lastname; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label address">
                                <?php _e( 'Address', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value address">
                                <?php echo $address; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php if( $house_no ) { ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label house_no">
                                <?php _e( 'House Number', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value house_no">
                                <?php echo $house_no; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label postcode">
                                <?php _e( 'Postcode', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value postcode">
                                <?php echo $postcode; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label city">
                                <?php _e( 'City', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value city">
                                <?php echo $city; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php if( $birthdate ) { ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label birthdate">
                                <?php _e( 'Birthdate', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value birthdate">
                                <?php echo $birthdate; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label email">
                                <?php _e( 'E-mail', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value email">
                                <?php echo $email; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label order_total">
                                <?php _e( 'Order Total', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value order_total">
                                <?php echo $order_total; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label date_time">
                                <?php _e( 'Date/Time', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value date_time">
                                <?php echo date( 'd.m.Y', strtotime( $row->added ) ); ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php if( $row->order_id ) { ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label date_time">
                                <?php _e( 'Order', 'woocommerce-byjuno-error-logs' ); ?>
                            </div>
                            <div class="byjuno-error-logs-value date_time">
                                <a href="<?php printf( '%spost.php?post=%s&action=edit', admin_url(), $row->order_id ); ?>" target="_blank"><?php _e( 'Click to open', 'woocommerce-byjuno' ); ?></a>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                    </div>
                    <div id="byjuno-error-logs-contact-<?php echo $row->id; ?>" class="byjuno-error-logs-contact">
                        <div class="byjuno-error-logs-contact-row">
                            <label for="log-request-<?php echo $row->id; ?>"><?php _e( 'Request', 'woocommerce-byjuno' ); ?></label>
                            <textarea class="log-request-response" id="log-request-<?php echo $row->id; ?>"><?php echo $row->request; ?></textarea>
                        </div>
                        <div class="byjuno-error-logs-contact-row subject">
                            <label for="log-response-<?php echo $row->id; ?>"><?php _e( 'Response', 'woocommerce-byjuno' ); ?></label>
                            <textarea class="log-request-response" id="log-response-<?php echo $row->id; ?>"><?php echo $row->response; ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if($pagination) { ?>
            <div class="byjuno-error-logs-pagination">
                <?php echo $pagination; ?>
            </div>
            <?php } ?>
        </div>
        <div class="clear"></div>
<?php
        return ob_get_clean();
    }

    function filters() {
        global $wpdb;
        ob_start();
?>
        <div class="byjuno-error-logs-filter-panel">
            <div for="bel-filter-by"><h3><?php _e( 'Filters', 'woocommerce-byjuno-error-logs' ); ?></h3></div>
            <div class="bel-filter-row">
                <ul class="bel-filter-by-list">
                <?php
                    $filters = array(
                        'added'     => __( 'Date', 'woocommerce-byjuno-error-logs' ),
                        'step'     => __( 'Step', 'woocommerce-byjuno-error-logs' ),
                        'order_id' => __( 'Order ID', 'woocommerce-byjuno-logs' )
                    );

                    $hasfilters = 0;
                    foreach($filters as $id => $label) {
                        $filtersactive = array();
                ?>
                <li>
                    <input <?php echo (isset($_GET[$id]) && $_GET[$id]) ? 'checked="checked"' : ''; ?> id="bel-filter-by-<?php echo $id; ?>" class="byjuno-error-logs-filter-by" type="checkbox" value="<?php echo $id; ?>" />
                    <label for="bel-filter-by-<?php echo $id; ?>"><?php echo $label; ?></label>
                    <?php
                        if( isset( $_GET[$id] ) && $_GET[$id] ) {
                            $filtersactive[$id] = $_GET[$id];
                            echo $this->filters_secondary_active($filtersactive);
                            $hasfilters = 1;
                        }
                    ?>
                </li>
                <?php } ?>
                </ul>
            </div>
            <div class="bel-filter-row">
                <h4>Relationship</h4>
                <ul class="bel-filter-by-list">
                    <li>
                        <input type="radio" <?php echo (isset($_GET['rel']) && $_GET['rel'] == 'or') ? 'checked="checked"' : ''; ?> class="bel-subfilter bel-subfilter-rel" name="bel-subfilter-rel" id="bel-filter-relationship-or" value="or" data-type="rel" />
                        <label for="bel-filter-relationship-or">OR</label>
                    </li>
                    <li>
                        <input type="radio" <?php echo ((isset($_GET['rel']) && $_GET['rel'] == 'and') || !isset($_GET['rel'])) ? 'checked="checked"' : ''; ?> class="bel-subfilter bel-subfilter-rel" name="bel-subfilter-rel" id="bel-filter-relationship-and" value="and" data-type="rel" />
                        <label for="bel-filter-relationship-and">AND</label>
                    </li>
                </ul>
            </div>
            <div class="bel-filter-row">
                <h4>Results per page</h4>
                <ul class="bel-filter-by-list">
                    <li>
                        <select class="bel-subfilter bel-subfilter-perpage" name="bel-subfilter-perpage" id="bel-fiter-perpage">
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </li>
                </ul>
            </div>
            <div class="bel-filter-row">
                <?php //echo $_SERVER['REQUEST_URI']; ?>
                <a href="<?php echo $_SERVER['REQUEST_URI']; ?>&perpag=<?php echo isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20; ?>" id="bel-filter-apply" class="button button-primary" class="bel-filter-apply">
                    <?php _e( 'Apply Filters', 'woocommerce-byjuno-error-logs' ); ?>
                </a>
                <?php if($hasfilters) { ?>
                <a href="admin.php?page=byjuno_logs&subp=order_logs" id="bel-filter-remove" class="button button-primary" class="bel-filter-remove">
                    <?php _e( 'Remove Filters', 'woocommerce-byjuno-error-logs' ); ?>
                </a>
                <?php } ?>
            </div>
        </div>
<?php
        return ob_get_clean();
    }

    function filters_secondary($data) {
        $filterdata = $data['data'];
        $type = $data['type'];
        ob_start();
?>
        <ul name="bel-filter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" id="bel-filter-<?php echo $type; ?>" class="bel-filter-secondary">
            <?php
                foreach($filterdata as $key => $filterdata) {
                    if( $type != 'added' ) {
            ?>
            <li>
                <input type="checkbox" id="bel-<?php echo $type; ?>-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" value="<?php echo $filterdata->$type; ?>" />
                <label for="bel-<?php echo $type; ?>-<?php echo $key; ?>"><?php echo $filterdata->$type; ?></label>
            </li>
            <?php } else { ?>
            <li>
                <input type="checkbox" id="bel-<?php echo $type; ?>-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" value="<?php echo $filterdata; ?>" />
                <label for="bel-<?php echo $type; ?>-<?php echo $key; ?>"><?php echo $filterdata; ?></label>
            </li>
            <?php } } ?>
        </ul>
<?php
        return ob_get_clean();
    }

    function filters_secondary_active( $filtersactive ) {


        if( ! $filtersactive) return;

        global $wpdb;

        ob_start();
        $the_type = '';
        foreach($filtersactive as $type => $values) {
            $type = $type;
            $the_type = $type;
            $values = explode( '_', $values );
            $filterdata = $wpdb->get_results("SELECT DISTINCT {$type} FROM {$wpdb->prefix}woocommerce_byjuno_logs");
            // if( $type == 'added' ) {
            //
            // }
        }

        if( $the_type == 'added' ) {
            $the_dates = array();
            foreach( $filterdata as $filterdata ) {
                $the_date = date('d.m.Y', strtotime( $filterdata->$type ));
                if( ! in_array( $the_date, $the_dates ) ) {
                    $the_dates[] = $the_date;
                }
            }
            if( $the_dates ) {
        ?>
        <ul name="bel-filter-added" data-type="added" id="bel-filter-added" class="bel-filter-secondary">
            <?php
                foreach($the_dates as $key => $date) {
                    $exp_added = isset( $_GET['added'] ) && $_GET['added'] ? explode('_', $_GET['added']) : null;
            ?>
            <li>
                <input type="checkbox" <?php echo $exp_added && in_array($date, $exp_added) ? 'checked="checked"' : ''; ?> id="bel-added-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-added" data-type="added" value="<?php echo $date; ?>" />
                <label for="bel-added-<?php echo $key; ?>"><?php echo $date; ?></label>
            </li>
            <?php } ?>
        </ul>
        <?php
            }
        } else {

            if( $filterdata ) {
?>
        <ul name="bel-filter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" id="bel-filter-<?php echo $type; ?>" class="bel-filter-secondary">
            <?php
                foreach($filterdata as $key => $filterdata) {
            ?>
            <li>
                <input type="checkbox" <?php echo in_array($filterdata->$type, $values) ? 'checked="checked"' : ''; ?> id="bel-<?php echo $type; ?>-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" value="<?php echo $filterdata->$type; ?>" />
                <label for="bel-<?php echo $type; ?>-<?php echo $key; ?>"><?php echo $filterdata->$type; ?></label>
            </li>
            <?php } ?>
        </ul>
<?php
            }
        }
        return ob_get_clean();
    }

}
?>
