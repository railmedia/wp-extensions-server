<?php
class ByjunoOrderLogs {

    var $views;

    function __construct() {

        $this->views = new ByjunoOrderLogsViews;

        add_action( 'admin_enqueue_scripts', array($this, 'scripts') );
        add_action( 'wp', array( $this, 'delete_old_logs' ) );
        add_action( 'admin_init', array( $this, 'delete_old_logs' ) );
        add_action( 'woocommerce_byjuno_logs', array( $this, 'interface' ) );
        add_action( 'init', array($this, 'db') );

        $ajaxcalls = array(
            'order_logs_delete_entry',
            'order_logs_secondary_filter'
        );

        foreach($ajaxcalls as $ajaxcall) {
            add_action( 'wp_ajax_'.$ajaxcall, array($this, $ajaxcall) );
            add_action( 'wp_ajax_nopriv_'.$ajaxcall, array($this, $ajaxcall) );
        }

    }

    function scripts() {

        wp_register_style('byjuno-logs', BYJUNOURL . 'components/logs/assets/css/logs.css');

        wp_register_script('byjuno-logs-blockui', BYJUNOURL . 'components/logs/assets/js/blockui.jquery.js', array('jquery'), '', true);
        wp_register_script('byjuno-logs', BYJUNOURL . 'components/logs/assets/js/logs.js', array('jquery'), '', true);
        wp_localize_script('byjuno-logs', 'byjunoerrors', array(
            'ajaxurl'       => admin_url('admin-ajax.php'),
            'currentpage'   => isset($_GET['page']) && $_GET['page'] ? $_GET['page'] . '&subp=order_logs' : 1
        ));

    }

	function interface() {

        if( isset( $_GET['subp'] ) && $_GET['subp'] == 'order_logs' ) {

            wp_enqueue_style( 'dashicons' );
            wp_enqueue_style( 'byjuno-logs' );

            wp_enqueue_script( 'byjuno-logs-blockui' );
            wp_enqueue_script( 'byjuno-logs' );

            global $wpdb;

            $query = $this->build_filters_query();
            $data = $wpdb->get_results($query);

            echo $this->views->interface( $data, $this->build_pagination() );

        }

	}

    function build_pagination() {

        if( ! isset( $_GET['rel'] ) ) {

            global $wpdb;
            
            $pag    = isset($_GET['pag']) && $_GET['pag'] ? $_GET['pag'] : 1;
            $perpag = isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20;
            $max    = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_byjuno_logs");
            $pages  = floor($max / $perpag);

            $result = '<ul>';

            $counterleft = 1;

            for($i = 1; $i <= $pages; $i++) {

                $current = (isset($_GET['pag']) && $_GET['pag'] == $i) || (!isset($_GET['pag']) && $i == 1) ? 'current-page-bel' : '';
                $href = (isset($_GET['pag']) && $_GET['pag'] == $i) || (!isset($_GET['pag']) && $i == 1) ? '' : 'admin.php?page=byjuno_logs&subp=order_logs&pag=' . $i;

                $result .= '<li class="' . $current . '" style="display:inline;"><a class="'.$current.'" href="' . $href . '">' . $i . '</a></li>';

                $counterleft++;

            }

            $result .= '</ul>';

            return $result;

        }

    }

    function build_filters_query() {

        global $wpdb;

        $query = ' WHERE ';
        $where = '';

        $rel = isset( $_GET['rel'] ) && $_GET['rel'] ? $_GET['rel'] : 'AND';

        $args = array('step', 'order_id');
        $count_args = 0;

        foreach($args as $arg) {

            if( isset( $_GET[$arg] ) && $_GET[$arg] ) {

                $thevalues = '(';
                $values = explode('_', $_GET[$arg]);
                foreach($values as $value) {
                    $thevalues .= "'" . $value . "', ";
                }
                if( strpos( $_GET[$arg], 's1_s2' ) !== false ) {
                    $thevalues .= "'s1_s2', ";
                }
                $thevalues = rtrim($thevalues, ', ');
                $thevalues .= ')';
                $query .= $arg . " IN " . $thevalues . " " . strtoupper($rel)." ";

                $count_args++;
            }

        }

        if( isset( $_GET['added'] ) && $_GET['added'] ) {
            $exp_added = explode('.', $_GET['added']);
            $query_date = $exp_added[2] . '-' . $exp_added[1] . '-' . $exp_added[0];
            $added_keyword = ! $count_args ? 'WHERE' : 'AND';
            $where .= " " . $added_keyword . " added LIKE '%" . $query_date . "%' ";
        }

        $query = rtrim($query, strtoupper($rel).' ');
        $query = rtrim($query, ' WHERE ');

        $pag    = isset($_GET['pag']) && $_GET['pag'] ? $_GET['pag'] : 1;
        $perpag = isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20;
        $max    = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_byjuno_logs {$query}");
        $pages  = $max / $perpag;
        $offset = ($pag == 1 || !$pag) ? 0 : $pag * $perpag;

        if( ! isset( $_GET['rel'] ) ) {
            $query = "SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_logs {$query} {$where} ORDER BY added DESC LIMIT {$offset}, {$perpag}";
        } else {
            $query = "SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_logs {$query} {$where} ORDER BY added DESC";
        }

        return $query;

    }

    function delete_old_logs() {

        global $wpdb;

        $table_exists = $wpdb->query( "SHOW TABLES LIKE '{$wpdb->prefix}woocommerce_byjuno_logs'" );
        if( $table_exists ) {
            $twoMonthsAgo = date('Y-m-d', strtotime('-2 months'));
            $oldLogs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_logs WHERE added < '{$twoMonthsAgo}'");
            if( $oldLogs ) {
                foreach( $oldLogs as $oldLog ) {
                    $wpdb->delete(
                        $wpdb->prefix . 'woocommerce_byjuno_logs',
                        array( 'id' => $oldLog->id )
                    );
                }
            }
        }

    }

    function order_logs_delete_entry() {

        global $wpdb;

        $id = $_POST['id'];
        $wpdb->delete(
            $wpdb->prefix . 'woocommerce_byjuno_logs',
            array( 'id' => $id )
        );
        echo $id;
        wp_die();

    }

    function order_logs_secondary_filter() {

        global $wpdb;

        $data = $_POST['data'];
        if( $data == 'added' ) {
            $filterdata = array();
            $getDates = $wpdb->get_results("SELECT DISTINCT {$data} FROM {$wpdb->prefix}woocommerce_byjuno_logs ORDER BY {$data} ASC");
            if( $getDates ) {
                foreach( $getDates as $date ) {
                    $thedate = date( 'd.m.Y', strtotime( $date->added ) );
                    if( ! in_array( $thedate, $filterdata ) ) {
                        $filterdata[] = $thedate;
                    }
                }
            }
        } else {
            $filterdata = $wpdb->get_results("SELECT DISTINCT {$data} FROM {$wpdb->prefix}woocommerce_byjuno_logs ORDER BY {$data} ASC");
        }

        if( $filterdata ) {
            echo $this->views->filters_secondary(array('data' => $filterdata, 'type' => $data));
        }

        wp_die();

    }

    function db() {

		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}woocommerce_byjuno_logs (
		  id mediumint(11) NOT NULL AUTO_INCREMENT,
          order_id mediumint(11),
          order_date varchar(250) NOT NULL,
          step varchar(250) NULL,
          request text NULL,
          response text NULL,
		  code int(11) NOT NULL,
          credit_rating varchar(200) NULL,
          credit_rating_level varchar(200) NULL,
          request_no varchar(200) NULL,
		  first_name varchar(250) NULL,
          last_name varchar(250) NULL,
          gender    varchar(250) NULL,
          birthdate varchar(100) NULL,
          address   text NULL,
          house_no  varchar(100) NULL,
          postcode  varchar(100) NULL,
          city      varchar(100) NULL,
          phone     varchar(100) NULL,
          email     varchar(150) NULL,
          order_total varchar(100) NULL,
          added datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		  PRIMARY KEY  (id)
		) $charset_collate;";

		$wpdb->query($sql);

	}

}

new ByjunoOrderLogs;

class ByjunoLogs {

    function __construct() {

        add_action( 'init', array($this, 'db') );
        add_action( 'byjuno_after_request', array( $this, 'logs' ) );

    }

    function byjuno_settings() {

		return get_option( 'woocommerce_byjuno_settings' );

	}

    function logs( $data, $byjunosettings ) {

		$byjunosettings = $byjunosettings ? $byjunosettings : $this->byjuno_settings();

		if( $byjunosettings['logs_enable'] == 1 ) {

            global $wpdb;

			$logstype 	= isset( $byjunosettings['logs_type'] ) && $byjunosettings['logs_type'] ? $byjunosettings['logs_type'] : 'database';
			$checkmode 	= $byjunosettings['mode'];
			$logdata 	= $data['data'];

			if($data) {

                $request = $data['data']['request_data'];
                $response = $data['data']['return_data'];
                $code = (array)$response->Customer->RequestStatus;
                $code = intval($code[0]);

                $wpdb->insert(
                    $wpdb->prefix . 'woocommerce_byjuno_logs',
                    array(
                        'order_id'      => $data['order_id'] ? $data['order_id'] : 0,
                        'order_date'    => date('d.m.Y'),
                        'step'    => $data['step'],
                        'request' => $data['data']['request'],
                        'response'=> $data['data']['response'],
                        'code'    => $code,
                        'credit_rating' => $response->Customer->CreditRating,
                        'credit_rating_level' => $response->Customer->CreditRatingLevel,
                        'request_no' => $data['data']['request_no'],
                        'first_name'    => $request['billing_firstname'],
                        'last_name'     => $request['billing_lastname'],
                        'gender'        => $request['gender'],
                        'birthdate'     => $request['birthday'],
                        'address'       => $request['billing_address'],
                        'house_no'      => $request['billing_houseno'],
                        'postcode'      => $request['billing_postcode'],
                        'city'          => $request['billing_city'],
                        'phone'         => $request['phone'],
                        'email'         => $request['email'],
                        'order_total'   => $request['ordertotal'],
                    )
                );

			}

		}

	}

}
?>
