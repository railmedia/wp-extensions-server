<?php
class ByjunoLogs {

    function __construct() {

        add_action( 'byjuno_after_request', array( $this, 'logs' ) );

    }

    function byjuno_settings() {

		return get_option( 'woocommerce_byjuno_settings' );

	}

    function logs( $data, $byjunosettings ) {

		$byjunosettings = $byjunosettings ? $byjunosettings : $this->byjuno_settings();

		if( $byjunosettings['logs_enable'] == 1 ) {

			$logstype 	= $byjunosettings['logs_type'] ? $byjunosettings['logs_type'] : 'file';
			$checkmode 	= $byjunosettings['mode'];
			$logdata 	= $data['data'];

			if($logdata) {

				switch($logstype) {

					case 'file':

						$uploaddir = ABSPATH . 'wp-content/plugins/woocommerce-byjuno/logs/'.$checkmode.'/'.date('Y').'/'.date('m').'/'.date('d');

						if(!is_dir($uploaddir)) {
							mkdir($uploaddir, 0775, true);
						}

						$logfilename = date('Y_m_d_H_i_s').'_'.$data['byjunocustomerref'].'_'.$data['step'];
						$logfile = $uploaddir.'/'.$logfilename.'.log';

						if(file_exists($logfile)) {
							$logfilename = $logfilename.'_'.rand(101, 302);
							$logfile = $uploaddir.'/'.$logfilename.'.log';
						}

						$logfile = fopen($logfile, 'w') or die('Unable to open file!');

						fwrite($logfile, "Request\n\n");
						fwrite($logfile, $logdata['request']);

						fwrite($logfile, "\n\nResponse\n\n");
						fwrite($logfile, $logdata['response']);

						fclose($logfile);

                        return $logfilename;

					break;

					case 'email':

						$recipient = $byjunosettings['logs_email'];
						if(!$recipient) {
							$recipient = $byjunosettings['technical_contact'];
							if(!$recipient) {
								$recipient = get_bloginfo('admin_email');
							}
						}

						if($recipient) {
							wp_mail($recipient, $data['step'].' request', $logdata['request']);
							wp_mail($recipient, $data['step'].' response', $logdata['response']);
						}

					break;

				}

			}

		}

	}

}
?>
