jQuery(document).ready(function() {

    if( jQuery('.log-request-response').length ) {
		jQuery('.log-request-response').on('click', function(){
			jQuery(this).toggleClass('active');
			//jQuery(this).select();
		});
	}

    jQuery('.byjuno-error-logs-header-row').on('click', function(e){

        var id = jQuery(this).attr('data-id');

        jQuery('.log-request-response').removeClass('active');

        jQuery('.byjuno-error-logs-details-container').hide();

        jQuery('#byjuno-error-logs-details-container-'+id).toggle();

    });

    jQuery('.byjuno-error-logs-header.actions a.delete').on('click', function(e) {

        if(confirm('Are you sure?') == true) {

            var id = jQuery(this).attr('data-id');

            jQuery.ajax({
                type: "POST",
                url: byjunoerrors.ajaxurl,
                data: ({action : 'order_logs_delete_entry', id: id}),
                success: function(data) {
                    jQuery( '#byjuno-error-logs-row-' + id ).remove();
                },
                error: function(xhr, status, error) {
                }
            });

        }

    });

    var url = {};

    jQuery('.bel-subfilter').each(function(i, v) {

        var type = jQuery(this).attr('data-type');

        if( ! url[type] || url[type] == undefined ) {
            url[type] = [];
        }

        if( jQuery(this).is(':checked') ) {
            url[type].push( jQuery(this).val() );
        }

    });

    jQuery('.byjuno-error-logs-filter-by').on('change', function() {

        var select   = jQuery(this);
            selectid = select.attr('data-id'),
            val      = select.val(),
            panel    = jQuery('.byjuno-error-logs-filter-panel');

        if( select.is(':checked') ) {

            panel.block({message: '', css : { borderRadius: '10px' }});

            jQuery.ajax({
                type: "POST",
                url: byjunoerrors.ajaxurl,
                data: ({action : 'order_logs_secondary_filter', data : val}),
                success: function(data) {
                    //jQuery('#byjuno-error-logs-row-'+id).remove();
                    if(jQuery('#bel-filter-'+val).length <= 0) {
                        select.parent('li').append(data);
                    }
                    panel.unblock();
                },
                error: function(xhr, status, error) {
                    panel.unblock();
                }
            });
        } else {
            jQuery('#bel-filter-'+val).remove();
            delete url[val];
            build_filters_href(url);
        }

    });


    jQuery('body').on('click', '.bel-subfilter', function(){

        var type = jQuery(this).attr('data-type'),
            hasfilter = 0;

            url[type] = [];

        jQuery('.bel-subfilter-' + type).each(function(i, v) {

            if( jQuery(this).is(':checked') ) {
                hasfilter = 1;
                url[type].push(jQuery(v).val());
            }

        });

        if( ! hasfilter ) {
            jQuery('#bel-filter-by-'+type).prop('checked', false);
            delete url[type];
        } else {
            jQuery('#bel-filter-by-'+type).prop('checked', true);
        }

        build_filters_href(url);

    });

});

function build_filters_href(url) {

    var theurl = 'admin.php?page=' + byjunoerrors.currentpage,
        button = jQuery('#bel-filter-apply');

    jQuery.each(url, function(by, values) {

        if( by != 'undefined' ) {

            theurl += '&' + by + '=';

            var len = values.length;
            jQuery.each(values, function(i, v){
                theurl += v;
                if (i === (len - 1)) {

                } else {
                    theurl += '_';
                }
            });

        }

    });

    theurl += '&perpag=' + jQuery('#bel-fiter-perpage').val();

    button.attr('href', theurl);

}
