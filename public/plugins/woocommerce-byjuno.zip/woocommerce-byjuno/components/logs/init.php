<?php
$files = array(
    'views/byjuno-logs.views.class.php',
    'controllers/byjuno-logs.class.php'
);
foreach( $files as $file ) {
    require_once( $file );
}
?>
