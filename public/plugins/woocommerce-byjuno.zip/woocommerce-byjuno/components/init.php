<?php
$components = array(
    'settings/init.php',
    'error-logs/init.php',
    'logs/init.php',
    //'localization/init.php'
);
foreach($components as $component) {
    include( $component );
}
?>
