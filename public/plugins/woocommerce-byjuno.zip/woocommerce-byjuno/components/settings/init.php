<?php
$files = array(
    'controllers/settings.class.php'
);
foreach( $files as $file ) {
    require_once( $file );
}
?>
