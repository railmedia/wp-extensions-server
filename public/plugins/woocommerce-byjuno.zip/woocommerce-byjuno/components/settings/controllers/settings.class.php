<?php
class ByjunoSettings {

    function __construct() {

        add_action( 'admin_menu', array($this, 'menu'), 99 );

    }

    function menu() {
        add_submenu_page(
            'byjuno_settings',
            __( 'Logs', 'woocommerce-byjuno' ),
            __( 'Logs', 'woocommerce-byjuno' ),
            'manage_options',
            'byjuno_logs',
            array( $this, 'interface' )
        );
    }

    function interface() {
		wp_enqueue_style( 'byjuno-admin-css' );
	?>
    	<div class="wrap">
    		<h1 class="wp-heading-inline"><?php _e( 'WooCommerce Byjuno Logs', 'woocommerce-byjuno' ); ?></h1>
    		<div class="woocommerce-byjuno-logs-nav <?php echo ! isset( $_GET['subp'] ) ? 'full-screen' : 'normal-screen'; ?>">
    			<a href="admin.php?page=byjuno_logs&subp=order_logs" style="font-size: 20px;" class="button <?php echo isset( $_GET['subp'] ) && $_GET['subp'] != 'order_logs' ? 'button-primary' : ''; ?>">
    				<?php _e( 'Order Logs', 'woocommerce-byjuno' ); ?>
    			</a>
    			<a href="admin.php?page=byjuno_logs&subp=error_logs" style="font-size: 20px;" class="button <?php echo isset( $_GET['subp'] ) && $_GET['subp'] != 'error_logs' ? 'button-primary' : ''; ?>">
    				<?php _e( 'Error Logs', 'woocommerce-byjuno' ); ?>
    			</a>
    		</div>
    		<?php do_action( 'woocommerce_byjuno_logs' ); ?>
    	</div>
	<?php
	}

}

new ByjunoSettings;
?>
