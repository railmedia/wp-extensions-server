<?php
$files = array(
    'views/byjuno-error-logs.views.class.php',
    'controllers/byjuno-error-logs.class.php'
);
foreach( $files as $file ) {
    require_once( $file );
}
?>
