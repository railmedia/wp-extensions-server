<?php
class ByjunoErrorLogsViews {

    function interface($data, $pagination) {
        $byjunosettings = byjuno_settings();
        ob_start();
?>
        <h1>Error logs</h1>
        <?php echo $this->filters(); ?>
        <div class="byjuno-error-logs-container">
            <div id="byjuno-error-logs-row-header" class="byjuno-error-logs-row">
                <div id="byjuno-error-logs-header-row-header" class="byjuno-error-logs-header-row">
                    <div class="byjuno-error-logs-header name">
                        <?php _e( 'Name', BYJUNODOMAIN ); ?>
                    </div>
                    <div class="byjuno-error-logs-header return_code">
                        <?php _e( 'Code', BYJUNODOMAIN ); ?>
                    </div>
                    <div class="byjuno-error-logs-header credit_rating">
                        <?php _e( 'Credit Rating / Level', BYJUNODOMAIN ); ?>
                    </div>
                    <div class="byjuno-error-logs-header date">
                        <?php _e( 'Date', BYJUNODOMAIN ); ?>
                    </div>
                    <div class="byjuno-error-logs-header actions">
                        <?php _e( 'Actions', BYJUNODOMAIN ); ?>
                    </div>
                </div>
            </div>
            <?php foreach($data as $row) { ?>
            <div id="byjuno-error-logs-row-<?php echo $row->id; ?>" class="byjuno-error-logs-row">
                <div id="byjuno-error-logs-header-row-<?php echo $row->id; ?>" class="byjuno-error-logs-header-row" data-id="<?php echo $row->id; ?>">
                    <div class="byjuno-error-logs-header name">
                        <?php echo $row->first_name . ' ' . $row->last_name; ?>
                    </div>
                    <div class="byjuno-error-logs-header return_code">
                        <?php echo $row->code; ?>
                    </div>
                    <div class="byjuno-error-logs-header credit_rating">
                        <?php
                            echo $row->credit_rating;
                            if($row->credit_rating_level) {
                                echo ' / ' . $row->credit_rating_level;
                            }
                        ?>
                    </div>
                    <div class="byjuno-error-logs-header date">
                        <?php echo date('d.m.Y', strtotime($row->added)); ?>
                    </div>
                    <div class="byjuno-error-logs-header actions">
                        <a class="open" data-id="<?php echo $row->id; ?>" href="#"><span class="dashicons dashicons-visibility"></span></a>
                        <a class="delete" data-id="<?php echo $row->id; ?>" href="#"><span class="dashicons dashicons-trash"></span></a>
                    </div>
                </div>
                <div id="byjuno-error-logs-details-container-<?php echo $row->id; ?>" class="byjuno-error-logs-details-container" data-id="<?php echo $row->id; ?>">
                    <div class="byjuno-error-logs-fields">
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label code">
                                <?php _e( 'Code', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value code">
                                <?php echo $row->code; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label gender">
                                <?php _e( 'Gender', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value gender">
                                <?php echo $row->gender == 1 ? 'Männlich' : 'Weiblich'; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label first_name">
                                <?php _e( 'First Name', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value first_name">
                                <?php echo $row->first_name; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label last_name">
                                <?php _e( 'Last Name', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value last_name">
                                <?php echo $row->last_name; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label address">
                                <?php _e( 'Address', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value address">
                                <?php echo $row->address; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label house_no">
                                <?php _e( 'House Number', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value house_no">
                                <?php echo $row->house_no; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label postcode">
                                <?php _e( 'Postcode', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value postcode">
                                <?php echo $row->postcode; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label city">
                                <?php _e( 'City', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value city">
                                <?php echo $row->city; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label birthdate">
                                <?php _e( 'Birthdate', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value birthdate">
                                <?php echo $row->birthdate; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label email">
                                <?php _e( 'E-mail', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value email">
                                <?php echo $row->email; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label order_total">
                                <?php _e( 'Order Total', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value order_total">
                                <?php echo $row->order_total; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <hr/>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label date_time">
                                <?php _e( 'Date/Time', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value date_time">
                                <?php echo $row->added; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label request_no">
                                <?php _e( 'Request #', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value request_no">
                                <?php echo $row->request_no; ?>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php
                            $log = ABSPATH . 'wp-content/plugins/woocommerce-byjuno/logs/' . $byjunosettings['mode'] . '/' . $row->log_dir . $row->log_name . '.log';
                            $download = site_url() . '/wp-content/plugins/woocommerce-byjuno/logs/' . $byjunosettings['mode'] . '/' . $row->log_dir . $row->log_name . '.log';
                            if( is_file( $log ) ) {
                        ?>
                        <div class="byjuno-error-logs-details-row">
                            <div class="byjuno-error-logs-label log">
                                <?php _e( 'Log File', BYJUNODOMAIN ); ?>
                            </div>
                            <div class="byjuno-error-logs-value log">
                                <a href="<?php echo $download; ?>" target="_blank">Download</a>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <?php } ?>
                    </div>
                    <div id="byjuno-error-logs-contact-<?php echo $row->id; ?>" class="byjuno-error-logs-contact">
                        <div class="byjuno-error-logs-contact-row email">
                            <label for="contact-error-user-email-<?php echo $row->id; ?>"><?php _e( 'Recipient', BYJUNODOMAIN ); ?></label>
                            <input id="contact-error-user-email-<?php echo $row->id; ?>" class="contact-error-user-email" value="<?php echo $row->email; ?>" data-id="<?php echo $row->id; ?>" />
                        </div>
                        <div class="byjuno-error-logs-contact-row subject">
                            <label for="contact-error-user-subject-<?php echo $row->id; ?>"><?php _e( 'Subject', BYJUNODOMAIN ); ?></label>
                            <input id="contact-error-user-subject-<?php echo $row->id; ?>" class="contact-error-user-subject" value="<?php _e( 'Byjuno rectification review', BYJUNODOMAIN ); ?>" data-id="<?php echo $row->id; ?>" />
                        </div>
                        <div class="byjuno-error-logs-contact-row messagebox">
                            <label for="contact-error-user-message-<?php echo $row->id; ?>"><?php _e( 'Message', BYJUNODOMAIN ); ?></label>
                            <textarea id="contact-error-user-message-<?php echo $row->id; ?>"><?php _e( 'Dear', BYJUNODOMAIN ); ?> <?php echo $row->first_name. ' '.$row->last_name; ?>,</textarea>
                        </div>
                        <div class="byjuno-error-logs-contact-row send">
                            <button class="button button-primary bel-send-email" data-id="<?php echo $row->id; ?>"><?php _e( 'Send', BYJUNODOMAIN ); ?></button>
                        </div>
                        <?php if($row->date_contacted) { ?>
                        <p><i><?php _e( 'Date contacted for the last time:', BYJUNODOMAIN ); ?> <?php echo $row->date_contacted; ?></i></p>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if($pagination) { ?>
            <div class="byjuno-error-logs-pagination">
                <?php echo $pagination; ?>
            </div>
            <?php } ?>
        </div>
        <div class="clear"></div>
<?php
        return ob_get_clean();
    }

    function filters() {
        global $wpdb;
        ob_start();
?>
        <div class="byjuno-error-logs-filter-panel">
            <div for="bel-filter-by"><h3><?php _e( 'Filters', BYJUNODOMAIN ); ?></h3></div>
            <div class="bel-filter-row">
                <ul class="bel-filter-by-list">
                <?php
                    $filters = array(
                        'date'       => __( 'Date', BYJUNODOMAIN ),
                        'code'       => __( 'Code', BYJUNODOMAIN ),
                        'gender'     => __( 'Gender', BYJUNODOMAIN ),
                        'first_name' => __( 'First Name', BYJUNODOMAIN ),
                        'last_name'  => __( 'Last Name', BYJUNODOMAIN ),
                        'address'    => __( 'Address', BYJUNODOMAIN ),
                        'house_no'   => __( 'House Number', BYJUNODOMAIN ),
                        'postcode'   => __( 'Postcode', BYJUNODOMAIN ),
                        'city'       => __( 'City', BYJUNODOMAIN ),
                        'email'      => __( 'E-mail', BYJUNODOMAIN ),
                        'phone'      => __( 'Phone', BYJUNODOMAIN ),
                        'birthdate'  => __( 'Birthdate', BYJUNODOMAIN )
                    );

                    $hasfilters = 0;
                    foreach($filters as $id => $label) {
                        $filtersactive = array();
                ?>
                <li>
                    <input <?php echo (isset($_GET[$id]) && $_GET[$id]) ? 'checked="checked"' : ''; ?> id="bel-filter-by-<?php echo $id; ?>" class="byjuno-error-logs-filter-by" type="checkbox" value="<?php echo $id; ?>" />
                    <label for="bel-filter-by-<?php echo $id; ?>"><?php echo $label; ?></label>
                    <?php
                        if(isset($_GET[$id]) && $_GET[$id]) {
                            $filtersactive[$id] = $_GET[$id];
                            echo $this->filters_secondary_active($filtersactive);
                            $hasfilters = 1;
                        }
                    ?>
                </li>
                <?php } ?>
                </ul>
            </div>
            <div class="bel-filter-row">
                <h4>Relationship</h4>
                <ul class="bel-filter-by-list">
                    <li>
                        <input type="radio" <?php echo (isset($_GET['rel']) && $_GET['rel'] == 'or') ? 'checked="checked"' : ''; ?> class="bel-subfilter bel-subfilter-rel" name="bel-subfilter-rel" id="bel-filter-relationship-or" value="or" data-type="rel" />
                        <label for="bel-filter-relationship-or">OR</label>
                    </li>
                    <li>
                        <input type="radio" <?php echo ((isset($_GET['rel']) && $_GET['rel'] == 'and') || !isset($_GET['rel'])) ? 'checked="checked"' : ''; ?> class="bel-subfilter bel-subfilter-rel" name="bel-subfilter-rel" id="bel-filter-relationship-and" value="and" data-type="rel" />
                        <label for="bel-filter-relationship-and">AND</label>
                    </li>
                </ul>
            </div>
            <div class="bel-filter-row">
                <h4>Results per page</h4>
                <ul class="bel-filter-by-list">
                    <li>
                        <select class="bel-subfilter bel-subfilter-perpage" name="bel-subfilter-perpage" id="bel-fiter-perpage">
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </li>
                </ul>
            </div>
            <div class="bel-filter-row">
                <a href="<?php echo $_SERVER['REQUEST_URI']; ?>&pag=<?php echo isset($_GET['pag']) && $_GET['pag'] ? $_GET['pag'] : 1; ?>&perpag=<?php echo isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20; ?>" id="bel-filter-apply" class="button button-primary" class="bel-filter-apply">
                    <?php _e( 'Apply Filters', BYJUNODOMAIN ); ?>
                </a>
                <?php if($hasfilters) { ?>
                <a href="admin.php?page=byjuno_error_logs" id="bel-filter-remove" class="button button-primary" class="bel-filter-remove">
                    <?php _e( 'Remove Filters', BYJUNODOMAIN ); ?>
                </a>
                <?php } ?>
            </div>
        </div>
<?php
        return ob_get_clean();
    }

    function filters_secondary($data) {
        $filterdata = $data['data'];
        $type = $data['type'];
        ob_start();
?>
        <ul name="bel-filter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" id="bel-filter-<?php echo $type; ?>" class="bel-filter-secondary">
            <?php foreach($filterdata as $key => $filterdata) { ?>
            <li>
                <input type="checkbox" id="bel-<?php echo $type; ?>-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" value="<?php echo $filterdata->$type; ?>" />
                <label for="bel-<?php echo $type; ?>-<?php echo $key; ?>"><?php echo $filterdata->$type; ?></label>
            </li>
            <?php } ?>
        </ul>
<?php
        return ob_get_clean();
    }

    function filters_secondary_active($filtersactive) {

        if( ! $filtersactive) return;

        global $wpdb;

        ob_start();
        foreach($filtersactive as $type => $values) {
            $type = $type;
            $values = explode( '_', $values );
            $filterdata = $wpdb->get_results("SELECT DISTINCT {$type} FROM {$wpdb->prefix}woocommerce_byjuno_error_logs");
        }
        if($filterdata) {
?>
        <ul name="bel-filter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" id="bel-filter-<?php echo $type; ?>" class="bel-filter-secondary">
            <?php foreach($filterdata as $key => $filterdata) { ?>
            <li>
                <input type="checkbox" <?php echo in_array($filterdata->$type, $values) ? 'checked="checked"' : ''; ?> id="bel-<?php echo $type; ?>-<?php echo $key; ?>" class="bel-subfilter bel-subfilter-<?php echo $type; ?>" data-type="<?php echo $type; ?>" value="<?php echo $filterdata->$type; ?>" />
                <label for="bel-<?php echo $type; ?>-<?php echo $key; ?>"><?php echo $filterdata->$type; ?></label>
            </li>
            <?php } ?>
        </ul>
<?php
        }
        return ob_get_clean();
    }

}
?>
