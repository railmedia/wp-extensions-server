<?php
class ByjunoErrorLogs {

    var $views;

    function __construct() {

        $this->views = new ByjunoErrorLogsViews;

        add_action( 'admin_enqueue_scripts', array($this, 'scripts') );
        add_action( 'wp', array( $this, 'delete_old_error_logs' ) );
        add_action( 'admin_init', array( $this, 'delete_old_error_logs' ) );
        add_action( 'woocommerce_byjuno_logs', array( $this, 'interface' ) );
        add_action( 'init', array($this, 'db') );

        $ajaxcalls = array(
            'order_error_logs_delete_entry',
            'order_error_logs_secondary_filter',
            'order_error_logs_send_email'
        );

        foreach($ajaxcalls as $ajaxcall) {
            add_action( 'wp_ajax_'.$ajaxcall, array($this, $ajaxcall) );
            add_action( 'wp_ajax_nopriv_'.$ajaxcall, array($this, $ajaxcall) );
        }

    }

    function scripts() {

        wp_register_style('byjuno-error-logs', BYJUNOURL . 'components/error-logs/assets/css/error-logs.css');

        wp_register_script('byjuno-error-logs-blockui', BYJUNOURL . 'components/error-logs/assets/js/blockui.jquery.js', array('jquery'), '', true);
        wp_register_script('byjuno-error-logs', BYJUNOURL . 'components/error-logs/assets/js/error-logs.js', array('jquery'), '', true);
        wp_localize_script('byjuno-error-logs', 'byjunoerrors', array(
            'ajaxurl'       => admin_url('admin-ajax.php'),
            'currentpage'   => isset($_GET['page']) && $_GET['page'] ? $_GET['page'] . '&subp=error_logs' : 1
        ));

    }

    function menu() {
		add_submenu_page( 'woocommerce', __( 'Byjuno Error Logs', 'woocommerce-byjuno-error-logs' ), __( 'Byjuno Error Logs', 'woocommerce-byjuno-error-logs' ), 'manage_options', 'byjuno_error_logs', array( $this, 'interface' ) );
	}

	function interface() {

        if( isset( $_GET['subp'] ) && $_GET['subp'] == 'error_logs' ) {

            wp_enqueue_style( 'dashicons' );
            wp_enqueue_style( 'byjuno-error-logs' );

            wp_enqueue_script( 'byjuno-error-logs-blockui' );
            wp_enqueue_script( 'byjuno-error-logs' );

            global $wpdb;

            $query = $this->build_filters_query();
            $data = $wpdb->get_results($query);

            echo $this->views->interface( $data, $this->build_pagination() );

        }

	}

    function build_pagination() {

        if(!isset($_GET['rel'])) {

            global $wpdb;
            $pag    = isset($_GET['pag']) && $_GET['pag'] ? $_GET['pag'] : 1;
            $perpag = isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20;
            $max    = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_byjuno_error_logs");
            $pages  = floor($max / $perpag);

            $result = '<ul>';

            $counterleft = 1;

            for($i = 1; $i <= $pages; $i++) {

                $current = (isset($_GET['pag']) && $_GET['pag'] == $i) || (!isset($_GET['pag']) && $i == 1) ? 'current-page-bel' : '';
                $href = (isset($_GET['pag']) && $_GET['pag'] == $i) || (!isset($_GET['pag']) && $i == 1) ? '' : 'admin.php?page=byjuno_logs&subp=error_logs&pag=' . $i;

                $result .= '<li class="' . $current . '" style="display:inline;"><a class="'.$current.'" href="' . $href . '">' . $i . '</a></li>';

                $counterright++;

            }

            $result .= '</ul>';

            return $result;

        }

    }

    function build_filters_query() {

        global $wpdb;

        $query = ' WHERE ';

        $rel = isset($_GET['rel']) && $_GET['rel'] ? $_GET['rel'] : 'AND';

        $args = array('code', 'credit_rating', 'credit_rating_level', 'first_name', 'last_name', 'gender', 'birthdate', 'address', 'house_no', 'postcode', 'city', 'phone', 'email', 'order_total', 'date');

        foreach($args as $arg) {

            if( isset($_GET[$arg]) && $_GET[$arg] ) {

                $thevalues = '(';
                $values = explode('_', $_GET[$arg]);
                foreach($values as $value) {
                    $thevalues .= "'" . $value . "', ";
                }
                $thevalues = rtrim($thevalues, ', ');
                $thevalues .= ')';
                $query .= $arg . " IN " . $thevalues . " " . strtoupper($rel)." ";
            }

        }

        $query = rtrim($query, strtoupper($rel).' ');
        $query = rtrim($query, ' WHERE ');

        $pag    = isset($_GET['pag']) && $_GET['pag'] ? $_GET['pag'] : 1;
        $perpag = isset($_GET['perpag']) && $_GET['perpag'] ? $_GET['perpag'] : 20;
        $max    = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_byjuno_error_logs {$query}");
        $pages  = $max / $perpag;
        $offset = ($pag == 1 || !$pag) ? 0 : $pag * $perpag;

        if(!isset($_GET['rel'])) {
            $query = "SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_error_logs {$query} ORDER BY added DESC LIMIT {$offset}, {$perpag}";
        } else {
            $query = "SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_error_logs {$query} ORDER BY added DESC";
        }

        return $query;

    }

    function delete_old_error_logs() {
        global $wpdb;

        $table_exists = $wpdb->query( "SHOW TABLES LIKE '{$wpdb->prefix}woocommerce_byjuno_error_logs'" );
        if( $table_exists ) {
            $oneMonthAgo = date('Y-m-d', strtotime('-1 month'));
            $oldLogs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_byjuno_error_logs WHERE added < '{$oneMonthAgo}'");
            if( $oldLogs ) {
                foreach( $oldLogs as $oldLog ) {
                    $wpdb->delete(
                        $wpdb->prefix . 'woocommerce_byjuno_error_logs',
                        array( 'id' => $oldLog->id )
                    );
                }
            }
        }
    }

	function db() {

		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}woocommerce_byjuno_error_logs (
		  id mediumint(11) NOT NULL AUTO_INCREMENT,
          log_id int(11) NULL,
		  code int(11) NOT NULL,
          credit_rating varchar(200) NULL,
          credit_rating_level varchar(200) NULL,
          request_no varchar(200) NULL,
          log_name varchar(200) NULL,
          log_dir text NULL,
		  first_name varchar(250) NULL,
          last_name varchar(250) NULL,
          gender    varchar(250) NULL,
          birthdate varchar(100) NULL,
          address   text NULL,
          house_no  varchar(100) NULL,
          postcode  varchar(100) NULL,
          city      varchar(100) NULL,
          phone     varchar(100) NULL,
          email     varchar(150) NULL,
          order_total varchar(100) NULL,
          date      varchar(100) NULL,
          added datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		  PRIMARY KEY  (id)
		) $charset_collate;";

		$wpdb->query($sql);

	}

    function order_error_logs_delete_entry() {

        global $wpdb;

        $id = $_POST['id'];
        $wpdb->delete(
            $wpdb->prefix . 'woocommerce_byjuno_error_logs',
            array( 'id' => $id )
        );
        echo $id;
        wp_die();

    }

    function order_error_logs_send_email() {
        global $wpdb;
        $id = $_POST['id'];
        $recipient = $_POST['recipient'];
        $message = $_POST['message'];
        $subject = $_POST['subject'];

        $headers = "From: " . get_bloginfo('admin_email') . "\r\n";
        $headers .= "Reply-To: ". get_bloginfo('admin_email') . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        wp_mail($recipient, $subject, nl2br($message), $headers);
        $wpdb->update(
            $wpdb->prefix.'woocommerce_byjuno_error_logs',
            array('date_contacted' => date('d.m.Y')),
            array('id' => $id)
        );
        wp_die();
    }

    function order_error_logs_secondary_filter() {

        global $wpdb;

        $data = $_POST['data'];
        $filterdata = $wpdb->get_results("SELECT DISTINCT {$data} FROM {$wpdb->prefix}woocommerce_byjuno_error_logs ORDER BY {$data} ASC");
        if($filterdata) {
            echo $this->views->filters_secondary(array('data' => $filterdata, 'type' => $data));
        }

        wp_die();

    }

}

new ByjunoErrorLogs;

class ByjunoErrorLogsLog {

    public function log($data = null) {

        if(!$data) return;

        global $wpdb;

        $request = $data['data']['request_data'];
        $response = $data['data']['return_data'];
        $code = (array) $response->Customer->RequestStatus;
        $code = intval($code[0]);

        $logdata['request_no'] = isset( $data['request_no'] ) && $data['request_no'] ? $data['request_no'] : '';
        $logdata['log_name'] = isset( $logname ) && $logname ? $logname : '';
        $logdata['log_dir'] = date('Y') . '/' . date('m') . '/' . date('d') . '/';

        $wpdb->insert(
            $wpdb->prefix.'woocommerce_byjuno_error_logs',
            array(
                'code'          => $code,
                'credit_rating' => $response->Customer->CreditRating,
                'credit_rating_level' => $response->Customer->CreditRatingLevel,
                'request_no'    => $data['data']['request_no'],
                'log_name'      => isset( $data['log_name'] ) && $data['log_name'] ? $data['log_name'] : '',
                'log_dir'       => isset( $data['log_dir'] ) && $data['log_dir'] ? $data['log_dir'] : '',
                'first_name'    => $request['billing_firstname'],
                'last_name'     => $request['billing_lastname'],
                'gender'        => $request['gender'],
                'birthdate'     => $request['birthday'],
                'address'       => $request['billing_address'],
                'house_no'      => $request['billing_houseno'],
                'postcode'      => $request['billing_postcode'],
                'city'          => $request['billing_city'],
                'phone'         => $request['phone'],
                'email'         => $request['email'],
                'order_total'   => $request['ordertotal'],
                'date'          => date('d.m.Y')
            )
        );

    }

}

?>
