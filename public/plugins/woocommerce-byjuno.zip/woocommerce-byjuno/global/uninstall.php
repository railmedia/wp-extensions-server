<?php
/**
*
* Remove all the plugin's options on uninstall
*
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.cloudweb.ch
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

function byjuno_uninstall() {

    $options = array(
        'woocommerce_byjuno_settings'
    );

    foreach( $options as $option ) {
        delete_option( $option );
    }

    global $wpdb;
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}woocommerce_byjuno_error_logs" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}woocommerce_byjuno_logs" );

}
?>
