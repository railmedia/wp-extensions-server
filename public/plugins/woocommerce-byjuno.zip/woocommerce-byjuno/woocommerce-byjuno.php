<?php
/*
* Plugin Name: WooCommerce Byjuno
* Plugin URI: https://www.cloudweb.ch
* Description: Uses Byjuno database for WooCommerce checkout and allows or denies payments through invoices.
* Version: 5.1.1
* Author: cloudWEB
* Author URI: https://www.cloudweb.ch
* WC requires at least: 4.0.0
* WC tested up to: 7.6.1
* License: GPL2
*/

/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	define( 'BYJUNOPATH', plugin_dir_path( __FILE__ ) );
	define( 'BYJUNOURL', plugin_dir_url( __FILE__ ) );
	define( 'BYJUNOBASE', plugin_basename( __FILE__ ) );
	define( 'BYJUNODOMAIN', 'woocommerce-byjuno' );

	require_once( BYJUNOPATH . '/frontend/init.php' );

	if(is_admin()) {
		require_once( BYJUNOPATH . '/admin/init.php' );
	}

	require_once( BYJUNOPATH . '/components/init.php' );

	function byjuno_load_plugin_textdomain() {
	    load_plugin_textdomain( 'woocommerce-byjuno', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}

	add_action( 'plugins_loaded', 'byjuno_load_plugin_textdomain' );

}

require_once( __DIR__ . '/global/updates.php' );
require_once( __DIR__ . '/global/uninstall.php' );

function byjuno_deactivate_uninstall() {
    byjuno_uninstall();
    flush_rewrite_rules();
}
register_uninstall_hook( __FILE__, 'byjuno_deactivate_uninstall' );

?>
