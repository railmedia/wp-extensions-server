<?php
class ByjunoAdmin {

	var $views;

	private $error_logs;

	function __construct() {

		$this->views = new ByjunoAdminViews;

		if( class_exists( 'ByjunoErrorLogs' ) ) {
			$this->error_logs = new ByjunoErrorLogs;
		}

		add_action( 'admin_enqueue_scripts', array($this, 'scripts'), 200 );
		add_action( 'admin_menu', array($this, 'menu'), 99 );
		add_action( 'woocommerce_admin_order_data_after_order_details', array($this, 'byjuno_fields_display'), 10, 1 );
		add_action( 'woocommerce_order_refunded', array( $this, 'byjuno_on_order_refund' ), 10, 2 );
		add_action( 'init', array( $this, 'delete_old_log_files' ) );
		add_filter( 'plugin_action_links_'  . BYJUNOBASE, array($this, 'byjuno_settings_link_plugins_screen') );

	}

	function delete_old_log_files( $dir = null ) {

		$dir = $dir ? $dir : BYJUNOPATH . 'logs';

		$files = glob($dir . '/*');
		foreach ($files as $file) {
			is_dir( $file ) ? $this->delete_old_log_files($file) : unlink($file);
		}
		if( is_dir($dir) ) {
			rmdir($dir);
		}

		return;

	}

	function scripts() {

		wp_register_style('byjuno-admin-css', BYJUNOURL . 'admin/assets/css/byjuno-admin.css');

		if(
			( isset($_GET['page']) && $_GET['page'] == 'wc-settings' && isset($_GET['tab']) && $_GET['tab'] == 'checkout' && isset($_GET['section']) && $_GET['section'] == 'byjuno' )
		) {
			wp_enqueue_style('byjuno-admin-css');
			wp_enqueue_style('byjuno-fancybox-css', BYJUNOURL . 'admin/assets/scripts/fancybox/jquery.fancybox.3.5.7.css' );
			wp_enqueue_script('byjuno-fancybox-js', BYJUNOURL . 'admin/assets/scripts/fancybox/jquery.fancybox.3.5.7.min.js', array('jquery'), '', true);
			wp_enqueue_script('byjuno-admin-js', BYJUNOURL . 'admin/assets/js/byjuno-admin.js', array('jquery'), '', true);
			wp_localize_script('byjuno-admin-js', 'byjunoadminjs', array(
				'ajaxurl' 		=> admin_url('admin-ajax.php'),
				'siteurl' 		=> site_url()
			));
		}

		if ( isset($_GET['post']) && isset($_GET['action']) && $_GET['action'] == 'edit' ) {

			wp_enqueue_style( 'byjuno-admin-css' );
			wp_enqueue_script( 'byjuno-admin-order-js', BYJUNOURL . 'admin/assets/js/byjuno-admin-order.js', array('jquery'), '', true );
			wp_localize_script( 'byjuno-admin-order-js', 'byjunoao', array(
				'langs' => array(
					'showMore' => __( 'Show More', 'woocommerce-byjuno-admin' ),
					'showLess' => __( 'Show Less', 'woocommerce-byjuno-admin' )
				)
			) );
			
		}

	}

	function menu() {

		add_submenu_page(
			'woocommerce',
	        __( 'Byjuno Settings', 'woocommerce-byjuno' ),
	        __( 'Byjuno Settings', 'woocommerce-byjuno' ),
	        'manage_options',
	        'byjuno_settings',
	        array( $this, 'interface' )
	    );

	}

	function interface() {
		wp_enqueue_style( 'byjuno-admin-css' );
	?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php _e( 'WooCommerce Byjuno Settings', 'woocommerce-byjuno' ); ?></h1>
			<div class="byjuno-settings-buttons">
				<div class="byjuno-setting">
					<a href="<?php echo admin_url() . 'admin.php?page=byjuno_logs&subp=order_logs'; ?>">
						<img style="max-width: 100px;" src="<?php echo esc_url( BYJUNOURL ); ?>admin/assets/img/logs.svg" alt="<?php _e( 'Byjuno logs', 'woocommerce-byjuno' ); ?>" />
					</a>
					<a class="button button-primary" href="<?php echo admin_url() . 'admin.php?page=byjuno_logs&subp=order_logs'; ?>">
						<?php _e( 'Logs', 'woocommerce-byjuno' ); ?>
					</a>
				</div>
				<div class="byjuno-setting">
					<a href="<?php echo admin_url() . 'admin.php?page=wc-settings&tab=checkout&section=byjuno'; ?>">
						<img style="max-width: 100px;" src="<?php echo esc_url( BYJUNOURL ); ?>admin/assets/img/settings.svg" alt="<?php _e( 'Byjuno Settings', 'woocommerce-byjuno' ); ?>" />
					</a>
					<a class="button button-primary" href="<?php echo admin_url() . 'admin.php?page=wc-settings&tab=checkout&section=byjuno'; ?>">
						<?php _e( 'Payment Gateway Settings', 'woocommerce-byjuno' ); ?>
					</a>
				</div>
				<?php do_action( 'woocommerce_byjuno_admin_settings_buttons' ); ?>
            </div>
			<?php do_action( 'woocommerce_byjuno_admin_dashboard' ); ?>
		</div>
	<?php
	}

	function byjuno_on_order_refund( $order_id, $refund_id ) {

		$byjuno_settings = get_option( 'woocommerce_byjuno_settings' );

		$paymentmethod = get_post_meta( $order_id, '_payment_method', true );
		$s5_sent	   = get_post_meta( $order_id, 'sent_s5', true );

		if( $s5_sent ) return;

		if( $paymentmethod == 'byjuno' && $byjuno_settings['enable_on_order_refunds'] == '1' ) {

			if( class_exists( 'ByjunoRequests' ) ) {
				$requests = new ByjunoRequests;
				$requests->s5_refund( $order_id, $refund_id );
			}

		}

	}

	function byjuno_fields_display($order) {

		$orderid = $order->get_id();
		$paymentmethod = get_post_meta( $orderid, '_payment_method', true );

		if( $paymentmethod == 'byjuno' ) {
			$fields = array(
				'user_gender' 				=> array(
					'label' => __( 'User Gender', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_user-gender', true )
				),
				'birthdate' 				=> array(
					'label' => __( 'Birthdate', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_user-birthdate', true )
				),
				'billing_houseno' 			=> array(
					'label' => __( 'Billing House Number', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_houseno', true )
				),
				'shipping_houseno' 			=> array(
					'label' => __( 'Shipping House Number', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_shipping_houseno', true )
				),
				'company_reg_number' 		=> array(
					'label' => __( 'Company Registration Number', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_company_reg', true )
				),
				'paper_invoice' 			=> array(
					'label' => __( 'Paper Invoice', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_paper_invoice', true )
				),
				'installment' 				=> array(
					'label' => __( 'Installment', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_installment_type', true )
				),
				'customer_type'				=> array(
					'label' => __( 'Customer Type', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_customer_type', true )
				),
				'credit_rating' 			=> array(
					'label' => __( 'Credit Rating', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_credit_rating', true )
				),
				'byjuno_code'				=> array(
					'label' => __( 'Byjuno Code', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_byjuno_code', true )
				),
				'transaction_number' 		=> array(
					'label' => __( 'Transaction Number', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_trno', true )
				),
				'decision_process_number' 	=> array(
					'label' => __( 'Decision Process Number', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, '_billing_dpno', true )
				),
				'customer_reference' 		=> array(
					'label' => __( 'Customer Reference', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, 'byjuno_customer_reference', true )
				),
				'request_id' 				=> array(
					'label' => __( 'Request ID', 'woocommerce-byjuno-admin' ),
					'value' => get_post_meta( $orderid, 'byjuno_request_id', true )
				)
			);

			echo $this->views->byjuno_fields_display( $fields );

		}

	}

	function byjuno_settings_link_plugins_screen( $links ) {

		$the_links = array();

		$settings = esc_url( add_query_arg(
			array(
				'page' 		=> 'wc-settings',
				'tab' 		=> 'checkout',
				'section' 	=> 'byjuno'
			),
			get_admin_url() . 'admin.php'
		) );

		$the_links[] = '<a href=' . $settings . ' target="_blank">' . __( 'Settings', 'woocommerce-byjuno-admin' ) . '</a>';

		$logs = esc_url( add_query_arg(
			array(
				'page' => 'byjuno_error_logs'
			),
			get_admin_url() . 'admin.php'
		) );

		$the_links[] = '<a href=' . $logs . ' target="_blank">' . __( 'Error logs', 'woocommerce-byjuno-admin' ) . '</a>';

		foreach( $the_links as $the_link ) {
			array_push( $links, $the_link );
		}

		return $links;
	}

}
new ByjunoAdmin;
?>
