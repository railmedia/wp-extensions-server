(function($){

	const ByjunoAdmin = {

		init: function() {

			jQuery('.fancybox').on('click', function(e) {

				e.preventDefault();
				
				let dataType = jQuery(this).attr('data-type');
				switch( dataType ) {
					case 'image':
						jQuery.fancybox.open({
							src : '<img src="'+jQuery(this).attr('href')+'" alt="byjuno_checkout_fields_priorities" />',
							type : 'html'
						});
					break;
					case 'video':
						jQuery.fancybox.open({
							src : '<video controls loop muted autoplay><source src="'+jQuery(this).attr('href')+'" type="video/mp4"></video>',
							type : 'html'
						});
					break;
				}
			});
		
		},
		topNav: function() {

			let target   = jQuery('#mainform h2');
			let sections = jQuery('#mainform h3');
			let markup   = '<ul style="width: 100%;" class="subsubsub byjuno-top-nav">';
		
			sections.each(function(i, section){

				if( jQuery(this).text() && jQuery(this).attr('id') != 'woocommerce_byjuno_localization_separator' ) {
					markup += '<li><a href="#' + jQuery(this).attr('id') + '">' + jQuery(this).text() + '</a> <span class="sep">|</span></li>';
				}

			});
		
			markup += '</ul>';
		
			target.before( markup );
		
			jQuery('body').on('click', '.byjuno-top-nav a', function(e){
		
				e.preventDefault();
		
				jQuery('html, body').animate({
					scrollTop: jQuery( jQuery(this).attr('href') ).offset().top - 100
				}, 1500);
		
			})
		
		},
		conditionalSettings: function() {

			const ByjunoAdminConditionalSettings = {

				init: function() {
					this.orderPrefix();
					this.orderIdSource();
					this.gender();
					this.birthdate();
					this.houseNumber();
					this.companyRegistration();
					this.installments();
					this.invoiceType();
					this.logs();
				},
				orderPrefix: function() {

					// Order prefix field

					let enableOrderIdPrefix = jQuery('#woocommerce_byjuno_use_order_id_prefix');
					let orderIdPrefix 		= jQuery('#woocommerce_byjuno_order_id_prefix');
					let orderIdPrefixParent = orderIdPrefix.parents('tr');
				
					if( enableOrderIdPrefix.val() == '0' ) {
						orderIdPrefixParent.hide();
					}
				
					enableOrderIdPrefix.on('change', function(){
						parseInt( jQuery(this).val() ) ? orderIdPrefixParent.show() : orderIdPrefixParent.hide();
					});

				},
				orderIdSource: function() {

					// Order prefix field

					let orderIdSource  = jQuery('#woocommerce_byjuno_order_id_source');
					let orderIdMetaKey = jQuery('#woocommerce_byjuno_order_id_meta_key');
					let orderIdMetaKeyParent = orderIdMetaKey.parents('tr');
				
					if( orderIdSource.val() == 1 ) {
						orderIdMetaKeyParent.hide();
					}
				
					orderIdSource.on('change', function(){
						parseInt( jQuery(this).val() ) == 2 ? orderIdMetaKeyParent.show() : orderIdMetaKeyParent.hide();
					});

				},
				gender: function() {

					// Gender field

					let enableGenderField   = jQuery('#woocommerce_byjuno_use_gender_field');
					let genderFieldFirstRow = enableGenderField.parents('tr');
					let genderFieldRows     = enableGenderField.parents('table').find('tr');
					let genderFieldAltId	= jQuery('#woocommerce_byjuno_gender_field_alt_id');
					let genderFieldAltIdRows= jQuery('#woocommerce_byjuno_gender_field_alt_id_female_value, #woocommerce_byjuno_gender_field_alt_id_male_value').parents('tr');

					if( ! parseInt( enableGenderField.val() ) ) {
						genderFieldRows.hide();
						genderFieldFirstRow.show();
					} else {
						genderFieldAltId.val() ? genderFieldAltIdRows.show() : genderFieldAltIdRows.hide();
					}

					enableGenderField.on('change', function() {

						if( ! parseInt( jQuery(this).val() ) ) {
							genderFieldRows.hide();
							genderFieldFirstRow.show();
						} else {
							genderFieldRows.show();
							genderFieldAltId.val() ? genderFieldAltIdRows.show() : genderFieldAltIdRows.hide();
						}

					});

					genderFieldAltId.on('change', function(){
						jQuery(this).val() ? genderFieldAltIdRows.show() : genderFieldAltIdRows.hide();
					});

				},
				birthdate: function() {

					// Birthdate field

					let enableBirthdateField 		= jQuery('#woocommerce_byjuno_use_birthdate_field');
					let birthdateFieldFirstRow 		= enableBirthdateField.parents('tr');
					let birthdateFieldRows 			= enableBirthdateField.parents('table').find('tr');
					let birthdateType				= jQuery('#woocommerce_byjuno_birthdate_field_type');
					let birthdateTypeSeparateFields = jQuery('#woocommerce_byjuno_birthdate_field_day_label, #woocommerce_byjuno_birthdate_field_month_label, #woocommerce_byjuno_birthdate_field_year_label').parents('tr');
					let birthdateTypeSingleField 	= jQuery('#woocommerce_byjuno_birthdate_field_label').parents('tr');

					if( ! parseInt( enableBirthdateField.val() ) ) {

						birthdateFieldRows.hide();
						birthdateFieldFirstRow.show();

					} else {

						if( parseInt( birthdateType.val() ) == 1 ) {
							birthdateTypeSingleField.hide();
							birthdateTypeSeparateFields.show();
						} else if ( parseInt( birthdateType.val() ) == 2 ) {
							birthdateTypeSingleField.show();
							birthdateTypeSeparateFields.hide();
						}

					}

					enableBirthdateField.on('change', function(){

						if( ! parseInt( jQuery(this).val() ) ) {
							birthdateFieldRows.hide();
							birthdateFieldFirstRow.show();
						} else {
							birthdateFieldRows.show();
							if( parseInt( birthdateType.val() ) == 1 ) {
								birthdateTypeSingleField.hide();
								birthdateTypeSeparateFields.show();
							} else if ( parseInt( birthdateType.val() ) == 2 ) {
								birthdateTypeSingleField.show();
								birthdateTypeSeparateFields.hide();
							}
						}

					});

					birthdateType.on('change', function(){

						if( parseInt( jQuery(this).val() ) == 1 ) {
							birthdateTypeSingleField.hide();
							birthdateTypeSeparateFields.show();
						} else if ( parseInt( jQuery(this).val() ) == 2 ) {
							birthdateTypeSingleField.show();
							birthdateTypeSeparateFields.hide();
						}

					});

				},
				houseNumber: function() {

					// House number field

					let enableHouseNumberField = jQuery('#woocommerce_byjuno_use_houseno_field');
					let houseNumberFirstRow    = enableHouseNumberField.parents('tr');
					let houseNumberFieldRows   = enableHouseNumberField.parents('table').find('tr');

					if( ! parseInt( enableHouseNumberField.val() ) ) {
						houseNumberFieldRows.hide();
						houseNumberFirstRow.show();
					}

					enableHouseNumberField.on('change', function() {

						if( ! parseInt( jQuery(this).val() ) ) {
							houseNumberFieldRows.hide();
							houseNumberFirstRow.show();
						} else {
							houseNumberFieldRows.show();
						}

					});

				},
				companyRegistration: function() {

					// Company registration field

					let enableCompanyRegField = jQuery('#woocommerce_byjuno_use_company_reg_field');
					let companyRegFirstRow    = enableCompanyRegField.parents('tr');
					let companyRegFieldRows   = enableCompanyRegField.parents('table').find('tr');

					if( ! parseInt( enableCompanyRegField.val() ) ) {
						companyRegFieldRows.hide();
						companyRegFirstRow.show();
					}

					enableCompanyRegField.on('change', function() {

						if( ! parseInt( jQuery(this).val() ) ) {
							companyRegFieldRows.hide();
							companyRegFirstRow.show();
						} else {
							companyRegFieldRows.show();
						}

					});

				},
				installments: function() {

					//Installments fields

					let that = this;

					let enableInstallmentsField = jQuery('#woocommerce_byjuno_use_installments');
					let installmentsFirstRow    = enableInstallmentsField.parents('tr');
					let installmentsFieldRows   = enableInstallmentsField.parents('table').find('tr');

					that.toggleInstallments();

					if( ! parseInt( enableInstallmentsField.val() ) ) {
						installmentsFieldRows.hide();
						installmentsFirstRow.show();
					}

					enableInstallmentsField.on('change', function(){

						if( ! parseInt( enableInstallmentsField.val() ) ) {
							installmentsFieldRows.hide();
							installmentsFirstRow.show();
						} else {
							installmentsFieldRows.show();
							that.toggleInstallments();
						}

					});

				},
				toggleInstallments: function() {

					let installmentsTypes = [ 'full', 3, 4, 12, 24, 36 ];

					installmentsTypes.map(function( installmentType, i ) {

						let installmentToggle = jQuery( '#woocommerce_byjuno_use_installments_' + installmentType );
						let installmentFor = jQuery('#woocommerce_byjuno_installments_' + installmentType + '_for').parents('tr');
						let installmentTemplate = jQuery('#woocommerce_byjuno_installments_' + installmentType + '_template').parents('tr');

						if( installmentToggle.is(':checked') ) {
							installmentFor.show();
							installmentTemplate.show();
						} else {
							installmentFor.hide();
							installmentTemplate.hide();
						}

						installmentToggle.on('change', function(){
							if( jQuery(this).is(':checked') ) {
								installmentFor.show();
								installmentTemplate.show();
							} else {
								installmentFor.hide();
								installmentTemplate.hide();
							}
						});

					});

				},
				invoiceType: function() {

					//Invoice type field

					let enableInvoiceTypeField = jQuery('#woocommerce_byjuno_invoice_type');
					let invoiceTypeFirstRow    = enableInvoiceTypeField.parents('tr');
					let invoiceTypeFieldRows   = enableInvoiceTypeField.parents('table').find('tr');

					if( ! parseInt( enableInvoiceTypeField.val() ) ) {
						invoiceTypeFieldRows.hide();
						invoiceTypeFirstRow.show();
					}

					enableInvoiceTypeField.on('change', function() {

						if( ! parseInt( jQuery(this).val() ) ) {
							invoiceTypeFieldRows.hide();
							invoiceTypeFirstRow.show();
						} else {
							invoiceTypeFieldRows.show();
						}

					});

				},
				logs: function() {

					let enableLogsField = jQuery('#woocommerce_byjuno_logs_enable');
					let logsLink		= jQuery('#woocommerce_byjuno_logs_separator');

					if( ! parseInt( enableLogsField.val() ) ) {
						logsLink.hide();
					}

					enableLogsField.on('change', function() {

						if( ! parseInt( jQuery(this).val() ) ) {
							logsLink.hide();
						} else {
							logsLink.show();
						}

					});

				}

			}

			ByjunoAdminConditionalSettings.init();

		}

	}

	jQuery(document).ready(function() {

		ByjunoAdmin.init();

		ByjunoAdmin.topNav();
	
		ByjunoAdmin.conditionalSettings();
	
	});

})(jQuery);