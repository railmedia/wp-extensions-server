(function($){

    const ByjunoAdminOrder = {

        fieldsMore: function() {

            let trigger = jQuery('#byjuno_fields_show_more');
            let more    = jQuery('#byjuno_fields_more');
        
            trigger.on('click', function() {
        
                let status = jQuery(this).attr('data-status');
        
                switch(status) {
                    case 'open':
                        jQuery(this).attr('data-status', 'closed');
                        jQuery(this).text( byjunoao.langs.showMore ? byjunoao.langs.showMore : 'Show More' );
                        more.hide();
                    break;
                    case 'closed':
                        jQuery(this).attr('data-status', 'open');
                        jQuery(this).text( byjunoao.langs.showLess ? byjunoao.langs.showLess : 'Show Less' );
                        more.show();
                    break;
                }
        
            });
        
        }

    }

    jQuery(document).ready(function(){

        if( jQuery('#byjuno_fields_more').length ) {
            ByjunoAdminOrder.fieldsMore();
        }
    
    });

})(jQuery);