<?php
class ByjunoAdminViews {

    function byjuno_fields_display( $data ) {
        ob_start();
?>
        <div class="byjuno_specific_fields">
            <h3><?php _e( 'Byjuno data', 'woocommerce-byjuno-admin' ); ?></h3>
            <?php
                $counter = 1;
                foreach($data as $id => $details) {
                    if( $counter == 3 ) {
            ?>
                    <div id="byjuno_fields_more" style="display:none;">
            <?php
                    }
                    if( isset( $details['value'] ) && $details['value'] ) {
            ?>
                    <p><strong><?php echo $details['label']; ?></strong>: <?php echo $details['value']; ?></p>
            <?php
                    }
                    $counter++;
                }
            ?>
            </div>
            <p data-status="closed" id="byjuno_fields_show_more">
                <?php _e( 'Show more', 'woocommerce-byjuno-admin' ); ?>
            </p>
        </div>
        <div class="clear"></div>
<?php
        return ob_get_clean();
    }

}
?>
