<?php
$files = array(
    'views/byjuno-admin.views.class.php',
    'controllers/byjuno-admin.class.php',
    BYJUNOPATH . 'frontend/views/byjuno.views.class.php'
);
foreach( $files as $file ) {
    require_once( $file );
}
?>
