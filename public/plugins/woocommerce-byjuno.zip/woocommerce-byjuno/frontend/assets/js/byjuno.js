(function($){

	const ByjunoFrontend = {

		state: {
			installmentOption: ''
		},
		init: function() {
			this.byjunoB2b();
			this.byjunoPostCode();
			this.byjunoClearDuplicateThankYou();
		},
		byjunoB2b: function() {

			let that = this;

			if( jQuery('#billing_company').length ) {
		
				that.byjunoDoB2b();
				that.byjunoB2bInstallments();
		
				jQuery( document ).ajaxComplete(function( event, xhr, settings ) {

					if( settings.url == '/?wc-ajax=update_order_review' || settings.url == '/' + byjuno.bl + '/?wc-ajax=update_order_review' ) {
						that.byjunoDoB2b();
						that.byjunoB2bInstallments();
						if( jQuery('.byjuno_not_available_notice').length ) {
							this.byjunoDuplicateErrorTriggerUpdate();
						}
					}

				});
		
				jQuery('body').on('change', '#billing_company', function() {
					that.byjunoDoB2b();
					that.byjunoB2bInstallments();
				});
		
			}
		
		},
		byjunoDoB2b: function() {

			let companyRegField = this.byjunoCompanyRegField();

			console.log(companyRegField);
		
			if( companyRegField != undefined && companyRegField.length ) {
		
				let companyRegFieldContainer = jQuery('#' + companyRegField.attr('id') + '_field');
		
				jQuery('#billing_company').val() ? companyRegFieldContainer.show() : companyRegFieldContainer.hide();
		
			}
		
		},
		byjunoB2bInstallments: function() {

			let isB2bOrB2C = jQuery('#billing_company').val() ? 'b2b' : 'b2c';
			let installments_types = jQuery('.payment_method_byjuno input[name="byjuno-installments-type"]');
			let company_field = jQuery('#billing_company');
		
			if( jQuery('.payment_method_byjuno input[name="byjuno-installments-type"]').length ) {
		
				installments_types.each(function(i, v){

					let availableFor = jQuery(this).attr('data-installments_for');

					if( availableFor != 'all') {
						if( availableFor != isB2bOrB2C ) {
							jQuery(this).prop('checked', false);
							jQuery(this).parent().hide();
						} else {
							jQuery(this).prop('checked', true);
							jQuery(this).parent().show();
						}
					}

				});
		
			}
		
		},
		byjunoDuplicateErrorTriggerUpdate: function() {

			let counter = 1;
			let hasMultiple = 0;
		
			jQuery('.byjuno_not_available_notice').each(function(i, notice){
				if( counter > 1 ) {
					jQuery(this).remove();
					hasMultiple++;
				}
				counter++;
			});
		
		},
		byjunoPostCode: function() {

			let pcl = byjuno.pcl;
			let pcno = byjuno.pcno;
		
			if( !pcl ) pcl = 8;
		
			jQuery( '#billing_postcode' ).on('keypress', function(e) {
		
				if(e.keyCode == 8 || e.keyCode == 46 || e.keyCode == 37 || e.keyCode == 39) {
					return true;
				}
		
				let value = jQuery(this).val();
		
				if( value.length >= pcl ) {
					e.preventDefault();
				}
		
			});
		
			if( pcno > 0 ) {
		
				jQuery( '#billing_postcode' ).on('input', function(e) {
					var value = jQuery(this).val();
					value = value.replace(/\D/g, '');
					jQuery(this).val(value);
				});
			}
		
		},
		byjunoClearDuplicateThankYou: function() {

			let thanks = jQuery('.byjuno-thank-you-instructions');
			let counter = 1;
		
			if( thanks.length ) {
		
				jQuery.each(thanks, function(i, v){
					if(counter > 1) {
						jQuery(this).remove();
					}
					counter++;
				});
		
			}
		
		},
		byjunoBirthdateEdit: function() {

			let day 	= jQuery('#billing_user-birthdate-day');
			let month 	= jQuery('#billing_user-birthdate-month');
			let year 	= jQuery('#billing_user-birthdate-year');
			let dbField = jQuery('#billing_user-birthdate');
			let bdString= '';
		
			bdString = day.val() + '.' + month.val() + '.' + year.val();
		
			dbField.val( bdString );
		
		},
		byjunoUserBirthdateInit: function() {

			let startDate = "1917";
			let underaged = byjuno.au == '1' ? '-9' : '-18';
			let lang = byjuno.datelang;
			let monthNames, monthNamesShort, dayNames, dayNamesShort, dayNamesMin;
		
			if( lang.monthNames ) {
				monthNames = lang.monthNames;
				monthNamesShort = monthNames.map(function(month){
					return month.substr(0, 3);
				});
			} else {
				monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
				monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
			}
		
			if( lang.dayNames ) {
				dayNames = lang.dayNames;
				dayNamesShort = dayNames.map(function(day){
					return day.substr(0, 2);
				});
				dayNamesMin = dayNamesShort;
			} else {
				dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
				dayNamesShort = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
				dayNamesMin = dayNamesShort;
			}
		
			jQuery('#billing_user-birthdate').datepicker({
		
				closeText: lang.closeText ? lang.closeText : 'Close',
				prevText: lang.prevText ? lang.prevText : "&#x3C;Prev",
				nextText: lang.nextText ? lang.nextText : "Next&#x3E;",
				currentText: lang.currentText ? lang.currentText : "Today",
				monthNames: lang.monthNames,
				monthNamesShort: monthNamesShort,
				dayNames: dayNames,
				dayNamesShort: dayNamesShort,
				dayNamesMin: dayNamesMin,
				weekHeader: "KW",
				firstDay: 1,
				isRTL: false,
				showMonthAfterYear: false,
				minDate: new Date(1900,1-1,1),
				maxDate: underaged + 'Y',
				dateFormat: 'dd.mm.yy',
				defaultDate: new Date(1970,1-1,1),
				changeMonth: true,
				changeYear: true,
				yearRange: '-110:' + underaged
		
			});
		
			jQuery('#billing_user-birthdate_fancybox').datepicker({
		
				closeText: lang.closeText ? lang.closeText : 'Close',
				prevText: lang.prevText ? lang.prevText : "&#x3C;Prev",
				nextText: lang.nextText ? lang.nextText : "Next&#x3E;",
				currentText: lang.currentText ? lang.currentText : "Today",
				monthNames: lang.monthNames,
				monthNamesShort: monthNamesShort,
				dayNames: dayNames,
				dayNamesShort: dayNamesShort,
				dayNamesMin: dayNamesMin,
				weekHeader: "KW",
				firstDay: 1,
				isRTL: false,
				showMonthAfterYear: false,
				minDate: new Date(1900,1-1,1),
				maxDate: underaged + 'Y',
				dateFormat: 'dd.mm.yy',
				defaultDate: new Date(1970,1-1,1),
				changeMonth: true,
				changeYear: true,
				yearRange: '-110:' + underaged,
				constrainInput: true
		
			});
		
		},
		byjunoFillLabels: function() {

			let fields = {
				'#billing_email' 	 : '#suboption_via_email_value',
				'#billing_address_1' : '#suboption_via_post_address_1_value',
				'#billing_postcode'  : '#suboption_via_post_postcode_value',
				'#billing_city' 	 : '#suboption_via_post_city_value'
			};
		
			jQuery.each(fields, function(field, target){
		
				if(jQuery(field).val() != ''){
					jQuery(target).text(jQuery(field).val());
				}
		
				jQuery(field).on('change', function(){
					jQuery(target).text(jQuery(field).val());
				});
		
			});
		
			if( jQuery('input[name="byjuno-installments-type"]').length ) {
		
				if( this.state.installmentOption ) {
		
					jQuery('.billing_byjuno_radio[value="' + installmentOption + '"]').prop('checked', true);
		
				} else {
		
					var firstInstall = jQuery('input[name="byjuno-installments-type"]')[0];
					firstInstall.checked = true;
		
				}
		
			}
		
			jQuery('input[name="byjuno-installments-type"]').on('click', function(){
				ByjunoFrontend.state.installmentOption = jQuery(this).val();
			});
		
		},
		byjunoCompanyRegField: function() {

			let companyRegField;
		
			if( jQuery('#' + byjuno.ccrf).length ) {
				companyRegField = jQuery('#' + byjuno.ccrf);
			} else if( jQuery('#billing_company_reg').length ) {
				companyRegField = jQuery('#billing_company_reg');
			}
			
			return companyRegField;
		
		}

	}

	jQuery(document).ready(function() {

		ByjunoFrontend.init();
	
		let numbersOnly = /^[0-9]+$/;
		let currentYear = new Date().getFullYear();
	
		jQuery('body').on('change', '#billing_user-birthdate-day', function(){
			if( ! jQuery(this).val().match( numbersOnly ) || jQuery(this).val() > 31 ) {
				jQuery('#billing_user-birthdate').val('');
				jQuery(this).val('');
			} else {
				ByjunoFrontend.byjunoBirthdateEdit();
			}
		});
	
		jQuery('body').on('change', '#billing_user-birthdate-month', function(){
			if( ! jQuery(this).val().match( numbersOnly ) || jQuery(this).val() > 12 ) {
				jQuery('#billing_user-birthdate').val('');
				jQuery(this).val('');
			} else {
				ByjunoFrontend.byjunoBirthdateEdit();
			}
		});
	
		jQuery('body').on('change', '#billing_user-birthdate-year', function(){
			if( ! jQuery(this).val().match( numbersOnly ) || jQuery(this).val() < 1900 || jQuery(this).val() >= currentYear ) {
				jQuery('#billing_user-birthdate').val('');
				jQuery(this).val('');
			} else {
				ByjunoFrontend.byjunoBirthdateEdit();
			}
		});
	
		jQuery('body').on('keypress', '#billing_user-birthdate-day', function(){
			if( jQuery(this).val().length >= 2 ) {
				return false;
			}
			ByjunoFrontend.byjunoBirthdateEdit();
		});
	
		jQuery('body').on('keypress', '#billing_user-birthdate-month', function(){
			if( jQuery(this).val().length >= 2 ) {
				return false;
			}
			ByjunoFrontend.byjunoBirthdateEdit();
		});
	
		jQuery('body').on('keypress', '#billing_user-birthdate-year', function(){
			if( jQuery(this).val().length >= 4 ) {
				return false;
			}
			ByjunoFrontend.byjunoBirthdateEdit();
		});
	
		jQuery('body').on({
			mouseenter: function(){
				jQuery(this).before( '<span class="byjuno-tooltip">' + jQuery(this).attr('data-tooltip') );
			},
			mouseleave: function(){
				jQuery('.byjuno-tooltip').remove();
			}
		}, '.birthdate-year-tooltip');
	
	});
	
	jQuery(window).on('load', function() {
	
		if( jQuery('#billing_user-birthdate').length ) {
			ByjunoFrontend.byjunoUserBirthdateInit();
		}
	
		ByjunoFrontend.byjunoFillLabels();
	
		jQuery(document).ajaxComplete(function(e, request, settings) {
			ByjunoFrontend.byjunoUserBirthdateInit();
			ByjunoFrontend.byjunoFillLabels();
		});
	
	});

	jQuery( document ).ajaxComplete(function( event, xhr, settings ) {

		if( jQuery('#billing_user-birthdate').length ) {
			ByjunoFrontend.byjunoUserBirthdateInit();
		}
	
		if( settings.url == '/?wc-ajax=update_order_review' || settings.url == '/' + byjuno.bl + '/?wc-ajax=update_order_review' ) {
			if( jQuery('.byjuno_not_available_notice').length ) {
				ByjunoFrontend.byjunoDuplicateErrorTriggerUpdate();
			}
		}
	
		if( byjuno.asb == '1' ) {
	
			setTimeout(function(){
				if(jQuery('.payment_method_byjuno').length > 0) {
					jQuery('.payment_method_byjuno input').prop('checked', true);
					jQuery('.payment_box').fadeOut(function() {
						jQuery('.payment_box.payment_method_byjuno').fadeIn();
					});
				}
			}, 1000);
	
		}
	
		ByjunoFrontend.byjunoB2bInstallments();
	
	});

})(jQuery);