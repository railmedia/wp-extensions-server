<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

add_action('plugins_loaded', 'wc_byjuno_gateway_init', 100);

function wc_byjuno_gateway_init() {

	class WC_Gateway_Byjuno extends WC_Payment_Gateway {

		var $views;

		public function __construct() {

			$this->views 				= new ByjunoViews;
			$this->id                 	= 'byjuno';
			$this->icon               	= apply_filters('woocommerce_byjuno_icon', '');
			$this->has_fields         	= false;
			$this->method_title       	= __( 'Byjuno', 'woocommerce-byjuno' );
			$this->method_description 	= __( 'Performs a check against Byjuno database. Depending on the result of the lookup, customers will be allowed to choose this gateway for checkout or not. Orders are marked as "on-hold" when received.', 'woocommerce-byjuno' );
			if( in_array( 'woocommerce-byjuno-multi-language/woocommerce-byjuno-multi-language.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
				$this->method_description .= '<p>' . __( 'You are currently using the WooCommerce Byjuno Multi Language plugin. The labels you set here will be overwritten by the ones you set in the Multi Language plugin.', 'woocommerce-byjuno' ) . '</p>';
				$this->method_description .= '<p>' . sprintf( __( '%sClick here to open the Multi Language settings page%s', 'woocommerce-byjuno' ), '<a href="' . admin_url() . 'admin.php?page=byjuno_multi_language" target="_blank">', '</a>' );
			}
			$settings 					= get_option('woocommerce_byjuno_settings');
			$session					= WC()->session;
			if($session) {
				$customer				= $session->get('customer');
			}
			$labels 					= byjuno_fields_labels();

			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();

			if( isset( $settings['display_gateway_logo'] ) && $settings['display_gateway_logo'] == '1' && ! is_admin() ) {
				$this->icon = BYJUNOURL . 'frontend/assets/img/byjuno.gif';
			}
			$this->title = $labels ? $labels['gateway_title'] : $this->get_option('title');

			$this->description = $labels ? $labels['gateway_description'] . $this->get_byjuno_custom_fields() : $this->get_option('description') . $this->get_byjuno_custom_fields();
			//$this->description = $this->get_option('description');

			$this->instructions = $labels ? $labels['gateway_instructions'] : $this->get_option( 'instructions' );

			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );

			// Customer Emails
			//add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		}

		function get_byjuno_custom_fields() {

			$settings	 = byjuno_settings();
			$labels 	 = byjuno_fields_labels();
			$description = '';

			if( isset( $settings['use_company_reg_field'] ) && $settings['use_company_reg_field'] ) {

				if( ! $settings['company_reg_field_alt_id'] ) {

					$company_reg = isset( $labels['gateway_company_registration'] ) && $labels['gateway_company_registration'] ? $labels['gateway_company_registration'] : '';
					$company_reg_req = isset( $settings['company_reg_field_required'] ) && $settings['company_reg_field_required'] == '1' ? '<font color="red">*</font>' : '';

					ob_start();
?>
					<div id="billing_company_reg_field" style="display:none;">
						<?php if( isset( $settings['company_reg_field_label_type'] ) && $settings['company_reg_field_label_type'] == '1' ) { ?>
						<p><label for="billing_company_reg"><?php echo $company_reg; ?><?php echo $company_reg_req; ?></label></p>
						<?php } ?>
						<p>
							<input type="text" class="billing_byjuno_text" <?php echo ( isset( $settings['company_reg_field_label_type'] ) && $settings['company_reg_field_label_type'] == '2' ) ? 'placeholder="' . $company_reg . '"' : ''; ?> name="billing_company_reg" id="billing_company_reg" value="" />
						</p>
					</div>
<?php
					$description .= ob_get_clean();

				}

			}

			if( isset( $settings['use_gender_field'] ) && $settings['use_gender_field'] ) {

				if( ! $settings['gender_field_alt_id'] ) {

					$label_gender = isset( $labels['gateway_gender'] ) && $labels['gateway_gender'] ? $labels['gateway_gender'] : '';
					$label_gender_female = isset( $labels['gateway_gender_female'] ) && $labels['gateway_gender_female'] ? $labels['gateway_gender_female'] : '';
					$label_gender_male = isset( $labels['gateway_gender_male'] ) && $labels['gateway_gender_male'] ? $labels['gateway_gender_male'] : '';

					ob_start();

					if( isset( $settings['gender_field_functionality'] ) && $settings['gender_field_functionality'] ) {

						switch( $settings['gender_field_functionality'] ) {
							case '1':
?>
							<p><label for="billing_user-gender"><?php echo $label_gender; ?><font color="red">*</font></label></p>
							<select class="billing_byjuno_select" id="billing_user-gender" name="billing_user-gender">
								<option value="2"><?php echo $label_gender_female; ?></option>
								<option value="1"><?php echo $label_gender_male; ?></option>
							</select>
<?php
							break;
							case '2':
?>
							<p><?php echo $label_gender; ?><font color="red">*</font></p>
							<p>
								<input class="billing_byjuno_radio" type="radio" id="billing_user-gender_2" name="billing_user-gender" value="2" /> <label class="billing_byjuno_radio_label" for="billing_user-gender_2"><?php echo $label_gender_female; ?></label>
							</p>
							<p>
								<input class="billing_byjuno_radio" type="radio" id="billing_user-gender_1" name="billing_user-gender" value="1" /> <label class="billing_byjuno_radio_label" for="billing_user-gender_1"><?php echo $label_gender_male; ?></label>
							</p>
<?php
							break;

						}

					}

					$description .= ob_get_clean();

				}

			}

			if( isset( $settings['use_birthdate_field'] ) && $settings['use_birthdate_field'] ) {

				if( ! $settings['birthdate_field_alt_id'] ) {

					$label_birthdate = isset( $labels['gateway_birthdate'] ) && $labels['gateway_birthdate'] ? $labels['gateway_birthdate'] : '';
					$label_birthdate_day = isset( $labels['gateway_birthdate_day'] ) && $labels['gateway_birthdate_day'] ? $labels['gateway_birthdate_day'] : '';
					$label_birthdate_month = isset( $labels['gateway_birthdate_month'] ) && $labels['gateway_birthdate_month'] ? $labels['gateway_birthdate_month'] : '';
					$label_birthdate_year = isset( $labels['gateway_birthdate_year'] ) && $labels['gateway_birthdate_year'] ? $labels['gateway_birthdate_year'] : '';

					$birthdate_field_type = isset( $settings['birthdate_field_type'] ) && $settings['birthdate_field_type'] ? $settings['birthdate_field_type'] : '1';
					$label_birthdate_type = isset( $settings['birthdate_field_label_type'] ) && $settings['birthdate_field_label_type'] ? $settings['birthdate_field_label_type'] : '1';

					ob_start();

?>
					<?php if( $birthdate_field_type == '1' ) { ?>

						<p><label for="billing_user-birthdate"><?php echo $label_birthdate; ?><font color="red">*</font></label></p>

						<p>
							<input type="hidden" name="billing_user-birthdate" id="billing_user-birthdate" readonly="readonly" value="" />
						</p>

						<div class="billing-birthdate-container">

							<div class="billing-birthdate-item billing-birthdate-day">

								<?php if( $label_birthdate_type == '1' ) { ?>
								<p><label for="billing_user-birthdate-day"><?php echo $label_birthdate_day; ?><font color="red">*</font></label></p>
								<?php } ?>

								<p>
									<input type="text" maxlength="2" placeholder="<?php echo $label_birthdate_day; ?>" name="billing_user-birthdate-day" id="billing_user-birthdate-day" value="" />
								</p>

							</div>

							<div class="billing-birthdate-item billing-birthdate-month">

								<?php if( $label_birthdate_type == '1' ) { ?>
								<p><label for="billing_user-birthdate-month"><?php echo $label_birthdate_month; ?><font color="red">*</font></label></p>
								<?php } ?>

								<p>
									<input type="text" placeholder="<?php echo $label_birthdate_month; ?>" maxlength="2" name="billing_user-birthdate-month" id="billing_user-birthdate-month" value="" />
								</p>

							</div>

							<div class="billing-birthdate-item billing-birthdate-year">

								<?php if( $label_birthdate_type == '1' ) { ?>
								<p><label for="billing_user-birthdate-year"><?php echo $label_birthdate_year; ?><font color="red">*</font></label></p>
								<?php } ?>

								<p>
									<input type="text" placeholder="<?php echo $label_birthdate_year; ?>" maxlength="4" name="billing_user-birthdate-year" id="billing_user-birthdate-year" value="" />
								</p>

							</div>

							<div class="clear"></div>

						</div>

					<?php } else { ?>

						<?php if( $label_birthdate_type == '1' ) { ?>
						<p><label for="billing_user-birthdate"><?php echo $label_birthdate; ?><font color="red">*</font></label></p>
						<?php } ?>

						<p><input name="billing_user-birthdate" id="billing_user-birthdate" placeholder="<?php echo $label_birthdate_type == '2' ? $label_birthdate : ''; ?>" value="" /></p>

					<?php } ?>
<?php

					$description .= ob_get_clean();

				}

			}

			if( isset( $settings['use_houseno_field'] ) && $settings['use_houseno_field'] ) {

				if( ! $settings['houseno_field_alt_id'] ) {

					$label_houseno = isset( $labels['gateway_house_number'] ) && $labels['gateway_house_number'] ? $labels['gateway_house_number'] : '';

					ob_start();

?>
					<?php if( isset( $settings['houseno_field_label_type'] ) && $settings['houseno_field_label_type'] == '1' ) { ?>
					<p><label for="billing_houseno"><?php echo $label_houseno; ?><font color="red">*</font></label></p>
					<?php } ?>
					<p>
						<input type="text" class="billing_byjuno_text" <?php echo ( isset( $settings['houseno_field_label_type'] ) && $settings['houseno_field_label_type'] == '2' ) ? 'placeholder="' . $label_houseno . '"' : ''; ?> name="billing_houseno" id="billing_houseno" value="" />
					</p>
<?php

					$description .= ob_get_clean();

				}

			}

			if( isset( $settings['invoice_type'] ) && $settings['invoice_type'] ) {

				global $wp;
				$order = null;
				$order_pay = isset( $wp->query_vars['order-pay'] ) && $wp->query_vars['order-pay'] ? $wp->query_vars['order-pay'] : null;
				if( $order_pay ) {
					$order = wc_get_order( $order_pay );
				}

				if( $settings['invoice_type_intro_text'] ) {

					$label_intro = isset( $labels['gateway_invoice_type_intro'] ) && $labels['gateway_invoice_type_intro'] ? $labels['gateway_invoice_type_intro'] : '';
					$label_mail = isset( $labels['gateway_invoice_type_email'] ) && $labels['gateway_invoice_type_email'] ? $labels['gateway_invoice_type_email'] : '';
					$label_post = isset( $labels['gateway_invoice_type_post_office'] ) && $labels['gateway_invoice_type_post_office'] ? $labels['gateway_invoice_type_post_office'] : '';

					ob_start();
	?>
					<p>
						<?php echo $label_intro; ?>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if( $settings['invoice_via_email'] ) {

					$replace_email = '';

					if( isset( $customer ) && ! empty( $customer ) ) {
						$replace_email = $customer['email'];
					}

					if( $order ) {
						$replace_email = $order->get_billing_email();
					}


					$thevalue = ! is_admin() ? str_replace( '{email}', '<span id="suboption_via_email_value">' . $replace_email . '</span>', $label_mail ) : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" name="byjuno-invoice-type" checked="checked" value="NO" id="byjuno-invoice-type-email" /> <label class="billing_byjuno_radio_label" for="byjuno-invoice-type-email"><?php echo $thevalue; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();

				}

				if( $settings['invoice_via_post'] ) {

					$replace_address = '';

					if( isset( $customer ) && ! empty( $customer ) ) {
						$replace_address = '<span id="suboption_via_post_address_1_value">' . $customer['address_1'] . '</span>, <span id="suboption_via_post_postcode_value">' . $customer['postcode'] . '</span>, <span id="suboption_via_post_city_value">' . $customer['city'] . '</span>';
					}

					if( $order ) {
						$replace_address = '<span id="suboption_via_post_address_1_value">' . $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() . '</span>, <span id="suboption_via_post_postcode_value">' . $order->get_billing_postcode() . '</span>, <span id="suboption_via_post_city_value">' . $order->get_billing_city() . '</span>';
					}

					$thevalue = ! is_admin() ? str_replace( '{address}', $replace_address, $label_post ) : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" name="byjuno-invoice-type" value="YES" id="byjuno-invoice-type-paper" /> <label class="billing_byjuno_radio_label" for="byjuno-invoice-type-paper"><?php echo $thevalue; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();

				}

			}

			if( isset( $settings['use_installments'] ) && $settings['use_installments'] ) {

				if(
					$settings['use_installments_full'] == 'yes' || $settings['use_installments_3'] == 'yes' || $settings['use_installments_4'] == 'yes' || $settings['use_installments_12'] == 'yes' || $settings['use_installments_24'] == 'yes' || $settings['use_installments_36'] == 'yes'
				) {

					$label_intro = isset( $labels['gateway_installments_intro'] ) && $labels['gateway_installments_intro'] ? $labels['gateway_installments_intro'] : '';

					if( $label_intro ) {

						ob_start();

	?>
						<p><?php echo $label_intro; ?><font color="red">*</font></p>
	<?php

						$description .= ob_get_clean();

					}

				}

				if( $settings['use_installments_full'] == 'yes' ) {

					$label_installments_full = isset( $labels['gateway_installments_full'] ) && $labels['gateway_installments_full'] ? $labels['gateway_installments_full'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" name="byjuno-installments-type" value="1" data-installments_for="<?php echo $settings['installments_full_for']; ?>" id="byjuno-installment-type-full" /> <label class="billing_byjuno_radio_label" for="byjuno-installment-type-full"><?php echo $label_installments_full; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if($settings['use_installments_3'] == 'yes') {

					$label_installments_3 = isset( $labels['gateway_installments_3'] ) && $labels['gateway_installments_3'] ? $labels['gateway_installments_3'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" data-installments_for="<?php echo $settings['installments_3_for']; ?>" name="byjuno-installments-type" value="3" id="byjuno-installment-type-3" /> <label class="billing_byjuno_radio_label" for="byjuno-installment-type-3"><?php echo $label_installments_3; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if($settings['use_installments_4'] == 'yes') {

					$label_installments_4 = isset( $labels['gateway_installments_4'] ) && $labels['gateway_installments_4'] ? $labels['gateway_installments_4'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" data-installments_for="<?php echo $settings['installments_4_for']; ?>" name="byjuno-installments-type" value="4" id="byjuno-installment-type-4" /> <label class="billing_byjuno_radio_label" for="byjuno-installment-type-4"><?php echo $label_installments_4; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if($settings['use_installments_12'] == 'yes') {

					$label_installments_12 = isset( $labels['gateway_installments_12'] ) && $labels['gateway_installments_12'] ? $labels['gateway_installments_12'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" data-installments_for="<?php echo $settings['installments_12_for']; ?>" name="byjuno-installments-type" value="12" id="byjuno-installment-type-12" /> <label class="billing_byjuno_radio_label" for="byjuno-installment-type-12"><?php echo $label_installments_12; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if($settings['use_installments_24'] == 'yes') {

					$label_installments_24 = isset( $labels['gateway_installments_24'] ) && $labels['gateway_installments_24'] ? $labels['gateway_installments_24'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" data-installments_for="<?php echo $settings['installments_24_for']; ?>" name="byjuno-installments-type" value="24" id="byjuno-installment-type-24" /> <label for="byjuno-installment-type-24"><?php echo $label_installments_24; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

				if($settings['use_installments_36'] == 'yes') {

					$label_installments_36 = isset( $labels['gateway_installments_36'] ) && $labels['gateway_installments_36'] ? $labels['gateway_installments_36'] : '';

					ob_start();
	?>
					<p>
						<input type="radio" class="billing_byjuno_radio" data-installments_for="<?php echo $settings['installments_36_for']; ?>" name="byjuno-installments-type" value="36" id="byjuno-installment-type-36" /> <label class="billing_byjuno_radio_label" for="byjuno-installment-type-36"><?php echo $label_installments_36; ?></label>
					</p>
	<?php
					$description .= ob_get_clean();
				}

			}

			return $description;

		}

		public function init_form_fields() {

			$formfields_enabled = array(

				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'woocommerce-byjuno' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable Byjuno Payment', 'woocommerce-byjuno' ),
					'default' => 'yes'
				)

			);

			$formfields_title_desc_instructions = array(

				'title' => array(
					'title'       => __( 'Title', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'woocommerce-byjuno' ),
					'default'     => __( 'Byjuno Payment', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'description' => array(
					'title'       => __( 'Description', 'woocommerce-byjuno' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'woocommerce-byjuno' ),
					'default'     => __( 'Performs a check on the Byjuno database before placing an order.', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'instructions' => array(
					'title'       => __( 'Instructions', 'woocommerce-byjuno' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that will be added to the thank you page and emails.', 'woocommerce-byjuno' ),
					'default'     => __( 'To proceed, please fill all the required fields, including the Gender and Birthdate fields if required.', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'unavailable' => array(
					'title'       => __( 'Unavailable', 'woocommerce-byjuno' ),
					'type'        => 'textarea',
					'description' => __( 'Message that will appear on the checkout page if the Byjuno credit check is negative.', 'woocommerce-byjuno' ),
					'default'     => __( 'Unfortunately Byjuno is not available for your order. Please select a different payment gateway.', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

			);

			$formfields_api = array(

				'api_settings' => array(
					'title'       => __( 'API Settings', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => __( 'Below information should be taken from Byjuno', 'woocommerce-byjuno' ),
				),

				'mode' => array(
					'title'       => __( 'Mode', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						'Test' => 'Test',
						'Live' => 'Live'
					),
					'description' => __( 'Set the way the check is made - testing or live environment.', 'woocommerce-byjuno' ),
					'default'     => 'Test',
					'desc_tip'    => true,
				),

				'client_id' => array(
					'title'       => __( 'Client ID', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'API element provided by Byjuno.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'user_id' => array(
					'title'       => __( 'User ID', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'API element provided by Byjuno.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'password' => array(
					'title'       => __( 'Password', 'woocommerce-byjuno' ),
					'type'        => 'password',
					'description' => __( 'API element provided by Byjuno.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),
				'api_settings_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				),

			);

			$formfields_admin = array(

				'administration' => array(
					'title'       => __( 'Administration', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => '',
				),

				'use_order_id_prefix' => array(
					'title'       => __( 'Enable Order ID Prefix', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'description' => __( 'The prefix should be the first 3 characters of your websites\' domain. This is used for the Byjuno calls and may be requested by the Byjuno staff.', 'woocommerce-byjuno' ),
					'options'     => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'desc_tip'    => true,
				),

				'order_id_prefix' => array(
					'title'       => __( 'Order ID Prefix', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set the order ID prefix. We recommend using the first 3 letters of your websites\' domain', 'woocommerce-byjuno' ),
					'default'     => substr( str_replace(array('http://www', 'https://www.', 'http://', 'https://', 'www.'), '', site_url()), 0, 3),
					'desc_tip'    => true,
				),

				'order_id_source' => array(
					'title'       => __( 'Order ID Source', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options'	  => array(
						1 => 'WooCommerce default order ID',
						2 => 'Order meta'
					),
					'description' => __( 'Select where to take the Order ID from', 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'order_id_meta_key' => array(
					'title'       => __( 'Order ID meta key', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Get from database. You may need to contact your developer in order to correctly use this feature.', 'woocommerce-byjuno' ),
					'desc_tip'    => true
				),

				'enable_on_order_refunds' => array(
					'title'       => __( 'Enable on Order Refunds', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'description' => __( 'If set to yes, the plugin will send a partial cancellation to Byjuno when an order gets refunded or partially refunded.', 'woocommerce-byjuno' ),
					'options'     => array(
						1 => __( 'Yes', 'woocommerce-byjuno' ),
						0 => __( 'No', 'woocommerce-byjuno' )
					),
					'desc_tip'    => true,
				),

				'technical_contact' => array(
					'title'       => __( 'Technical Contact (E-mail)', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Address which will receive notifications throughout the check process.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'receive_system_emails' => array(
					'title'		  => __('Receive system emails', 'woocommerce-byjuno'),
					'type'		  => 'select',
					'options'	  => array(
						1 => __( 'Yes', 'woocommerce-byjuno' ),
						0 => __( 'No', 'woocommerce-byjuno' )
					),
					'description' => __( 'Receive emails to the above email address whenever a new order request is sent towards Byjuno or whenever a cancel request for an order is sent towards Byjuno.', 'woocommerce-byjuno' ),
					'desc_tip'	  => true
				),

				'display_gateway_logo' => array(
					'title'		  => __('Display Byjuno logo on the checkout page', 'woocommerce-byjuno'),
					'type'		  => 'select',
					'options'	  => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Display Byjuno logo by the name of the Gateway on the checkout page', 'woocommerce-byjuno' ),
					'desc_tip'	  => true
				),

				'auto_select_gateway' => array(
					'title'		  => __( 'Auto select Byjuno gateway', 'woocommerce-byjuno' ),
					'type'		  => 'select',
					'options'	  => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Auto select Byjuno gateway if it is displayed on the checkout page', 'woocommerce-byjuno' ),
					'desc_tip'	  => true
				),

				'administration_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				),
			);

			$formfields_gender = array(

				'gender_settings' => array(
					'title'       => __( 'Gender settings', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => '',
				),

				'use_gender_field' => array(
					'title'       => __( 'Use gender field', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						1 => __( 'Yes', 'woocommerce-byjuno' ),
						0 => __( 'No', 'woocommerce-byjuno' )
					),
					'description' => __( 'Add a checkout form field to collect the customer\'s gender. Can be skipped with Byjuno agreement.', 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'gender_field_label' => array(
					'title'       => __( 'Gender field label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the Gender field.', 'woocommerce-byjuno' ),
					'default'     => __( 'Gender', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'gender_field_label_female' => array(
					'title'       => __( 'Gender field Female label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for Female option in the Gender field.', 'woocommerce-byjuno' ),
					'default'     => __( 'Female', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'gender_field_label_male' => array(
					'title'       => __( 'Gender field Male label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for Male option in the Gender field.', 'woocommerce-byjuno' ),
					'default'     => __( 'Male', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'gender_field_functionality' => array(
					'title'       => __( 'Gender field functionality', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						1 => 'Select box (dropdown)',
						2 => 'Radio Buttons'
					),
					'description' => __( 'Choose how the gender field is displayed on the checkout page.', 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'gender_field_alt_id' => array(
					'title'       => __( 'Gender field alternative ID', 'woocommerce-byjuno' ) . '<br/><a class="fancybox" data-type="video" href="' . BYJUNOURL . 'admin/assets/img/gender.mp4" style="cursor:pointer">' . __( 'Check how to get the field ID', 'woocommerce-byjuno' ) . '</a>',
					'type'        => 'text',
					'description' => __( 'If your checkout page already uses a gender field, add the ID here.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'gender_field_alt_id_female_value' => array(
					'title'       => __( 'Gender field alternative female value', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Byjuno needs to receive value 2 for Female and value 1 for Male. Please add the value of the gender field alternative  field corresponding to FEMALE (eg. Frau / Female / Woman / Feminine).<br/><br/>Depending on how the custom gender field was added (tip: WooCommerce Checkout Field Editor plugin or custom code), you may wish to ask your developer about this value.<br/><br/>Leave empty if your field follows the 2 - Female; 1 - Male value - label sequence.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'gender_field_alt_id_male_value' => array(
					'title'       => __( 'Gender field alternative male value', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Byjuno needs to receive value 2 for Female and value 1 for Male. Please add the value of the gender field alternative  field corresponding to MALE (eg. Herr / Male / Man / Masculine).<br/><br/>Depending on how the custom gender field was added (tip: WooCommerce Checkout Field Editor plugin or custom code), you may wish to ask your developer about this value.<br/><br/>Leave empty if your field follows the 2 - Female; 1 - Male value - label sequence.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'gender_field_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_birthdate = array(

				'birthdate_settings' => array(
					'title'       => __( 'Birthdate settings', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => '',
				),

				'use_birthdate_field' => array(
					'title'       => __( 'Use birthdate field', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						1 => __( 'Yes', 'woocommerce-byjuno' ),
						0 => __( 'No', 'woocommerce-byjuno' )
					),
					'description' => __( "Add a checkout form field to collect the customer's date of birth. Can be skipped with Byjuno agreement.", 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'birthdate_field_type' => array(
					'title'       => __( 'Birthdate field type', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						1 => __( 'Separate Fields for day, month, and year', 'woocommerce-byjuno' ),
						2 => __( 'Single field datepicker', 'woocommerce-byjuno' )
					),
					'description' => __( 'Choose between datepicker or separate fields for day, month and year', 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'birthdate_field_day_label' => array(
					'title'       => __( 'Birthdate field day label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the Birthdate day field', 'woocommerce-byjuno' ),
					'default'     => __( 'Day', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'birthdate_field_month_label' => array(
					'title'       => __( 'Birthdate field month label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the Birthdate month field', 'woocommerce-byjuno' ),
					'default'     => __( 'Month', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'birthdate_field_year_label' => array(
					'title'       => __( 'Birthdate field year label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the Birthdate year field', 'woocommerce-byjuno' ),
					'default'     => __( 'Year', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'birthdate_field_label' => array(
					'title'       => __( 'Birthdate field label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the Birthdate field.', 'woocommerce-byjuno' ),
					'default'     => __( 'Birthdate', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'birthdate_field_label_type' => array(
					'title'       => __( 'Birthdate field label type', 'woocommerce-byjuno' ),
					'description' => __( 'Choose between a classic label or a placeholder for the Birthdate field.', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options'	  => array(
						1 => 'Classic label',
						2 => 'Placeholder'
					),
					'desc_tip'    => true,
				),

				'birthdate_field_alt_id' => array(
					'title'       => __( 'Birthdate field alternative ID', 'woocommerce-byjuno' ) . '<br/><a class="fancybox" data-type="video" href="' . BYJUNOURL . 'admin/assets/img/birthdate.mp4" style="cursor:pointer">' . __( 'Check how to get the field ID', 'woocommerce-byjuno' ) . '</a>',
					'type'        => 'text',
					'description' => __( 'If your checkout page already uses a gender field, add the ID here.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'birthday_field_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_housenumber = array(

				'housenumber_settings' => array(
					'title'       => __( 'House number settings', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => '',
				),

				'use_houseno_field' => array(
					'title'       => __( 'Use house number field', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Add a checkout form field to collect the customer\'s house number. Can be skipped with Byjuno agreement.', 'woocommerce-byjuno' ),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'houseno_field_label' => array(
					'title'       => __( 'House number field label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the House number field.', 'woocommerce-byjuno' ),
					'default'     => 'House Number',
					'desc_tip'    => true,
				),

				'houseno_field_label_type' => array(
					'title'       => __( 'House number field label type', 'woocommerce-byjuno' ),
					'description' => __( 'Choose between a classic label or a placeholder for the House number field.', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options'	  => array(
						1 => 'Classic label',
						2 => 'Placeholder'
					),
					'desc_tip'    => true,
				),

				'houseno_field_alt_id' => array(
					'title'       => __( 'House Number field alternative ID', 'woocommerce-byjuno' ) . '<br/><a class="fancybox" data-type="video" href="' . BYJUNOURL . 'admin/assets/img/birthdate.mp4" style="cursor:pointer">' . __( 'Check how to get the field ID', 'woocommerce-byjuno' ) . '</a>',
					'type'        => 'text',
					'description' => __( 'If your checkout page already uses a house number field, add the ID here.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'houseno_field_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_company_reg = array(

				'company_reg_settings' => array(
					'title'       => __( 'Company / B2B settings', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => '',
				),

				'use_company_reg_field' => array(
					'title'       => __( 'Use company registration field', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Add a checkout form field to collect the customer\'s company registration number. Enabling this field, will automatically enable the B2B functionality.', 'woocommerce-byjuno' ),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'company_reg_field_required' => array(
					'title'       => __( 'Company registration field required', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'description' => __( 'Make the company registration field required or not. If set to Yes, users will be required to supply the number before placing an order.', 'woocommerce-byjuno' ),
					'options' => array(
						1 => __( 'Yes', 'woocommerce-byjuno' ),
						0 => __( 'No', 'woocommerce-byjuno' )
					),
					'default'     => 1,
					'desc_tip'    => true
				),

				'company_reg_field_label' => array(
					'title'       => __( 'Company registration field label', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'Set a custom label for the company registration field.', 'woocommerce-byjuno' ),
					'default'     => 'Company registration number',
					'desc_tip'    => true,
				),

				'company_reg_field_label_type' => array(
					'title'       => __( 'Company registration field label type', 'woocommerce-byjuno' ),
					'description' => __( 'Choose between a classic label or a placeholder for the Company registration field.', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options'	  => array(
						1 => 'Classic label',
						2 => 'Placeholder'
					),
					'desc_tip'    => true,
				),

				'company_reg_field_alt_id' => array(
					'title'       => __( 'Company registration field alternative ID', 'woocommerce-byjuno' ) . '<br/><a class="fancybox" data-type="video" href="' . BYJUNOURL . 'admin/assets/img/gender.mp4" style="cursor:pointer">' . __( 'Check how to get the field ID', 'woocommerce-byjuno' ) . '</a>',
					'type'        => 'text',
					'description' => __( 'If your checkout page already uses a company registration field, add the ID here.', 'woocommerce-byjuno' ),
					'default'     => '',
					'desc_tip'    => true,
				),

				'company_reg_field_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_installments = array(

				'installments_description' => array(
					'title'       => __( 'Installments settings', 'woocommerce-byjuno' ),
					'description' => __( 'Please check the your contract with Byjuno AG before activation', 'woocommerce-byjuno' ),
					'type'        => 'title'
				),

				'use_installments' => array(
					'title'       => __( 'Use installments', 'woocommerce-byjuno' ),
					'description' => __( 'Allows the customer to choose on checkout between paying in full or using installments.', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'installments_intro_text' => array(
					'title'       => __( 'Installments intro text', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => __( 'Please choose your payment plan', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'use_installments_full' => array(
					'title'       => __( 'Pay in full', 'woocommerce-byjuno' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => __( 'Enable installment pay in full', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'installments_full_for' => array(
					'title'       => __( 'Pay in full available for', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C', 'woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_full_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => __( 'Pay in full template', 'woocommerce-byjuno' ),
					'desc_tip'    => true,
				),

				'use_installments_3' => array(
					'title'       => sprintf( __( 'Pay in %s payments', 'woocommerce-byjuno' ), '3' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '3' ),
					'desc_tip'    => true,
				),

				'installments_3_for' => array(
					'title'       => sprintf( __( '%s payments available for', 'woocommerce-byjuno' ), '3' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C', 'woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_3_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '3' ),
					'desc_tip'    => true,
				),

				'use_installments_4' => array(
					'title'       => sprintf( __( 'Pay in %s payments', 'woocommerce-byjuno' ), '4' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '4' ),
					'desc_tip'    => true,
				),

				'installments_4_for' => array(
					'title'       => sprintf( __( '%s payments available for', 'woocommerce-byjuno' ), '4' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C', 'woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_4_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '4' ),
					'desc_tip'    => true,
				),

				'use_installments_12' => array(
					'title'       => sprintf( __( 'Pay in %s payments', 'woocommerce-byjuno' ), '12' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '12' ),
					'desc_tip'    => true,
				),

				'installments_12_for' => array(
					'title'       => sprintf( __( '%s payments available for', 'woocommerce-byjuno' ), '12' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C','woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_12_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '12' ),
					'desc_tip'    => true,
				),

				'use_installments_24' => array(
					'title'       => sprintf( __( 'Pay in %s payments', 'woocommerce-byjuno' ), '24' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '24' ),
					'desc_tip'    => true,
				),

				'installments_24_for' => array(
					'title'       => sprintf( __( '%s payments available for', 'woocommerce-byjuno' ), '24' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C', 'woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_24_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '24' ),
					'desc_tip'    => true,
				),

				'use_installments_36' => array(
					'title'       => sprintf( __( 'Pay in %s payments', 'woocommerce-byjuno' ), '36' ),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'checkbox',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '36' ),
					'desc_tip'    => true,
				),

				'installments_36_for' => array(
					'title'       => sprintf( __( '%s payments available for', 'woocommerce-byjuno' ), '36' ),
					'description' => '',
					'type'        => 'select',
					'options'	  => array(
						'all' => __( 'B2C & B2B', 'woocommerce-byjuno' ),
						'b2c' => __( 'B2C', 'woocommerce-byjuno' ),
						'b2b' => __( 'B2B', 'woocommerce-byjuno' ),
					),
					'default'     => '',
					'desc_tip'    => true,
				),

				'installments_36_template' => array(
					'title'       => __( 'Description (visible on the website)', 'woocommerce-byjuno' ),
					'description' => '',
					'type'        => 'textarea',
					'default'     => sprintf( __( 'Pay in %s installments', 'woocommerce-byjuno' ), '36' ),
					'desc_tip'    => true,
				),

				'installments_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_invoice_type = array(

				'invoice_type_description' => array(
					'title'       => __( 'Invoice type settings', 'woocommerce-byjuno' ),
					'type'        => 'title'
				),

				'invoice_type' => array(
					'title'       => __( 'Use invoice type', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Allow user to choose between having the invoice sent by e-mail or on paper via Post Office.', 'woocommerce-byjuno' ),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'invoice_type_intro_text' => array(
					'title'		  => __( 'Invoice type intro text', 'woocommerce-byjuno' ),
					'type'		  => 'textarea',
					'description' => __( 'The text added here will appear before the invoice type options in the payment gateway on the checkout page. Leave empty if you do not wish to provide the user with any other infos.', 'woocommerce-byjuno' ),
					'default'	  => 'Select invoice type',
					'desc_tip'	  => true
				),

				'invoice_via_email' => array(
					'title'       => __( 'Invoice sent via email template', 'woocommerce-byjuno' ),
					'type'        => 'textarea',
					'description' => __( 'You can use the {email} tag inside the template', 'woocommerce-byjuno' ),
					'default'     => __('Invoice sent via e-mail to: {email}', 'woocommerce-byjuno'),
					'desc_tip'    => true,
				),

				'invoice_via_post' => array(
					'title'       => __( 'Invoice sent via Post Office template', 'woocommerce-byjuno' ),
					'type'        => 'textarea',
					'description' => __( 'You can use the {address} tag inside the template', 'woocommerce-byjuno' ),
					'default'     => __('Invoice sent by Post (3.50 CHF per letter) to: {address}', 'woocommerce-byjuno'),
					'desc_tip'    => true,
				),

				'ui_settings_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_workflow = array(

				'workflow_description' => array(
					'title'       => __( 'Workflow settings', 'woocommerce-byjuno' ),
					'type'        => 'title'
				),

				'order_status' => array(
					'title'       => __( 'Order status', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						'processing' 	=> 'Processing',
						'on-hold' 		=> 'On Hold',
						'completed' 	=> 'Completed',
						'pending' 		=> 'Pending',
						'cancelled' 	=> 'Cancelled',
						'refunded' 		=> 'Refunded',
						'failed' 		=> 'Failed'
					),
					'description' => __( 'Default order status for orders placed with Byjuno.', 'woocommerce-byjuno' ),
					'default'     => 1,
					'desc_tip'    => true,
				),

				'postcode_field_limit' => array(
					'title'		 => __( 'Limit Post Code digits', 'woocommerce-byjuno' ),
					'description'=> __( 'Maximum allowed number of characters is 8. If you add a value greater than 8, Byjuno will not be able to process the requests', 'woocommerce-byjuno' ),
					'type'		 => 'text',
					'default'	 => '8',
					'desc_tip'	 => true
				),

				'postcode_field_numbers_only' => array(
					'title'       => __( 'Restrict Post Code to numbers', 'woocommerce-byjuno' ),
					'description' => __( 'If set to No, users will be able to input letters and special characters in the post code field.', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'allow_guests' => array(
					'title'       => __( 'Allow Guest Users', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Allow unregistered users to pay with Byjuno', 'woocommerce-byjuno' ),
					'default'     => 0,
					'desc_tip'    => true,
				),

				'allow_underage' => array(
					'title'       => __( 'Allow Underage Users', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options' => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'description' => __( 'Allow underaged users to pay with Byjuno', 'woocommerce-byjuno' ),
					'default'     => 0,
					'desc_tip'    => true
				),

				'underage_threshold' => array(
					'title'       => __( 'Underaged Threshold', 'woocommerce-byjuno' ),
					'type'        => 'text',
					'description' => __( 'The number set here will represent the maximum age for underaged. Typically this value should be 18.', 'woocommerce-byjuno' ),
					'default'     => '18',
					'desc_tip'    => true
				),

				'workflow_settings_separator' => array(
					'title'       => '',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			$formfields_multilanguage = array();

			if( in_array( 'woocommerce-byjuno-multi-language/woocommerce-byjuno-multi-language.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

				$formfields_multilanguage = array(

					'multilanguage' => array(
						'title'       => __( 'Multi Language', 'woocommerce-byjuno' ),
						'type'        => 'title',
						'description' => __( 'Translate the Byjuno fields labels', 'woocommerce-byjuno' ),
					),

					'localization_separator' => array(
						'title'       => '<a href="' . admin_url() . 'admin.php?page=byjuno_multi_language" target="_blank">Click here to open the Multi Language settings page</a>',
						'type'        => 'title',
						'description' => '<hr />'
					)

				);

			}

			$formfields_api_responses_manager = array();

			if( in_array( 'woocommerce-byjuno-api-responses-manager/woocommerce-byjuno-api-responses-manager.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

				$formfields_api_responses_manager = array(

					'api_responses_manager' => array(
						'title'       => __( 'API Responses Manager', 'woocommerce-byjuno' ),
						'type'        => 'title',
						'description' => __( 'Manage how to treat order placement depending on the codes returned by the Byjuno API', 'woocommerce-byjuno' ),
					),

					'api_responses_manager_separator' => array(
						'title'       => '<a href="' . admin_url() . 'admin.php?page=byjuno_api_responses_manager" target="_blank">Click here to open the API responses manager settings page</a>',
						'type'        => 'title',
						'description' => '<hr />'
					)

				);

			}

			$formfields_logs = array(

				'logs' => array(
					'title'       => __( 'Logs', 'woocommerce-byjuno' ),
					'type'        => 'title',
					'description' => __( 'Choose to log Byjuno activity', 'woocommerce-byjuno' ),
				),

				'logs_enable' => array(
					'title'       => __( 'Logs Enable', 'woocommerce-byjuno' ),
					'type'        => 'select',
					'options'	  => array(
						0 => __( 'No', 'woocommerce-byjuno' ),
						1 => __( 'Yes', 'woocommerce-byjuno' )
					),
					'label'		  => __( 'Enable', 'woocommerce-byjuno' ),
					'description' => __( 'Enable logging on Byjuno activity', 'woocommerce-byjuno' ),
					'default'     => '0',
					'desc_tip'    => true,
				),

				'logs_separator' => array(
					'title'       => '<a href="' . admin_url() . 'admin.php?page=byjuno_logs&subp=order_logs" target="_blank">Check Byjuno error logs</a>',
					'type'        => 'title',
					'description' => '<hr />'
				)

			);

			// $formfields = $formfields_enabled + $formfields_title_desc_instructions + $formfields_api + $formfields_admin + $formfields_gender + $formfields_birthdate + $formfields_housenumber + $formfields_company_reg + $formfields_installments + $formfields_invoice_type + $formfields_workflow  + $formfields_multilanguage + $formfields_logs;

			$formfields = apply_filters( 'wc_byjuno_form_fields_enabled', $formfields_enabled ) + 
			apply_filters( 'wc_byjuno_form_fields_title_desc_instructions', $formfields_title_desc_instructions ) + 
			apply_filters( 'wc_byjuno_form_fields_api', $formfields_api ) + 
			apply_filters( 'wc_byjuno_form_fields_admin', $formfields_admin ) + 
			apply_filters( 'wc_byjuno_form_fields_gender', $formfields_gender ) + 
			apply_filters( 'wc_byjuno_form_fields_birthdate', $formfields_birthdate ) + 
			apply_filters( 'wc_byjuno_form_fields_housenumber', $formfields_housenumber ) + 
			apply_filters( 'wc_byjuno_form_fields_company_reg', $formfields_company_reg ) + 
			apply_filters( 'wc_byjuno_form_fields_installments', $formfields_installments ) + 
			apply_filters( 'wc_byjuno_form_fields_invoice_type', $formfields_invoice_type ) + 
			apply_filters( 'wc_byjuno_form_fields_workflow', $formfields_workflow ) + 
			apply_filters( 'wc_byjuno_form_fields_multilanguage', $formfields_multilanguage ) + 
			apply_filters( 'wc_byjuno_form_fields_api_responses_manager', $formfields_api_responses_manager ) + 
			apply_filters( 'wc_byjuno_form_fields_logs', $formfields_logs );


			$formfields['error_logs'] = array(
				'title' => __( 'Error Logs', 'woocommerce-byjuno' ),
				'type'        => 'title',
				'description' => '
					<div class="open-byjuno-test">
						<a href="'.site_url().'/wp-admin/admin.php?page=byjuno_error_logs" target="_blank">' . __( 'Check Byjuno error logs', 'woocommerce-byjuno' ) . '</a>
					</div>
					<div id="byjuno-test"></div>',
			);

			$this->form_fields = apply_filters( 'wc_byjuno_form_fields', $formfields );

		}

		public function thankyou_page() {

			if ( $this->instructions ) {
				echo '<p class="byjuno-thank-you-instructions">' . wptexturize( $this->instructions ) . '</p>';
			}

		}

		public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {

			if ( $this->instructions && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status( 'on-hold' ) ) {
				echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
			}

		}

		public function process_payment( $order_id ) {

			$settings = get_option('woocommerce_byjuno_settings');
			$order_status = isset($settings['order_status']) && $settings['order_status'] ? $settings['order_status'] : 'on-hold';

			$order = wc_get_order( $order_id );

			// Mark as on-hold (we're awaiting the payment)
			$order->update_status( $order_status, __( 'Awaiting Byjuno payment', 'woocommerce-byjuno' ) );

			// Remove cart
			WC()->cart->empty_cart();

			//wc_clear_cart_after_payment();

			// Return thankyou redirect
			return array(
				'result' 	=> 'success',
				'redirect'	=> $this->get_return_url( $order )
			);

		}

	}

}
?>
