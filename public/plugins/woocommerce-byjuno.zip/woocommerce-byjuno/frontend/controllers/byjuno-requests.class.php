<?php

use WPO\WC\PDF_Invoices\Documents;

/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}


function disable_directly_byjuno_gateway( $gateways ) {
	unset( $gateways['byjuno'] );
	return $gateways;
}


$requests = new ByjunoRequests;

add_action( 'woocommerce_checkout_update_order_meta', array($requests, 's3'), 20, 2 );
// add_action( 'woocommerce_before_pay_action', array($requests, 's3'), 20 );
add_action( 'woocommerce_order_status_completed', array($requests, 'process_s4'), 1 );
add_action( 'woocommerce_order_status_cancelled', array($requests, 's5'), 10, 1 );
// add_action( 'woocommerce_order_status_refunded', array($requests, 's5'), 10, 1 );
add_action( 'wp_ajax_s5_partial', array($requests, 's5') );
add_action( 'wp_ajax_nopriv_s5_partial', array($requests, 's5') );

class ByjunoRequests {

	var $views, $byjunosettings;

	function __construct() {

		$this->views = new ByjunoViews;
		$this->byjunosettings = byjuno_settings();

	}

	function client_ip() {

		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
    	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
      		$ip = $_SERVER['REMOTE_ADDR'];
    	}

		return $ip;

	}

	function s1_s2( $customer = null, $order = null ) {

		global $woocommerce, $wpdb;

		$checkout 	= WC()->checkout;
		$session 	= WC()->session;
		$cart 		= WC()->cart;

		$userid = byjuno_logged_in_user_id();

		$byjunosettings = $this->byjunosettings;

		$checkmode = $byjunosettings['mode'];
		$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/response.cfm' : $posturl = '/services/creditCheckDACH_01_41/response.cfm';

		$byjunorequestno = ( isset( $session ) && $session->get_customer_id() ) ? $wpdb->get_var("SELECT session_id FROM {$wpdb->prefix}woocommerce_sessions WHERE session_key='{$session->get_customer_id()}'") : rand(101, 302);

		if( ! $byjunorequestno ) {
			$byjunorequestno = rand(101, 302);
		}

		$orderid 			= $byjunorequestno;
		$shopname 			= str_replace( ' ', '', strtolower( get_bloginfo('name') ) );
		$byjunocustomerref 	= $shopname . '_' . $byjunorequestno;
		$byjunorequest 		= $shopname . '_request_' . $byjunorequestno;
		$byjunothmetrix		= $session->get('byjuno_threatmetrix_sessionid') ? $session->get('byjuno_threatmetrix_sessionid') : md5( get_bloginfo('name') . get_current_user_id() . date('Y-m-d H:i:s') );

		$has_gender = $byjunosettings['use_gender_field'];
		if( $has_gender ) {
			$gender_field_alt_id = $byjunosettings['gender_field_alt_id'];
			if( $gender_field_alt_id ) {
				$gender_female_value = $byjunosettings['gender_field_alt_id_female_value'];
				$gender_male_value = $byjunosettings['gender_field_alt_id_male_value'];
				$gender_field_value = isset( $customer[ $gender_field_alt_id ] ) && $customer[ $gender_field_alt_id ] ? $customer[ $gender_field_alt_id ] : $customer['billing_user-gender'];
				if( $gender_female_value && ( $gender_field_value == $gender_female_value ) ) {
					$gender_field_value = '2';
				}
				if( $gender_male_value && ( $gender_field_value == $gender_male_value ) ) {
					$gender_field_value = '1';
				}
			} else {
				$gender_field_value = $customer['billing_user-gender'];
			}
		} else {
			$gender_field_value = $customer['billing_user-gender'];
		}

		$gender = $gender_field_value;

		$has_birthdate = $byjunosettings['use_birthdate_field'];
		if( $has_birthdate ) {
			$birthdate_field_alt_id = $byjunosettings['birthdate_field_alt_id'];
			if( $birthdate_field_alt_id ) {
				$birthdate_field_value = isset( $customer[ $birthdate_field_alt_id ] ) && $customer[ $birthdate_field_alt_id ] ? $customer[ $birthdate_field_alt_id ] : $customer['billing_user-birthdate'];
			} else {
				switch( $byjunosettings['birthdate_field_type'] ) {
					case '1': default:
						$birthdate_field_value = $customer['billing_user-birthdate-year'] . '-' . $customer['billing_user-birthdate-month'] . '-' . $customer['billing_user-birthdate-day'];
					break;
					case '2':
						$birthdate_field_value = $customer['billing_user-birthdate'];
					break;
				}
			}
		}

		$birthday = $birthdate_field_value;

		$has_houseno = $byjunosettings['use_houseno_field'];
		if( $has_houseno ) {
			$houseno_field_alt_id = $byjunosettings['houseno_field_alt_id'];
			if( $houseno_field_alt_id ) {
				$houseno_field_value = isset( $customer[ $houseno_field_alt_id ] ) && $customer[ $houseno_field_alt_id ] ? $customer[ $houseno_field_alt_id ] : $customer['billing_houseno'];
			} else {
				$houseno_field_value = $customer['billing_houseno'];
			}
		}

		$houseno = isset( $houseno_field_value ) && $houseno_field_value ? $houseno_field_value : '';

		$has_company_reg = $byjunosettings['use_company_reg_field'] ? intval( $byjunosettings['use_company_reg_field'] ) : 0;

		$customer_type = $billing_company = '';
		if( $order ) {
			$billing_company = $order->get_billing_company();
			$customer_type = $billing_company && $has_company_reg ? 'b2b' : 'b2c';
		} else {
			$billing_company = isset( $customer['billing_company'] ) && $customer['billing_company'] ? $customer['billing_company'] : '';
			$customer_type = $billing_company && $has_company_reg ? 'b2b' : 'b2c';
		}

		if( $customer_type == 'b2b' ) {
			if( $has_company_reg ) {
				$company_reg_field_alt_id = $byjunosettings['company_reg_field_alt_id'];
				if( $company_reg_field_alt_id ) {
					$company_reg_field_value = isset( $customer[ $company_reg_field_alt_id ] ) && $customer[ $company_reg_field_alt_id ] ? $customer[ $company_reg_field_alt_id ] : $customer['billing_company_reg'];
				} else {
					$company_reg_field_value = $customer['billing_company_reg'];
				}
			}
		} else {
			$company_reg_field_value = '';
		}

		$company_reg = $company_reg_field_value;

		if( $has_gender && ! $gender || $has_birthdate && ! $birthday ) return false;

		if( $order ) {

			$billing_firstname	 = $order->get_billing_first_name();
			$billing_lastname 	 = $order->get_billing_last_name();
			// $billing_company	 = $customer['billing_company'];
			$billing_company_reg = $company_reg;
			$billing_address_1	 = $order->get_billing_address_1();
			$billing_address_2	 = $order->get_billing_address_2();
			$billing_address 	 = $billing_address_1 . ' ' . $billing_address_2;
			$billing_country 	 = $order->get_billing_country();
			$billing_housenumber = $houseno;
			$billing_postcode 	 = $order->get_billing_postcode();
			$billing_city 		 = $order->get_billing_city();
			$billing_phone 		 = $order->get_billing_phone();
			$billing_email 		 = $order->get_billing_email();

			$shipping_firstname  = $order->get_shipping_first_name();
			$shipping_firstname  = $shipping_firstname ? $shipping_firstname : $billing_firstname;

			$shipping_lastname   = $order->get_shipping_last_name();
			$shipping_lastname   = $shipping_lastname ? $shipping_lastname : $billing_lastname;
			
			$shipping_company	 = $order->get_shipping_company();
			$shipping_company    = $shipping_company ? $shipping_company : $billing_company;

			$shipping_address_1  = $order->get_shipping_address_1();
			$shipping_address_1  = $shipping_address_1 ? $shipping_address_1 : $billing_address_1;

			$shipping_address_2  = $order->get_shipping_address_2();
			$shipping_address_2  = $shipping_address_2 ? $shipping_address_2 : $billing_address_2;

			$shipping_address	 = $shipping_address_1 . ' ' . $shipping_address_2;

			$shipping_country	 = $order->get_shipping_country();
			$shipping_country	 = $shipping_country ? $shipping_country : $billing_country;
			
			if( isset( $byjunosettings['use_houseno_field'] ) ) {
				$shipping_housenumber = $customer['shipping_houseno'] ? $customer['shipping_houseno'] : $houseno;
			}

			$shipping_postcode   = $order->get_shipping_postcode();
			$shipping_postcode	 = $shipping_postcode ? $shipping_postcode : $billing_postcode;
			
			$shipping_city		 = $order->get_shipping_city();
			$shipping_city		 = $shipping_city ? $shipping_city : $billing_city;

			$ordertotal  = $order->get_total();

		} else {

			$billing_firstname	 = $customer['billing_first_name'];
			$billing_lastname 	 = $customer['billing_last_name'];
			// $billing_company	 = $customer['billing_company'];
			$billing_company_reg = $company_reg;
			$billing_address 	 = $customer['billing_address_1'];
			$billing_country 	 = $customer['billing_country'];
			$billing_housenumber = $houseno;
			$billing_postcode 	 = $customer['billing_postcode'];
			$billing_city 		 = $customer['billing_city'];
			$billing_phone 		 = $customer['billing_phone'];
			$billing_email 		 = $customer['billing_email'];

			$shipping_firstname  = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_first_name'] ) ? $customer['shipping_first_name'] : $customer['billing_first_name'];
			$shipping_lastname   = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_last_name'] ) ? $customer['shipping_last_name'] : $customer['billing_last_name'];
			$shipping_company    = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_company'] ) ? $customer['shipping_company'] : $customer['billing_company'];
			$shipping_address    = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_address_1'] ) ? $customer['shipping_address_1'] : $customer['billing_address_1'];
			$shipping_country    = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_country'] ) ? $customer['shipping_country'] : $customer['billing_country'];
			if(isset($byjunosettings['use_houseno_field'])) {
				$shipping_housenumber = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_houseno'] ) ? $customer['shipping_houseno'] : $houseno;
			}
			$shipping_postcode   = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_postcode'] ) ? $customer['shipping_postcode'] : $customer['billing_postcode'];
			$shipping_city       = ( isset( $customer['ship_to_different_address'] ) && $customer['ship_to_different_address'] && $customer['shipping_city'] ) ? $customer['shipping_city'] : $customer['billing_city'];

			$ordertotal  = $session->get('cart_totals');
			$ordertotal  = $ordertotal['total'];

		}

		$customercategory = byjuno_get_customer_category();

		$data = array();

		$data['byjuno'] = array(
			'clientid' 	=> $byjunosettings['client_id'],
			'email' 	=> $byjunosettings['technical_contact'],
			'user' 		=> $byjunosettings['user_id'],
			'pass' 		=> $byjunosettings['password'],
			'request' 	=> $byjunorequest,
			'ref' 		=> $byjunocustomerref,
			'orderid' 	=> $orderid,
			'customer_type' => $customer_type,
			'id_prefix' => $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
		);

		$data['user'] = array(
			'billing_firstname' => $billing_firstname,
			'billing_lastname'	=> $billing_lastname,
			'billing_company'   => $billing_company,
			'billing_company_reg' => $billing_company_reg,
			'billing_country'	=> $billing_country,
			'billing_address' 	=> $billing_address,
			'billing_houseno'	=> $billing_housenumber,
			'billing_postcode' 	=> $billing_postcode,
			'billing_city' 		=> $billing_city,
			'shipping_firstname'=> $shipping_firstname,
			'shipping_lastname'	=> $shipping_lastname,
			'shipping_company'  => $shipping_company,
			'shipping_country'	=> $shipping_country,
			'shipping_address' 	=> $shipping_address,
			'shipping_houseno'	=> $shipping_housenumber,
			'shipping_postcode' => $shipping_postcode,
			'shipping_city' 	=> $shipping_city,
			'phone' 			=> $billing_phone,
			'email' 			=> $billing_email,
			'gender' 			=> $gender,
			'birthday' 			=> date( 'Y-m-d', strtotime( $birthday ) ),
			'ordertotal' 		=> $ordertotal,
			'currency'			=> get_woocommerce_currency(),
			'customercategory' 	=> $customercategory,
			'thmetrix'			=> $byjunothmetrix,
			'ip'				=> $this->client_ip()
		);

		$userfields = $data['user'];
		if( isset($byjunosettings['use_gender_field'] ) && ! $byjunosettings['use_gender_field'] ) {
			unset( $userfields['gender'] );
		}

		if( isset( $byjunosettings['use_birthdate_field'] ) && ! $byjunosettings['use_birthdate_field'] ) {
			unset( $userfields['birthday'] );
		}

		if( isset($byjunosettings['use_houseno_field'] ) && ! $byjunosettings['use_houseno_field']) {
			unset( $userfields['billing_houseno'] );
			unset( $userfields['shipping_houseno'] );
		}

		unset( $userfields['phone'] );
		unset( $userfields['email'] );

		$valid = 1;

		foreach( $userfields as $id => $value ) {

			if( $id == 'billing_company' || $id == 'billing_company_reg' || $id == 'shipping_company' || $id == 'billing_country' || $id == 'shipping_country' )
				continue;

			if( !$value ) {
				$valid = 0;
				break;
			}

		}

		if( ! $valid) return;

		switch( $customer_type ) {

			case 'b2c':
				$request = $this->views->s1_s2($data);
			break;
			case 'b2b':
				$request = $this->views->s1_s2_b2b($data);
			break;
			default:
				$request = $this->views->s1_s2($data);

		}

		$requestdata = array(
			'request' 			=> $request,
			'request_data'		=> $data['user'],
			'request_no'		=> $byjunorequestno,
			'posturl'			=> $posturl,
			'return_response' 	=> true,
			'step'				=> 's1_s2',
			'byjunorequest'		=> $byjunorequest,
			'byjunocustomerref'	=> $byjunocustomerref
		);

		try {

			$response 			= byjuno_send_request($requestdata);
			$decisionnumber 	= strval($response->Customer->DecisionProcessNumber);
			$transactionnumber 	= strval($response->Customer->TransactionNumber);
			$decisionprocessnumber = strval($response->Customer->DecisionProcessNumber);

			update_user_meta($userid, 'reqno', $byjunorequestno);
			update_user_meta($userid, 'current-order-transaction-number', $transactionnumber);

			$returncode = $response->Customer->RequestStatus[0] ? intval( $response->Customer->RequestStatus[0] ) : 0;
			$creditrating = $response->Customer->CreditRating[0];
			$valid_codes = array(2);

			if ( in_array( 'woocommerce-byjuno-api-responses-manager/woocommerce-byjuno-api-responses-manager.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
				$wbapirm_codes = get_option( 'wbapirm_codes' );
				if( $wbapirm_codes ) {
					$valid_codes = array_merge( $valid_codes, $wbapirm_codes );
				}
			}

			if( in_array( $returncode, $valid_codes ) ) {

				$session->set( 'byjuno_code', strval($returncode) );
				$session->set( 'byjuno_thmetrix_number', $byjunothmetrix );
				$session->set( 'byjuno_request_number', $byjunorequestno );
				$session->set( 'byjuno_transaction_number', $transactionnumber );
				$session->set( 'byjuno_decision_process_number', $decisionnumber );
				$session->set( 'byjuno_credit_rating', strval($creditrating) );
				$session->set( 'byjuno_customer_type', $customer_type );
				$session->set( 'byjuno_installments_type', isset( $customer['byjuno-installments-type'] ) ? $customer['byjuno-installments-type'] : '' );

				return $returncode;

			}

		} catch (Exception $e) {

			$sessionparams = array('byjuno_code', 'byjuno_thmetrix_number', 'byjuno_request_number', 'byjuno_transaction_number', 'byjuno_decision_process_number', 'byjuno_credit_rating', 'byjuno_customer_type', 'byjuno_installments_type');
			foreach($sessionparams as $sessionparam) {
				$session->__unset( $sessionparam );
			}

		}

	}

	function s3( $orderid, $data = array() ) {

		$paymentmethod = get_post_meta($orderid, '_payment_method', true);
		$sent_s3 = get_post_meta( $orderid, 'sent_s3', 1 );

		if( $paymentmethod == 'byjuno' && ! $sent_s3 ) {

			$byjunosettings = $this->byjunosettings;

			$session = WC()->session;

			$orderid = is_numeric( $orderid ) ? $orderid : $orderid->get_id();

			$paymentmethod   = get_post_meta($orderid, '_payment_method', true);
			$sent3 			 = get_post_meta($orderid, 'sent_s3', true);
			$billing_company = get_post_meta($orderid, '_billing_company', true);

			$byjunorequestno = get_post_meta($orderid, '_billing_reqno', true);
			if( ! $byjunorequestno ) {
				$byjunorequestno = $session->get( 'byjuno_request_number' );
			}

			if( $byjunorequestno ) {
				update_post_meta( $orderid, '_billing_reqno', $byjunorequestno );
			}

			global $woocommerce, $wpdb;

			$byjuno_code = $session->get( 'byjuno_code' );

			$has_company_reg = $byjunosettings['use_company_reg_field'] ? intval( $byjunosettings['use_company_reg_field'] ) : 0;

			$customer_type = $billing_company && $has_company_reg ? 'b2b' : 'b2c';

			update_post_meta( $orderid, '_billing_customer_type', $customer_type );
			update_post_meta( $orderid, '_billing_byjuno_code', $byjuno_code );
			update_post_meta( $orderid, '_billing_thmetrix_number', $session->get( 'byjuno_thmetrix_number' ) );
			update_post_meta( $orderid, '_billing_reqno', $session->get( 'byjuno_request_number' ) );
			update_post_meta( $orderid, '_billing_trno', $session->get( 'byjuno_transaction_number' ) );
			update_post_meta( $orderid, '_billing_dpno', $session->get( 'byjuno_decision_process_number' ) );
			update_post_meta( $orderid, '_billing_credit_rating', $session->get( 'byjuno_credit_rating' ) );

			$userid = byjuno_logged_in_user_id();
			$birthdate = get_post_meta( $orderid, '_billing_user-birthdate', true );

			$shopname 			= str_replace( ' ', '', strtolower( get_bloginfo('name') ) );
			$byjunocustomerref 	= $shopname . '_' . $byjunorequestno;
			$byjunorequest 		= $shopname . '_request_' . $byjunorequestno;

			$checkmode = $byjunosettings['mode'];
			$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/response.cfm' : $posturl = '/services/creditCheckDACH_01_41/response.cfm';

			if($byjuno_code == 5 || $byjuno_code == 7 || $byjuno_code == 10 || $byjuno_code == 28) {
				$riskowner = 'CLIENT';
			} else {
				$riskowner = 'IJ';
			}

			$paymentmethodtype = 'INVOICE';
			$repaymenttype = '4';

			if( $customer_type == 'b2b' ) {
				$repaymenttype = '3';
			}

			if( $byjunosettings['allow_underage'] == 1 ) {

				if($byjuno_code == 2 || $byjuno_code == 8) {

					$threshold = $byjunosettings['underage_threshold'];
					$birthdate_year = date( 'Y', strtotime($birthdate) );
					$years_diff = intval( date('Y') ) - intval( $birthdate_year );

					if( $years_diff <= $threshold ) {
						//Client is underaged
						$riskowner = 'IJ';
						$repaymenttype = '3';
					}

				}

			}

			$installment_type = get_post_meta( $orderid, '_billing_installment_type', true );

			if( ! $installment_type ) {
				$installment_type = $session->get('byjuno_installments_type');
			}

			if( $installment_type ) {

				$repayment_types = array(
					'1_b2c'  => 4,
					'1_b2b'  => 3,
					'3_b2c'  => 10,
					'12_b2c' => 8,
					'24_b2c' => 9
				);

				$repaymenttype = $repayment_types[ $installment_type . '_' . $customer_type ];

				$paymentmethodtype = $installment_type == '1' ? 'INVOICE' : 'INSTALLMENT';

			}

			$data = array();

			$data['byjuno'] = array(
				'clientid' 		=> $byjunosettings['client_id'],
				'email' 		=> $byjunosettings['technical_contact'],
				'user' 			=> $byjunosettings['user_id'],
				'pass' 			=> $byjunosettings['password'],
				'request' 		=> $byjunorequest,
				'ref' 			=> $byjunocustomerref,
				'paper_inv' 	=> get_post_meta($orderid, '_billing_paper_invoice', true) ? get_post_meta($orderid, '_billing_paper_invoice', true) : 'NO',
				'riskowner' 	=> $riskowner,
				'repaymenttype' => $repaymenttype,
				'paymentmethod' => $paymentmethodtype,
				'customer_type' => isset( $customertype ) && $customertype ? $customertype : '',
				'id_prefix' 	=> $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
			);

			$paper_invoice = get_post_meta($orderid, '_billing_paper_invoice', true);
			if( ! $paper_invoice ) {
				$paper_invoice = 'NO';
			}

			$data['user'] = array(
				'orderid'			=> byjuno_order_id( $orderid ),
				'billing_firstname' => get_post_meta($orderid, '_billing_first_name', true),
				'billing_lastname' 	=> get_post_meta($orderid, '_billing_last_name', true),
				'billing_company'   => get_post_meta($orderid, '_billing_company', true),
				'billing_company_reg' => get_post_meta($orderid, '_billing_company_reg', true),
				'billing_address' 	=> rtrim( get_post_meta($orderid, '_billing_address_1', true) . ' ' . get_post_meta($orderid, '_billing_address_2', true), ' '),
				'billing_houseno'	=> get_post_meta($orderid, '_billing_houseno', true),
				'billing_postcode' 	=> get_post_meta($orderid, '_billing_postcode', true),
				'billing_city' 		=> get_post_meta($orderid, '_billing_city', true),
				'shipping_firstname'=> get_post_meta($orderid, '_shipping_first_name', true),
				'shipping_lastname'	=> get_post_meta($orderid, '_shipping_last_name', true),
				'shipping_country'	=> get_post_meta($orderid, '_shipping_country', true),
				'shipping_address' 	=> rtrim( get_post_meta($orderid, '_shipping_address_1', true) . ' ' . get_post_meta($orderid, '_shipping_address_2', true), ' '),
				'shipping_houseno'	=> get_post_meta($orderid, '_shipping_houseno', true),
				'shipping_postcode' => get_post_meta($orderid, '_shipping_postcode', true),
				'shipping_city' 	=> get_post_meta($orderid, '_shipping_city', true),
				'phone' 			=> get_post_meta($orderid, '_billing_phone', true),
				'email' 			=> get_post_meta($orderid, '_billing_email', true),
				'gender' 			=> get_post_meta($orderid, '_billing_user-gender', true),
				'birthday' 			=> date('Y-m-d', strtotime($birthdate)),
				'ordertotal' 		=> get_post_meta($orderid, '_order_total', true),
				'transactionnumber' => get_post_meta($orderid, '_billing_trno', true),
				'customercategory' 	=> byjuno_get_customer_category(),
				'paper_invoice'		=> $paper_invoice,
				'currency'			=> get_woocommerce_currency(),
				'ip'				=> $this->client_ip()
			);

			switch( $customer_type ) {

				case 'b2c':
					$request = $this->views->s3($data);
				break;
				case 'b2b':
					$request = $this->views->s3_b2b($data);
				break;
				default:
					$request = $this->views->s3($data);

			}

			$requestdata = array(
				'order_id'			=> $orderid,
				'request' 			=> $request,
				'posturl'			=> $posturl,
				'request_data'		=> $data['user'],
				'return_response' 	=> true,
				'step'				=> 's3',
				'byjunorequest'		=> $byjunorequest,
				'byjunocustomerref'	=> $byjunocustomerref
			);

			try {

				$sessionparams = array('byjuno_code', 'byjuno_thmetrix_number', 'byjuno_request_number', 'byjuno_transaction_number', 'byjuno_decision_process_number', 'byjuno_credit_rating', 'byjuno_customer_type', 'byjuno_installments_type');
				foreach($sessionparams as $sessionparam) {
					$hasparam = $session->get($sessionparam);
					if( $hasparam ) {
						$session->__unset( $sessionparam );
					}
				}

				$response = byjuno_send_request($requestdata);
				$returncode = $response->Customer->RequestStatus[0] ? intval( $response->Customer->RequestStatus[0] ) : 0;

				update_post_meta($orderid, '_billing_byjuno_s3_code', $returncode);

				$valid_codes = array(2);

				if ( in_array( 'woocommerce-byjuno-api-responses-manager/woocommerce-byjuno-api-responses-manager.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
					$wbapirm_codes = get_option( 'wbapirm_codes' );
					if( $wbapirm_codes ) {
						$valid_codes = array_merge( $valid_codes, $wbapirm_codes );
					}
				}

				if( in_array( $returncode, $valid_codes ) ) {

					if( $userid ) {
						delete_user_meta( $userid, 'billing_company' );
						delete_user_meta( $userid, 'shipping_company' );
					}

					update_post_meta($orderid, 'byjuno_customer_reference', $byjunocustomerref);
					update_post_meta($orderid, 'initial_total', get_post_meta($orderid, '_order_total', true));
					update_post_meta($orderid, 'byjuno_request_id', $byjunorequest);
					update_post_meta($orderid, 'sent_s3', 1);
					if( class_exists('WooCommerce_Ext_PrintOrders') ) {
						add_filter( 'woocommerce_print_orders_print_order_upon_processed', function($print, $order) {
							return true;
						}, 10, 2);
					}

				} else {
					update_post_meta( $orderid, 'cancel_order_byjuno_s3_failure', '1' ); //Order will get cancelled
					wc_add_notice( '<span class="byjuno_not_available_notice" style="font-weight:normal">' . $byjunosettings['unavailable'] . '</span>', 'error' );
				}

			} Catch (Exception $e) {

				echo 'Error! ',  $e->getMessage(), "\n";

			}

		}

	}

	function s3_included_in_s1_s2( $data ) {

		$session = WC()->session;

		$postdata = $_POST;

		global $woocommerce, $wpdb;

		$billing_company = $data['order']['billing_company'];
		$customer_type 	 = $data['order']['customer_type'];

		$byjunorequestno = $data['order']['request_number'];

		$byjuno_code = $data['order']['s1_s2_code'];

		$userid = byjuno_logged_in_user_id();
		$birthdate = $data['order']['birthday'];

		$byjunosettings = $this->byjunosettings;

		$shopname 			= str_replace( ' ', '', strtolower( get_bloginfo('name') ) );
		$byjunocustomerref 	= $shopname . '_' . $byjunorequestno;
		$byjunorequest 		= $shopname . '_request_' . $byjunorequestno;

		$checkmode = $byjunosettings['mode'];
		$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/response.cfm' : $posturl = '/services/creditCheckDACH_01_41/response.cfm';

		if($byjuno_code == 5 || $byjuno_code == 7 || $byjuno_code == 10 || $byjuno_code == 28) {
			$riskowner = 'CLIENT';
		} else {
			$riskowner = 'IJ';
		}

		$paymentmethodtype = 'INVOICE';
		$repaymenttype = '4';

		if( $customer_type == 'b2b' ) {
			$repaymenttype = '3';
		}

		if( $byjunosettings['allow_underage'] == 1 ) {

			if($byjuno_code == 2 || $byjuno_code == 8) {

				$threshold = $byjunosettings['underage_threshold'];
				$birthdate_year = date( 'Y', strtotime($birthdate) );
				$years_diff = intval( date('Y') ) - intval( $birthdate_year );

				if( $years_diff <= $threshold ) {
					//Client is underaged
					$riskowner = 'IJ';
					$repaymenttype = '3';
				}

			}

		}

		$installment_type = $data['order']['installment_type'];

		if( $installment_type ) {

			$repayment_types = array(
				'1_b2c'  => 4,
				'1_b2b'  => 3,
				'3_b2c'  => 10,
				'12_b2c' => 8,
				'24_b2c' => 9
			);

			$repaymenttype = $repayment_types[ $installment_type . '_' . $customer_type ];

			$paymentmethodtype = $installment_type == '1' ? 'INVOICE' : 'INSTALLMENT';

		}

		$data['byjuno'] = array(
			'clientid' 		=> $byjunosettings['client_id'],
			'email' 		=> $byjunosettings['technical_contact'],
			'user' 			=> $byjunosettings['user_id'],
			'pass' 			=> $byjunosettings['password'],
			'request' 		=> $byjunorequest,
			'ref' 			=> $byjunocustomerref,
			'paper_inv' 	=> isset( $data['invoice_type'] ) && $data['invoice_type'] ? $data['invoice_type'] : 'NO',
			'riskowner' 	=> $riskowner,
			'repaymenttype' => $repaymenttype,
			'paymentmethod' => $paymentmethodtype,
			'customer_type' => $customer_type,
			'id_prefix' 	=> $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
		);

		$paper_invoice = isset( $data['invoice_type'] ) && $data['invoice_type'] ? $data['invoice_type'] : 'NO';

		$userdata = $data['user'];
		$userdata['user']['paper_invoice'] = isset( $data['invoice_type'] ) && $data['invoice_type'] ? $data['invoice_type'] : 'NO';
		$userdata['user']['transactionnumber'] = $data['order']['transaction_number'];

		$data['user'] = $userdata; //s1_s2 -- ~ Line 391

		switch( $customer_type ) {

			case 'b2c':
				$request = $this->views->s3($data);
			break;
			case 'b2b':
				$request = $this->views->s3_b2b($data);
			break;
			default:
				$request = $this->views->s3($data);

		}

		$requestdata = array(
			'request' 			=> $request,
			'posturl'			=> $posturl,
			'return_response' 	=> true,
			'step'				=> 's3',
			'byjunorequest'		=> $byjunorequest,
			'byjunocustomerref'	=> $byjunocustomerref
		);

		try {

			$response = byjuno_send_request($requestdata);

			$returncode = $response->Customer->RequestStatus[0];

			if( $userid ) {
				delete_user_meta( $userid, 'billing_company' );
				delete_user_meta( $userid, 'shipping_company' );
			}

			$session->set( 'byjuno_customer_reference', $byjunocustomerref );
			$session->set( 'initial_total', $data['order']['total'] );
			$session->set( 'byjuno_request_id', $byjunorequest );
			$session->set( 'sent_s3', 1 );

			if( class_exists('WooCommerce_Ext_PrintOrders') ) {
				add_filter( 'woocommerce_print_orders_print_order_upon_processed', function($print, $order) {
					return true;
				}, 10, 2);
			}
			if( $returncode != 2 ) {
				update_post_meta( $orderid, 'cancel_order_byjuno_s3_failure', '1' );
			}

			return $returncode;

		} Catch (Exception $e) {

			echo 'Error! ',  $e->getMessage(), "\n";

		}

	}

	function process_s4($order) {

		$orderid = $order;
		$order = wc_get_order($orderid);

		$this->s4($order, $orderid);

	}

	function s4( $order = null, $orderid = null ) {

		global $post, $woocommerce, $wpdb;

		$orderid = ! $orderid ? $_POST['orderid'] : $orderid;
		$order = ! $order ? wc_get_order( $orderid ) : $order;

		$paymentmethod = get_post_meta($orderid, '_payment_method', true);
		$sent_s4 = get_post_meta( $orderid, 'sent_s4', 1 );

		if($paymentmethod == 'byjuno' && ! $sent_s4) {

			update_post_meta( $orderid, 's4_sent', 1 );

			$userid 			= byjuno_logged_in_user_id();

			$byjunosettings 	= $this->byjunosettings;

			$byjunomerchant 	= $byjunosettings['merchant_id'];

			$byjunorequestno	= get_post_meta( $orderid, '_billing_reqno', true );
			$shopname 			= str_replace( ' ', '', strtolower( get_bloginfo('name') ) );
			$byjunocustomerref 	= $shopname . '_' . $byjunorequestno;
			$byjunorequest 		= $shopname . '_request_' . $byjunorequestno;

			$checkmode = $byjunosettings['mode'];
			$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/sendTransaction.cfm' : $posturl = '/services/creditCheckDACH_01_41/sendTransaction.cfm';
			$checkmode == 'Test' ? $byjunoemail = 'test-invoices@byjuno.ch' : $byjunoemail = 'invoices@byjuno.ch';

			$total_refunds = 0.00;
			foreach( $order->get_refunds() as $refund ) {
				$total_refunds += abs( floatval( $refund->get_amount() ) );
			}

			$order_total = floatval( get_post_meta( $orderid, '_order_total', true ) ) - floatval( $total_refunds );

			$data = array();

			$data['byjuno'] = array(
				'clientid' 	=> $byjunosettings['client_id'],
				'email' 	=> $byjunosettings['technical_contact'],
				'user' 		=> $byjunosettings['user_id'],
				'pass' 		=> $byjunosettings['password'],
				'request' 	=> $byjunorequest,
				'ref' 		=> $byjunocustomerref,
				'id_prefix' => $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
			);

			$data['order'] = array(
				'id'		=> byjuno_order_id( $orderid ),
				'date' 		=> date('Y-m-d', strtotime($wpdb->get_var("SELECT post_date FROM {$wpdb->prefix}posts WHERE ID={$orderid}"))),
				'total' 	=> $order_total,
				'currency' 	=> get_post_meta( $orderid, '_order_currency', true )
			);

			$request = $this->views->s4( $data );

			$requestdata = array(
				'order_id'			=> $orderid,
				'request' 			=> $request,
				'posturl'			=> $posturl,
				'return_response' 	=> true,
				'step'				=> 's4',
				'byjunorequest'		=> $byjunorequest,
				'byjunocustomerref'	=> $byjunocustomerref
			);

			try {

				$response = byjuno_send_request( $requestdata );

				$description = $response->Transaction->ProcessingInfo->Description;
				$description = preg_replace('/\s+/', '', $description);

				update_post_meta( $orderid, 'sent_s4', 1 );

				if(class_exists('WPO_WCPDF')) {

					global $wpo_wcpdf;

					$pdfplugin = new WPO_WCPDF;

					$tmp_path = $pdfplugin->plugin_path() . '/tmp/';
					if(!is_dir($tmp_path)) {
						mkdir($tmp_path, 0777);
					}
					array_map('unlink', ( glob( $tmp_path.'*' ) ? glob( $tmp_path.'*' ) : array() ) );

					// create invoice pdf data
					$invoice = $wpo_wcpdf->export->get_pdf( 'invoice', (array) $orderid );
					$theorder = new WC_Order($orderid);

					$pdf_filename = __( 'invoice', BYJUNODOMAIN ) . '-' . $orderid . '.pdf';
					$pdf_path = $tmp_path . $pdf_filename;
					file_put_contents ( $pdf_path, $invoice );
					$attachmentsinvoice[] = $pdf_path;
					// end of create invoice pdf data

				}

				$to				= $byjunosettings['technical_contact'];
				$subjectinvoice	= 'Neue Bestellung | Merchant: '.$byjunomerchant.' | OrderId: '.$orderid.' | InvoiceNo: INV'.$orderid;
				$message 		= '&nbsp;';
				$headers		= 'From: '.get_bloginfo('name').'<'.$to.'>' . "\r\nContent-type: text/html\r\n";

				wp_mail( $byjunoemail, $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null );

				if(
					isset( $byjunosettings['technical_contact'] ) && $byjunosettings['technical_contact'] &&
					isset( $byjunosettings['receive_system_emails'] ) && $byjunosettings['receive_system_emails']
				) {
					wp_mail( $byjunosettings['technical_contact'], $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null );
				}

				// $this->s5_partial($orderid);

			} Catch (Exception $e) {

				echo 'Error! ',  $e->getMessage(), "\n";

			}

		}

	}

	function s5_partial( $orderid = null ) {

		global $woocommerce, $wpdb;

		$paymentmethod = get_post_meta($orderid, '_payment_method', true);

		if($paymentmethod == 'byjuno') {

			!$orderid ? $orderid = (int)$_GET['post'] : $orderid = (int)$orderid;

			$ordertotal 	= get_post_meta($orderid, '_order_total', true);
			$initialtotal 	= get_post_meta($orderid, 'initial_total', true);

			if( $ordertotal != $initialtotal && floatval( $initialtotal ) > floatval( $ordertotal ) ) {

				$userid 			= get_current_user_id();
				$difference 		= floatval( $initialtotal ) - floatval( $ordertotal );

				$byjunosettings 	= $this->byjunosettings;

				$byjunomerchant 	= $byjunosettings['merchant_id'];
				$byjunocustomerref 	= get_post_meta( $orderid, 'byjuno_customer_reference', true );
				if( ! $byjunocustomerref ) {
					$byjunocustomerref = strtolower( str_replace( ' ', '', get_bloginfo('name') ) );
				}
				$byjunorequest 		= get_post_meta( $orderid, 'byjuno_request_id', true );

				$checkmode 			= $byjunosettings['mode'];
				$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/sendTransaction.cfm' : $posturl = '/services/creditCheckDACH_01_41/sendTransaction.cfm';
				$checkmode == 'Test' ? $byjunoemail = 'test-invoices@byjuno.ch' : $byjunoemail = 'invoices@byjuno.ch';

				$data = array();

				$data['byjuno'] = array(
					'clientid' 	=> $byjunosettings['client_id'],
					'email' 	=> $byjunosettings['technical_contact'],
					'user' 		=> $byjunosettings['user_id'],
					'pass' 		=> $byjunosettings['password'],
					'request' 	=> $byjunorequest,
					'ref' 		=> $byjunocustomerref,
					'id_prefix' => $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
				);

				$data['order'] = array(
					'id'			=> byjuno_order_id( $orderid ),
					'date' 			=> date('Y-m-d', strtotime($wpdb->get_var("SELECT post_date FROM {$wpdb->prefix}posts WHERE ID={$orderid}"))),
					'initialtotal' 	=> get_post_meta($orderid, 'initial_total', true),
					'currency' 		=> get_post_meta($orderid, '_order_currency', true),
					'total' 		=> $ordertotal
				);

				$request = $this->views->s5($data, 'partial');

				$requestdata = array(
					'order_id'			=> $orderid,
					'request' 			=> $request,
					'posturl'			=> $posturl,
					'return_response' 	=> false,
					'step'				=> 's5_partial',
					'byjunorequest'		=> $byjunorequest,
					'byjunocustomerref'	=> $byjunocustomerref
				);

				update_post_meta($orderid, 'initial_total', $ordertotal);

				try {

					$response = byjuno_send_request($requestdata);

					update_post_meta($orderid, 'sent_s5_partial', 1);

					$to				= $byjunosettings['technical_contact'];
					$subjectinvoice	= 'Neue Bestellung | Merchant: '.$byjunomerchant.' | OrderId: '.$orderid;
					$message 		= '&nbsp;';
					$headers		= 'From: '.get_bloginfo('name').' <'.$to.'>' . "\r\nContent-type: text/html\r\n";

					wp_mail($byjunoemail, $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null);
					if( isset( $byjunosettings['technical_contact'] ) && $byjunosettings['technical_contact'] && isset( $byjunosettings['receive_system_emails'] ) && $byjunosettings['receive_system_emails'] ) {
						wp_mail( $byjunosettings['technical_contact'], $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null );
					}

				} Catch (Exception $e) {

					echo 'Error! ',  $e->getMessage(), "\n";

				}

			} elseif( floatval( $initialtotal ) < floatval( $ordertotal ) ) {

				update_post_meta($orderid, 'initial_total', $ordertotal);

			}

		}

	}

	function s5_refund( $orderid, $refund_id ) {

		if( ! $orderid || ! $refund_id ) return;

		global $woocommerce, $wpdb;

		$paymentmethod = get_post_meta($orderid, '_payment_method', true);

		if($paymentmethod == 'byjuno') {

			$order = new WC_Order( $orderid );
			$refund_amount = abs( get_post_meta( $refund_id, '_order_total', true ) );

			$total_refunds = 0.00;
			foreach( $order->get_refunds() as $refund ) {
				$total_refunds += abs( floatval( $refund->get_amount() ) );
			}

			$order_total = floatval( $order->get_total() ) - floatval( $total_refunds );
			$order_refund = floatval( $refund_amount );

			$userid 			= get_current_user_id();
			$difference 		= $order_refund;

			$byjunosettings 	= $this->byjunosettings;

			$byjunomerchant 	= $byjunosettings['merchant_id'];
			$byjunocustomerref 	= get_post_meta( $orderid, 'byjuno_customer_reference', true );
			if( ! $byjunocustomerref ) {
				$byjunocustomerref = strtolower( str_replace( ' ', '', get_bloginfo('name') ) );
			}
			$byjunorequest 		= get_post_meta( $orderid, 'byjuno_request_id', true );

			$checkmode 			= $byjunosettings['mode'];
			$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/sendTransaction.cfm' : $posturl = '/services/creditCheckDACH_01_41/sendTransaction.cfm';
			$checkmode == 'Test' ? $byjunoemail = 'test-invoices@byjuno.ch' : $byjunoemail = 'invoices@byjuno.ch';

			$data = array();

			$data['byjuno'] = array(
				'clientid' 	=> $byjunosettings['client_id'],
				'email' 	=> $byjunosettings['technical_contact'],
				'user' 		=> $byjunosettings['user_id'],
				'pass' 		=> $byjunosettings['password'],
				'request' 	=> $byjunorequest,
				'ref' 		=> $byjunocustomerref,
				'id_prefix' => $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
			);

			$data['order'] = array(
				//'id'			=> $data['byjuno']['id_prefix'] . $orderid,
				'id' 			=> byjuno_order_id( $orderid ),
				'order_id'		=> byjuno_order_id( $orderid ),
				'date' 			=> date('Y-m-d', strtotime($wpdb->get_var("SELECT post_date FROM {$wpdb->prefix}posts WHERE ID={$orderid}"))),
				'initialtotal' 	=> get_post_meta($orderid, 'initial_total', true),
				'refund'		=> $order_refund,
				'currency' 		=> get_post_meta($orderid, '_order_currency', true),
				'total' 		=> $order_total
			);

			$request = $this->views->s5($data, 'refund');

			$requestdata = array(
				'order_id'			=> $orderid,
				'request' 			=> $request,
				'posturl'			=> $posturl,
				'return_response' 	=> false,
				'step'				=> 's5_partial',
				'byjunorequest'		=> $byjunorequest,
				'byjunocustomerref'	=> $byjunocustomerref
			);

			update_post_meta( $orderid, 's5_total_after_refund', $order_total );

			try {

				$response = byjuno_send_request($requestdata);

				update_post_meta($orderid, 'sent_s5_refund', 1);

				$to				= $byjunosettings['technical_contact'];
				$subjectinvoice	= 'Neue Bestellung | Merchant: '.$byjunomerchant.' | OrderId: '.$orderid;
				$message 		= '&nbsp;';
				$headers		= 'From: '.get_bloginfo('name').' <'.$to.'>' . "\r\nContent-type: text/html\r\n";

				wp_mail($byjunoemail, $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null);
				if( isset( $byjunosettings['technical_contact'] ) && $byjunosettings['technical_contact'] && isset( $byjunosettings['receive_system_emails'] ) && $byjunosettings['receive_system_emails'] ) {
					wp_mail( $byjunosettings['technical_contact'], $subjectinvoice, $message, $headers, $attachmentsinvoice ? $attachmentsinvoice : null );
				}

			} Catch (Exception $e) {

				echo 'Error! ',  $e->getMessage(), "\n";

			}

		}

	}

	function s5($orderid) {

		global $wpdb;

		$paymentmethod = get_post_meta($orderid, '_payment_method', true);

		if($paymentmethod == 'byjuno') {

			! $orderid ? $orderid = $_POST['orderid'] : $orderid = $orderid;

			$ordertotal = get_post_meta($orderid, '_order_total', true);
			$orderemail = get_post_meta($orderid, '_billing_email', true);

			$difference = floatval( $ordertotal );

			update_post_meta( intval( $orderid ), 's5_sent', 1 );

			wp_update_post(array(
				'ID' => (int)$orderid,
				'post_status' => 'wc-cancelled'
			));

			$mailer = WC()->mailer();
			$mails = $mailer->get_emails();
			if(!empty($mails)) {
			    foreach($mails as $mail) {
			        if($mail->id == 'cancelled_order') {
						$mail->recipient = $mail->recipient.','.$orderemail;
						$mail->trigger( $orderid );
			        }
			     }
			}

			$userid = get_current_user_id();

			$byjunosettings = $this->byjunosettings;

			$byjunocustomerref = get_post_meta( $orderid, 'byjuno_customer_reference', true );
			if( ! $byjunocustomerref ) {
				$byjunocustomerref = strtolower( str_replace( ' ', '', get_bloginfo('name') ) );
			}
			$byjunorequest = get_post_meta( $orderid, 'byjuno_request_id', true );

			$checkmode = $byjunosettings['mode'];
			$checkmode == 'Test' ? $posturl = '/services/creditCheckDACH_01_41_TEST/sendTransaction.cfm' : $posturl = '/services/creditCheckDACH_01_41/sendTransaction.cfm';

			$data = array();

			$data['byjuno'] = array(
				'clientid' 	=> $byjunosettings['client_id'],
				'email' 	=> $byjunosettings['technical_contact'],
				'user' 		=> $byjunosettings['user_id'],
				'pass' 		=> $byjunosettings['password'],
				'request' 	=> $byjunorequest,
				'ref' 		=> $byjunocustomerref,
				'id_prefix' => $byjunosettings['use_order_id_prefix'] == 1 && isset( $byjunosettings['order_id_prefix'] ) && $byjunosettings['order_id_prefix'] ? $byjunosettings['order_id_prefix'] . '_' : ''
			);

			$data['order'] = array(
				'id'			=> byjuno_order_id( $orderid ),
				'date' 			=> date('Y-m-d', strtotime($wpdb->get_var("SELECT post_date FROM {$wpdb->prefix}posts WHERE ID={$orderid}"))),
				'initialtotal' 	=> get_post_meta($orderid, 'initial_total', true),
				'currency' 		=> get_post_meta($orderid, '_order_currency', true),
				'total' 		=> $ordertotal
			);

			$request = $this->views->s5($data, 'total');

			$requestdata = array(
				'order_id'			=> $orderid,
				'request' 			=> $request,
				'posturl'			=> $posturl,
				'return_response' 	=> false,
				'step'				=> 's5_full',
				'byjunorequest'		=> $byjunorequest,
				'byjunocustomerref'	=> $byjunocustomerref
			);

			try {

				byjuno_send_request($requestdata);

			} Catch (Exception $e) {

				echo 'Error! ',  $e->getMessage(), "\n";

			}

		}

	}

}
?>
