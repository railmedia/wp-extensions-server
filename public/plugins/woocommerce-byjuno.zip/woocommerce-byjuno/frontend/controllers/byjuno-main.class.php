<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

function byjuno_settings() {

	return get_option( 'woocommerce_byjuno_settings' );

}

function byjuno_logged_in_user_id($data = null ) {

	$userid = get_current_user_id();

	if( ! $userid ) {
		$user = wp_get_current_user();
		if( $user ) {
			$userid = $user->ID;
		}
		if( ! $userid && isset($_POST)) {
			$userid = $_POST['fields']['user']['id'];
		}
	}

	return $userid;

}

function byjuno_order_id( $order_id ) {

	$byjuno_settings = byjuno_settings();
	$byjuno_order_id = $order_id;

	switch( $byjuno_settings['order_id_source'] ) {
		case '1': default:
			// return $order_id;
		break;
		case '2':
			$order_id_meta_key = $byjuno_settings['order_id_meta_key'];
			if( $order_id_meta_key ) {
				$order_id_meta_value = get_post_meta( $order_id, $order_id_meta_key, true );
				if( $order_id_meta_value ) {
					$byjuno_order_id = $order_id_meta_value;
				}
			}
		break;
	}

	return $byjuno_order_id;

}

function byjuno_get_customer_category() {

	if( is_user_logged_in() ) {

		global $wpdb;

		$userid 			= get_current_user_id();
		$usermail 			= $wpdb->get_var("SELECT user_email FROM {$wpdb->prefix}users WHERE ID={$userid}");
		$userfirstname 		= get_user_meta( $userid, 'first_name', true );
		$userlastname 		= get_user_meta( $userid, 'last_name', true );
		$checkusermail 		= $wpdb->get_var("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_billing_email' AND meta_value='{$usermail}'");
		$checkuserfirstname = $wpdb->get_var("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_billing_first_name' AND meta_value='{$userfirstname}'");
		$checkuserlastname 	= $wpdb->get_var("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_billing_last_name' AND meta_value='{$userlastname}'");

		if( $checkusermail || $checkuserfirstname || $checkuserlastname ) {
			return 'RC'; //registered customer / ordered before
		} else {
			return 'NC'; //registered customer / no order yet
		}

	} else {

		return 'NC';

	}

}

function byjuno_permit_check() {

	$byjunosettings = byjuno_settings();
	$allowguest = isset( $byjunosettings['allow_guests'] ) ? $byjunosettings['allow_guests'] : null;
	$userloggedin = get_current_user_id();

	$permitcheck = ( $allowguest && ! $userloggedin ) || ( ! $allowguest && $userloggedin ) || ( $allowguest && $userloggedin ) ? 1 : 0;

	return $permitcheck;

}

function byjuno_fields_labels() {

	if( in_array( 'woocommerce-byjuno-multi-language/woocommerce-byjuno-multi-language.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

		$labels = get_option( 'wbml_langs_labels' );

		if( $labels ) {

			$locale = get_locale();
			$locale = explode('_', $locale);
			$lang = $locale[0];

			return $labels[$lang];

		}

	} else {

		$byjunosettings = byjuno_settings();

		$labels = array();
		$labels['gateway_title'] = isset( $byjunosettings['title'] ) && $byjunosettings['title'] ? $byjunosettings['title'] : '';

		$labels['gateway_description'] = isset( $byjunosettings['description'] ) && $byjunosettings['description'] ? $byjunosettings['description'] : '';

		$labels['gateway_instructions'] = isset( $byjunosettings['instructions'] ) && $byjunosettings['instructions'] ? $byjunosettings['instructions'] : '';

		$labels['gateway_gender'] = isset( $byjunosettings['gender_field_label'] ) && $byjunosettings['gender_field_label'] ? $byjunosettings['gender_field_label'] : '';

		$labels['gateway_gender_female'] = isset( $byjunosettings['gender_field_label_female'] ) && $byjunosettings['gender_field_label_female'] ? $byjunosettings['gender_field_label_female'] : '';

		$labels['gateway_gender_male'] = isset( $byjunosettings['gender_field_label_male'] ) && $byjunosettings['gender_field_label_male'] ? $byjunosettings['gender_field_label_male'] : '';

		$labels['gateway_birthdate'] = isset( $byjunosettings['birthdate_field_label'] ) && $byjunosettings['birthdate_field_label'] ? $byjunosettings['birthdate_field_label'] : '';

		$labels['gateway_birthdate_day'] = isset( $byjunosettings['birthdate_field_day_label'] ) && $byjunosettings['birthdate_field_day_label'] ? $byjunosettings['birthdate_field_day_label'] : '';

		$labels['gateway_birthdate_month'] = isset( $byjunosettings['birthdate_field_month_label'] ) && $byjunosettings['birthdate_field_month_label'] ? $byjunosettings['birthdate_field_month_label'] : '';

		$labels['gateway_birthdate_year'] = isset( $byjunosettings['birthdate_field_year_label'] ) && $byjunosettings['birthdate_field_year_label'] ? $byjunosettings['birthdate_field_year_label'] : '';

		$labels['gateway_house_number'] = isset( $byjunosettings['houseno_field_label'] ) && $byjunosettings['houseno_field_label'] ? $byjunosettings['houseno_field_label'] : '';

		$labels['gateway_company_registration'] = isset( $byjunosettings['company_reg_field_label'] ) && $byjunosettings['company_reg_field_label'] ? $byjunosettings['company_reg_field_label'] : '';

		$labels['gateway_installments_intro'] = isset( $byjunosettings['installments_intro_text'] ) && $byjunosettings['installments_intro_text'] ? $byjunosettings['installments_intro_text'] : '';

		$labels['gateway_installments_full'] = isset( $byjunosettings['installments_full_template'] ) && $byjunosettings['installments_full_template'] ? $byjunosettings['installments_full_template'] : '';

		$labels['gateway_installments_3'] = isset( $byjunosettings['installments_3_template'] ) && $byjunosettings['installments_3_template'] ? $byjunosettings['installments_3_template'] : '';

		$labels['gateway_installments_4'] = isset( $byjunosettings['installments_4_template'] ) && $byjunosettings['installments_4_template'] ? $byjunosettings['installments_4_template'] : '';

		$labels['gateway_installments_12'] = isset( $byjunosettings['installments_12_template'] ) && $byjunosettings['installments_12_template'] ? $byjunosettings['installments_12_template'] : '';

		$labels['gateway_installments_24'] = isset( $byjunosettings['installments_24_template'] ) && $byjunosettings['installments_24_template'] ? $byjunosettings['installments_24_template'] : '';

		$labels['gateway_installments_36'] = isset( $byjunosettings['installments_36_template'] ) && $byjunosettings['installments_36_template'] ? $byjunosettings['installments_36_template'] : '';

		$labels['gateway_invoice_type_intro'] = isset( $byjunosettings['invoice_type_intro_text'] ) && $byjunosettings['invoice_type_intro_text'] ? $byjunosettings['invoice_type_intro_text'] : '';

		$labels['gateway_invoice_type_email'] = isset( $byjunosettings['invoice_via_email'] ) && $byjunosettings['invoice_via_email'] ? $byjunosettings['invoice_via_email'] : '';

		$labels['gateway_invoice_type_post_office'] = isset( $byjunosettings['invoice_via_post'] ) && $byjunosettings['invoice_via_post'] ? $byjunosettings['invoice_via_post'] : '';

		return $labels;

	}

}

function byjuno_fields_validation( $order = null ) {

	$payment_method = $_POST['payment_method'];

	if( $payment_method == 'byjuno' ) {

		$byjunosettings = byjuno_settings();
		$labels = byjuno_fields_labels();

		$has_gender = isset( $byjunosettings['use_gender_field'] ) && $byjunosettings['use_gender_field'] ? $byjunosettings['use_gender_field'] : '';
		if( $has_gender ) {
			
			$gender_field_alt_id = isset( $byjunosettings['gender_field_alt_id'] ) && $byjunosettings['gender_field_alt_id'] ? $byjunosettings['gender_field_alt_id'] : '';
			$gender_field = $gender_field_alt_id ? $gender_field_alt_id : 'billing_user-gender';

			if( ( isset( $_POST[ $gender_field ] ) && ! $_POST[ $gender_field ] ) || ! isset( $_POST[ $gender_field ] ) ) {
				wc_add_notice( '<strong>' . $labels['gateway_gender'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
			}

		}

		$has_birthdate = isset( $byjunosettings['use_birthdate_field'] ) && $byjunosettings['use_birthdate_field'] ? $byjunosettings['use_birthdate_field'] : '';
		if( $has_birthdate ) {

			$birthdate_field_alt_id = $byjunosettings['birthdate_field_alt_id'];
			// $birthdate_field = $birthdate_field_alt_id ? $birthdate_field_alt_id : 'billing_user-birthdate';

			if( isset( $_POST[ $birthdate_field ] ) && ! $_POST[ $birthdate_field ] ) {

				wc_add_notice( '<strong>' . $labels['gateway_birthdate'] . $_POST[ $birthdate_field ] . $birthdate_field . 's</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
				
			} else {
	
				if( isset( $_POST[ 'billing_user-birthdate-day' ] ) && ! $_POST[ 'billing_user-birthdate-day' ] ) {
					wc_add_notice( '<strong>' . $labels['gateway_birthdate_day'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
				}
		
				if( isset( $_POST[ 'billing_user-birthdate-month' ] ) && ! $_POST[ 'billing_user-birthdate-month' ] ) {
					wc_add_notice( '<strong>' . $labels['gateway_birthdate_month'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
				}
		
				if( isset( $_POST[ 'billing_user-birthdate-year' ] ) && ! $_POST[ 'billing_user-birthdate-year' ] ) {
					wc_add_notice( '<strong>' . $labels['gateway_birthdate_year'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
				}

			}

		}

		$has_houseno = isset( $byjunosettings['use_houseno_field'] ) && $byjunosettings['use_houseno_field'] ? $byjunosettings['use_houseno_field'] : '';
		if( $has_houseno ) {
			$houseno_field_alt_id = isset( $byjunosettings['houseno_field_alt_id'] ) && $byjunosettings['houseno_field_alt_id'] ? $byjunosettings['houseno_field_alt_id'] : '';
			$houseno_field = $houseno_field_alt_id ? $houseno_field_alt_id : 'billing_houseno';
		}

		if( isset( $houseno_field ) && isset( $_POST[ $houseno_field ] ) && ! $_POST[ $houseno_field ] ) {
	        wc_add_notice( '<strong>' . $labels['gateway_house_number'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
	    }

		if( isset( $_POST['billing_company'] ) && $_POST['billing_company'] ) {

			$has_company_reg = isset( $byjunosettings['use_company_reg_field'] ) && $byjunosettings['use_company_reg_field'] ? $byjunosettings['use_company_reg_field'] : '';
			if( $has_company_reg ) {
				$company_reg_field_alt_id = isset( $byjunosettings['company_reg_field_alt_id'] ) && $byjunosettings['company_reg_field_alt_id'] ? $byjunosettings['company_reg_field_alt_id'] : '';
				$company_reg_field = $company_reg_field_alt_id ? $company_reg_field_alt_id : 'billing_company_reg';
			}

			if( isset( $_POST[ $company_reg_field ] ) && isset( $byjunosettings['company_reg_field_required'] ) && $byjunosettings['company_reg_field_required'] == '1' && ! $_POST[ $company_reg_field ] ) {
				wc_add_notice( '<strong>' . $labels['gateway_company_registration'] . '</strong> ' . __( 'is a required field.', 'woocommerce-byjuno' ), 'error' );
			}
			
		}

		$permitcheck = byjuno_permit_check();

		if( $permitcheck ) {

			$byjunoRequests = new ByjunoRequests;
			$s1_s2 = $byjunoRequests->s1_s2( $_POST, $order );

			// wc_add_notice( '<span class="byjuno_not_available_notice" style="font-weight:normal">' . $unavailable . '</span>', 'error' );

			if( ! $s1_s2 ) {

				$unavailable = $labels['gateway_unavailable'] ? $labels['gateway_unavailable'] : $byjunosettings['unavailable'];

				wc_add_notice( '<span class="byjuno_not_available_notice" style="font-weight:normal">' . $unavailable . '</span>', 'error' );

			} else {

				if( $order ) {
					$byjunoRequests->s3( $order );
				}
			}

		} else {

			add_filter( 'woocommerce_available_payment_gateways', 'disable_directly_byjuno_gateway', 200, 1 );

		}

	}

}

// add_action( 'woocommerce_before_pay_action', 'byjuno_fields_validation' );
add_action( 'woocommerce_before_checkout_process', 'byjuno_fields_validation' );

add_filter( 'woocommerce_available_payment_gateways', 'remove_byjuno_gateway_on_pay_action', 10, 1 );

function remove_byjuno_gateway_on_pay_action( $available_gateways ) {

	if( isset( $_GET['pay_for_order'] ) && isset( $_GET['key'] ) ) {
		unset( $available_gateways['byjuno'] );
	}

	return $available_gateways;

}

function byjuno_check_s3_status( $orderid ) {

	$failure = get_post_meta( $orderid, 'cancel_order_byjuno_s3_failure', true );

	if( $failure ) {
		$order = wc_get_order($orderid);
		$order->update_status('cancelled', 'Byjuno payment request failed (S3 failure)');
		delete_post_meta($orderid, 'cancel_order_byjuno_s3_failure');
	}

}

add_action( 'woocommerce_thankyou', 'byjuno_check_s3_status', 99, 1 );

function byjuno_check_orders_for_s3_failed() {

	global $wpdb;
	$orders = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}postmeta WHERE meta_key='cancel_order_byjuno_s3_failure'");
	if( $orders ) {
		foreach( $orders as $order ) {
			$the_order = wc_get_order($order->post_id);
			if( $the_order ) {
				delete_post_meta($order->post_id, 'cancel_order_byjuno_s3_failure');
				$the_order->update_status('cancelled', 'Byjuno payment request failed (S3 failure)');
			}
		}
	}

}

add_action( 'wp', 'byjuno_check_orders_for_s3_failed' );

function byjuno_send_request($data) {

	$posturl = 'https://secure.intrum.ch' . $data['posturl'];

	$request = curl_init();

	$requestfield = urlencode("REQUEST") . "=" . urlencode($data['request']);

	$headers = array(
		'Content-type: application/x-www-form-urlencoded',
		'Content-Length: '.strlen($requestfield)
	);
	curl_setopt($request, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($request, CURLOPT_URL, $posturl);
	curl_setopt($request, CURLOPT_POST, 1);
	curl_setopt($request, CURLOPT_POSTFIELDS, $requestfield);

	$response = curl_exec($request);

	if( ! isset( $data['istest'] ) ) {

		$logdata = apply_filters( 'byjuno_log_data', array(
			'order_id'			=> isset( $data['order_id'] ) && $data['order_id'] ? $data['order_id'] : '',
			'byjunocustomerref' => $data['byjunocustomerref'],
			'byjunorequest' 	=> $data['byjunorequest'],
			'step'				=> $data['step'],
			'data' 				=> array(
				'request_no'	=> isset( $data['request_no'] ) && $data['request_no'] ? $data['request_no'] : '',
				'request' 		=> $data['request'],
				'request_data' 	=> $data['request_data'],
				'response' 		=> $response,
				'return_data'	=> simplexml_load_string($response)
			)
		) );


		if(class_exists('ByjunoLogs')) {
			$logs = new ByjunoLogs;
			$logname = $logs->logs($logdata, byjuno_settings());
		}

		if($data['step'] == 's1_s2') {
			if(class_exists('ByjunoErrorLogs')) {
				if($logname) {
					$logdata['log_name'] = $logname;
					$logdata['log_dir'] = date('Y') . '/' . date('m') . '/' . date('d') . '/';
				}
				$errorlogs = new ByjunoErrorLogsLog;
				echo $errorlogs->log($logdata);
			}
		}

	}

	if(isset($data['return_response']) && $data['return_response']) {

		$response = simplexml_load_string($response);
		return $response;

	}

}

class ByjunoMain {

	var $views, $carttotal, $errorlogs, $requests_static;

	function __construct($data=null) {

		$this->views = new ByjunoViews;

		add_filter( 'woocommerce_payment_gateways', array( $this, 'wc_byjuno_gateway_init' ), 10, 1 );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_links' ) );
		add_action( 'wp_footer', array( $this, 'threatmetrix' ) );
		add_action( 'init', array($this, 'byjuno_allowed') );

		$actions = array( 'byjuno_admin_get_test_form' );

		foreach ( $actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, $action ) );
			add_action( 'wp_ajax_nopriv_' . $action, array( $this, $action ) );
		}

	}

	function byjuno_allowed() {
		$permitcheck = byjuno_permit_check();
		if( ! $permitcheck ) {
			add_filter( 'woocommerce_available_payment_gateways', 'disable_directly_byjuno_gateway', 200, 1 );
		}
	}

	function threatmetrix() {

		if( is_checkout() && ! is_wc_endpoint_url('order-received') ) {

			$blogname = strtolower(str_replace(' ', '', get_bloginfo('name')));
			$byjunosettings = byjuno_settings();
			$byjunoclientid = $byjunosettings['client_id'];
			$sessionid = md5($blogname.get_current_user_id().date('Y-m-d H:i:s'));
			WC()->session->set('byjuno_threatmetrix_clientid', $byjunoclientid);
			WC()->session->set('byjuno_threatmetrix_sessionid', $sessionid);
			$data = array(
				'byjunoclientid' 	=> $byjunoclientid,
				'sessionid'			=> $sessionid
			);

			echo $this->views->threatmetrix($data);

		}

	}

	function wc_byjuno_gateway_init($gateways) {

		if( class_exists( 'WC_Gateway_Byjuno' ) ) {
			$gateways[] = 'WC_Gateway_Byjuno';
		}

		return $gateways;

	}

	function plugin_links($links) {

		$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=byjuno' ) . '">' . __( 'Settings', 'woocommerce-byjuno' ) . '</a>',
		);

		return array_merge($plugin_links, $links);

	}

	function byjuno_admin_get_test_form() {

		echo $this->views->byjuno_test_form();

		wp_die();

	}


}
new ByjunoMain;
?>
