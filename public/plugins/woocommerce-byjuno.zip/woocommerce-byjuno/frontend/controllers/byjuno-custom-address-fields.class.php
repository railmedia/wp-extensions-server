<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

class ByjunoCustomAddressFields {

	var $byjunosettings, $permitcheck;

	function __construct() {

		$this->byjunosettings = byjuno_settings();
		$this->permitcheck = byjuno_permit_check();

		add_filter('woocommerce_shipping_fields', array($this, 'my_account_shipping_address'), 100, 1);
		add_filter('woocommerce_checkout_fields', array($this, 'checkout'), 100, 1);
		add_action('woocommerce_checkout_update_order_meta', array($this, 'checkout_fields_update_order_meta'), 10);
		add_filter('woocommerce_order_formatted_billing_address' , array($this, 'default_billing_address'), 100, 2);
		add_filter('woocommerce_order_formatted_shipping_address' , array($this, 'default_shipping_address'), 100, 2);

	}

	function checkout( $fields = array() ) {

		$permitcheck = $this->permitcheck;

		if( is_checkout() && $permitcheck ) {

			$byjunosettings = $this->byjunosettings;
			$labels = byjuno_fields_labels();

			if( isset( $byjunosettings['use_houseno_field'] ) && $byjunosettings['use_houseno_field'] ) {

			    $fields['shipping']['shipping_houseno'] = array(
					'class'		=> array('form-row-wide'),
					'clear'		=> true,
				    'label'     => $labels['houseno_field_label'],
				    'placeholder'   => __($labels['houseno_field_label'], 'placeholder', 'woocommerce-byjuno'),
				    'required'  => true,
					'priority'  => 55
			    );

			}

		}

		return $fields;

	}

	function my_account_shipping_address($fields = array()) {

		if( is_account_page() ) {

			$byjunosettings = $this->byjunosettings;
			$labels = byjuno_fields_labels();

			if( isset($byjunosettings['use_houseno_field'] ) && $byjunosettings['use_houseno_field'] ) {

			    $fields['shipping_houseno'] = array(
					'class'		=> array('form-row-wide'),
					'clear'		=> true,
				    'label'     => $labels['houseno_field_label'],
				    'placeholder'   => __($labels['houseno_field_label'], 'placeholder', 'woocommerce-byjuno'),
				    'required'  => true,
					'priority'  => 55
			    );

			}

		}

		return $fields;

	}

	function default_billing_address($fields, $order) {

		$permitcheck = $this->permitcheck;

		if( is_account_page() || ( is_checkout() && $permitcheck ) ) {

			$byjunosettings = $this->byjunosettings;

			if( isset( $byjunosettings['use_houseno_field'] ) && $byjunosettings['use_houseno_field'] ) {
				$fields['billing_houseno'] = get_post_meta( $order->id, '_billing_houseno', true );
			}

		}

		return $fields;

	}

	function default_shipping_address($fields, $order) {

		$permitcheck = $this->permitcheck;

		if( is_account_page() || ( is_checkout() && $permitcheck ) ) {

			$byjunosettings = $this->byjunosettings;

			if( isset( $byjunosettings['use_houseno_field'] ) && $byjunosettings['use_houseno_field'] ) {
				$fields['shipping_houseno'] = get_post_meta( $order->id, '_shipping_houseno', true );
			}

		}

		return $fields;

	}

	function checkout_fields_update_order_meta($order_id) {

		$permitcheck = $this->permitcheck;

		if( is_account_page() || ( is_checkout() && $permitcheck ) ) {

			$byjunosettings = $this->byjunosettings;

			$has_gender = $byjunosettings['use_gender_field'];
			if( $has_gender ) {
				$gender_field_alt_id = $byjunosettings['gender_field_alt_id'];
				if( $gender_field_alt_id ) {
					$gender_female_value = $byjunosettings['gender_field_alt_id_female_value'];
					$gender_male_value = $byjunosettings['gender_field_alt_id_male_value'];
					$gender_field_value = isset( $_POST[ $gender_field_alt_id ] ) && $_POST[ $gender_field_alt_id ] ? $_POST[ $gender_field_alt_id ] : $_POST['billing_user-gender'];
					if( $gender_female_value && ( $gender_field_value == $gender_female_value ) ) {
						$gender_field_value = '2';
					}
					if( $gender_male_value && ( $gender_field_value == $gender_male_value ) ) {
						$gender_field_value = '1';
					}
				} else {
					$gender_field_value = $_POST['billing_user-gender'];
				}
			} else {
				$gender_field_value = $_POST['billing_user-gender'];
			}

			if ( $gender_field_value ) {
				update_post_meta( $order_id, '_billing_user-gender', sanitize_text_field( $gender_field_value ) );
			}

			$has_birthdate = $byjunosettings['use_birthdate_field'];
			if( $has_birthdate ) {
				$birthdate_field_alt_id = $byjunosettings['birthdate_field_alt_id'];
				if( $birthdate_field_alt_id ) {
					$birthdate_field_value = isset( $_POST[ $birthdate_field_alt_id ] ) && $_POST[ $birthdate_field_alt_id ] ? $_POST[ $birthdate_field_alt_id ] : $_POST['billing_user-birthdate'];
				} else {
					$birthdate_field_value = $_POST['billing_user-birthdate'];
				}
			}

			if ( $birthdate_field_value ) {
				update_post_meta( $order_id, '_billing_user-birthdate', sanitize_text_field( $birthdate_field_value ) );
			}

			$has_houseno = $byjunosettings['use_houseno_field'];
			if( $has_houseno ) {
				$houseno_field_alt_id = $byjunosettings['houseno_field_alt_id'];
				if( $houseno_field_alt_id ) {
					$houseno_field_value = isset( $_POST[ $houseno_field_alt_id ] ) && $_POST[ $houseno_field_alt_id ] ? $_POST[ $houseno_field_alt_id ] : $_POST['billing_houseno'];
				} else {
					$houseno_field_value = $_POST['billing_houseno'];
				}
			}

			if( isset( $houseno_field_value ) && $houseno_field_value ) {
				update_post_meta( $order_id, '_billing_houseno', sanitize_text_field( $houseno_field_value ) );
			}

			$customer_type = isset( $_POST['billing_company'] ) && $_POST['billing_company'] ? 'b2b' : 'b2c';
			$has_company_reg = $byjunosettings['use_company_reg_field'];
			if( $has_company_reg ) {
				$company_reg_field_alt_id = $byjunosettings['company_reg_field_alt_id'];
				if( $company_reg_field_alt_id ) {
					$company_reg_field_value = isset( $_POST[ $company_reg_field_alt_id ] ) && $_POST[ $company_reg_field_alt_id ] ? $_POST[ $company_reg_field_alt_id ] : $_POST['billing_company_reg'];
				} else {
					$company_reg_field_value = $_POST['billing_company_reg'];
				}
			}

			if( $company_reg_field_value ) {
				update_post_meta( $order_id, '_billing_company_reg', sanitize_text_field( $company_reg_field_value ) );
			}

			if( isset($_POST['shipping_houseno']) ) {
				update_post_meta( $order_id, '_shipping_houseno', sanitize_text_field( $_POST['shipping_houseno'] ) );
			}

			if( isset($_POST['byjuno-invoice-type']) ) {
				update_post_meta( $order_id, '_billing_paper_invoice', sanitize_text_field( $_POST['byjuno-invoice-type'] ) );
			}

			if( isset($_POST['byjuno-installments-type']) ) {
				update_post_meta( $order_id, '_billing_installment_type', sanitize_text_field( $_POST['byjuno-installments-type'] ) );
			}

		}

	}

}
new ByjunoCustomAddressFields;
?>
