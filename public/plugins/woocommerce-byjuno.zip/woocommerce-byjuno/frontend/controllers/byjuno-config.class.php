<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

class ByjunoConfig {

	function __construct($data = null) {

		add_action( 'wp_enqueue_scripts', array($this, 'scripts'), 200 );
		add_action( 'activated_plugin', array($this, 'load_last') );

	}

	function load_last() {

	    $plugins = get_option( 'active_plugins' );
		foreach($plugins as $key => $plugin) {
			if($plugin == 'woocommerce-byjuno/woocommerce-byjuno.php') {
				unset($plugins[$key]);
			}
		}
		$plugins[] = 'woocommerce-byjuno/woocommerce-byjuno.php';
		update_option('active_plugins', $plugins, 1);

	}

	function scripts() {

		$permitcheck = byjuno_permit_check();
		$byjunosettings = byjuno_settings();

		if( is_checkout() && $permitcheck ) {

			$userid = get_current_user_id();

			if( is_checkout() && ! is_wc_endpoint_url('order-received') ) {

				$session = WC()->session;

				if( $byjunosettings['use_company_reg_field'] ) {
					wp_enqueue_script('byjuno-block-ui', BYJUNOURL . 'frontend/assets/js/jquery.blockui.js', array('jquery'), '', true);
				}
				wp_enqueue_script('byjuno-main-js', BYJUNOURL . 'frontend/assets/js/byjuno.js', array('jquery'), '', true);
				$localizefrontend = array(
					'crf'			=> $byjunosettings['use_company_reg_field'],
					'ccrf'			=> $byjunosettings['use_company_reg_field'] && $byjunosettings['company_reg_field_alt_id'] ? $byjunosettings['company_reg_field_alt_id'] : '',
					'pcl'			=> $byjunosettings['postcode_field_limit'],
					'pcno'			=> $byjunosettings['postcode_field_numbers_only'],
					'au'			=> $byjunosettings['allow_underage'],
					'asb'			=> $byjunosettings['auto_select_gateway'],
					'datelang'		=> array(
						'closeText' => __( 'Close', 'woocommerce-byjuno' ),
						'prevText'  => __( 'Prev', 'woocommerce-byjuno' ),
						'nextText'	=> __( 'Next', 'woocommerce-byjuno' ),
						'currentText' => __( 'Today', 'woocommerce-byjuno' ),
						'monthNames' => array(
							__( 'January', 'woocommerce-byjuno' ),
							__( 'February', 'woocommerce-byjuno' ),
							__( 'March', 'woocommerce-byjuno' ),
							__( 'April', 'woocommerce-byjuno' ),
							__( 'May', 'woocommerce-byjuno' ),
							__( 'June', 'woocommerce-byjuno' ),
							__( 'July', 'woocommerce-byjuno' ),
							__( 'August', 'woocommerce-byjuno' ),
							__( 'September', 'woocommerce-byjuno' ),
							__( 'October', 'woocommerce-byjuno' ),
							__( 'November', 'woocommerce-byjuno' ),
							__( 'December', 'woocommerce-byjuno' )
						),
						'dayNames'	=> array(
							__( 'Sunday', 'woocommerce-byjuno' ),
							__( 'Monday', 'woocommerce-byjuno' ),
							__( 'Tuesday', 'woocommerce-byjuno' ),
							__( 'Wednesday', 'woocommerce-byjuno' ),
							__( 'Thursday', 'woocommerce-byjuno' ),
							__( 'Friday', 'woocommerce-byjuno' ),
							__( 'Saturday', 'woocommerce-byjuno' )
						)
					)
				);

				wp_localize_script('byjuno-main-js', 'byjuno', $localizefrontend);

			}

		}

		wp_enqueue_style('byjuno-main-css',  BYJUNOURL . 'frontend/assets/css/byjuno.css');

		if( isset( $byjunosettings ) && isset( $byjunosettings['hide_byjuno_fields'] ) && $byjunosettings['hide_byjuno_fields'] == 1 ) {
			wp_add_inline_style('byjuno-main-css', '#billing_user-gender_field, #billing_user-birthdate_field {display:none;}');
		}

		if(is_checkout() || is_account_page()) {

			wp_enqueue_style( 'jquery-ui-theme-smoothness', BYJUNOURL . 'frontend/assets/css/jquery-ui.1.2.1.min.css' );
			wp_enqueue_script( 'jquery-ui-datepicker' );

		}

	}

}
new ByjunoConfig;
?>
