<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

class ByjunoViews {

	function threatmetrix($data) {

		ob_start();
?>
		<script type="text/javascript" src="https://h.online-metrix.net/fp/tags.js?org_id=lq866c5i&session_id=<?php echo $data['sessionid']; ?>&pageid=<?php echo $data['byjunoclientid']; ?>"></script>
		<noscript>
			<iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="https://h.online-metrix.net/tags?org_id=lq866c5i&session_id=<?php echo $data['sessionid']; ?>&pageid=<?php echo $data['byjunoclientid']; ?>"></iframe>
		</noscript>
<?php
		return ob_get_clean();

	}

	function gateway_description( $byjunosettings, $data ) {
		ob_start();
?>
		<p><?php _e($byjunosettings['description'], 'woocommerce-byjuno'); ?></p>

		<?php if(isset($byjunosettings['use_checkout_suboptions']) && $byjunosettings['use_checkout_suboptions']) { ?>

			<?php if(isset($byjunosettings['checkout_suboptions_via_email']) && $byjunosettings['checkout_suboptions_via_email']) { ?>
			<p>
				<input type="radio" style="position:relative; top:auto; z-index:10000;" name="byjuno-invoice-type" checked="checked" value="NO" id="byjuno-invoice-type-email" /> <label for="byjuno-invoice-type-email">
					<?php echo str_replace('{email}', $data['user']['email'], $byjunosettings['checkout_suboptions_via_email']); ?>
				</label>
			</p>
			<?php } ?>

			<?php if(isset($byjunosettings['checkout_suboptions_via_post']) && $byjunosettings['checkout_suboptions_via_post']) { ?>
			<p>
				<input type="radio" style="position:relative; top:auto; z-index:10000;" name="byjuno-invoice-type" value="YES" id="byjuno-invoice-type-paper" />
				<label for="byjuno-invoice-type-paper">
					<?php echo str_replace('{address}', $data['user']['address'] . ', ' . $data['user']['postcode'] . ', ' . $data['user']['postcode'], $byjunosettings['checkout_suboptions_via_post']); ?>
				</label>
			</p>
			<?php } ?>

		<?php } ?>

		<?php if(isset($byjunosettings['use_installments']) && $byjunosettings['use_installments']) { ?>

			<p><?php _e('Please choose your payment plan:', 'woocommerce-byjuno'); ?></p>

			<?php if(isset($byjunosettings['use_installments_full']) && $byjunosettings['use_installments_full']) { ?>
			<p>
				<input type="radio" style="position:relative; top:auto; z-index:10000;" name="byjuno-installments-type" checked="checked" value="0" id="byjuno-installment-type-full" />
				<label for="byjuno-installment-type-full"><?php echo $byjunosettings['use_installments_full']; ?></label>
			</p>
			<?php } ?>

			<?php if( isset( $byjunosettings['use_installments_3'] ) && $byjunosettings['use_installments_3'] ) { ?>
			<p>
				<input type="radio" style="position:relative; top:auto; z-index:10000;" name="byjuno-installments-type" value="10" id="byjuno-installment-type-3" />
				<label for="byjuno-installment-type-3"><?php echo $byjunosettings['use_installments_3']; ?></label>
			</p>
			<?php } ?>

			<?php if( isset( $byjunosettings['use_installments_12'] ) && $byjunosettings['use_installments_12'] ) { ?>
			<p>
				<input type="radio" style="position:relative; top:auto; z-index:10000;" name="byjuno-installments-type" value="8" id="byjuno-installment-type-12" />
				<label for="byjuno-installment-type-12"><?php echo $byjunosettings['use_installments_12']; ?></label>
			</p>
			<?php } ?>

		<?php } ?>
<?php

		return ob_get_clean();

	}

	public function s1_s2($data) {

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}
			$customer = $doc->createElement('Customer');
			$customeratt = $doc->createAttribute('Reference');
			$customeratt->value = $data['byjuno']['id_prefix'] . $data['byjuno']['ref'];
			$customer->appendChild($customeratt);
			$request->appendChild($customer);
				$person = $doc->createElement('Person');
				$customer->appendChild($person);
					$elements = array(
						$doc->createElement('LastName', htmlspecialchars( $data['user']['billing_lastname'] ) ),
						$doc->createElement('FirstName', htmlspecialchars( $data['user']['billing_firstname'] ) ),
						$doc->createElement('Gender', $data['user']['gender']),
						$doc->createElement('DateOfBirth', $data['user']['birthday'])
					);
					$lang = get_locale();
					$lang = explode('_', $lang);
					$lang = (isset($lang[0]) && $lang[0]) ? strtolower($lang[0]) : 'de';
					$elements[] = $doc->createElement('Language', $lang);
					foreach($elements as $element) {
						$person->appendChild($element);
					}
					$address 	= $doc->createElement('CurrentAddress');
					$person->appendChild($address);
						$elements = array(
							$doc->createElement('FirstLine', htmlspecialchars( $data['user']['billing_address'] ) ),
							$doc->createElement('HouseNumber', (isset($data['user']['billing_houseno']) && $data['user']['billing_houseno']) ? $data['user']['billing_houseno'] : ''),
							$doc->createElement('CountryCode', (isset($data['user']['billing_country']) && $data['user']['billing_country']) ? $data['user']['billing_country'] : 'CH'),
							$doc->createElement('PostCode', $data['user']['billing_postcode']),
							$doc->createElement('Town', htmlspecialchars( $data['user']['billing_city'] ) )
						);
						foreach($elements as $element) {
							$address->appendChild($element);
						}
					$commnumbers= $doc->createElement('CommunicationNumbers');
					$person->appendChild($commnumbers);
						$elements = array(
							$doc->createElement('TelephonePrivate'),
							$doc->createElement('TelephoneOffice'),
							$doc->createElement('Fax'),
							$doc->createElement('Mobile', $data['user']['phone']),
							$doc->createElement('Email', $data['user']['email'])
						);
						foreach($elements as $element) {
							$commnumbers->appendChild($element);
						}
					$extrainfofields = array(
						array(
							'Name' 	=> 'ORDERCLOSED',
							'Value' => 'NO'
						),
						// array(
						// 	'Name' 	=> 'ORDERID',
						// 	'Value' => isset($data['orderid']) && $data['orderid'] ? $data['byjuno']['id_prefix'] . $data['orderid'] : ''
						// ),
						array(
							'Name' 	=> 'ORDERAMOUNT',
							'Value' => $data['user']['ordertotal']
						),
						array(
							'Name' 	=> 'ORDERCURRENCY',
							'Value' => $data['user']['currency'] ? $data['user']['currency'] : 'CHF'
						),
						array(
							'Name' 	=> 'IP',
							'Value' => $data['user']['ip'] ? $data['user']['ip'] : $_SERVER['REMOTE_ADDR']
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_firstname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_LASTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_lastname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTLINE',
							'Value' => htmlspecialchars( rtrim($data['user']['shipping_address'].' '.$data['user']['shipping_houseno'], ' ') )
						),
						array(
							'Name' 	=> 'DELIVERY_COUNTRYCODE',
							'Value' => $data['user']['shipping_country'] ? $data['user']['shipping_country'] : 'CH'
						),
						array(
							'Name' 	=> 'DELIVERY_POSTCODE',
							'Value' => $data['user']['shipping_postcode']
						),
						array(
							'Name' 	=> 'DELIVERY_TOWN',
							'Value' => htmlspecialchars( $data['user']['shipping_city'] )
						),
						array(
							'Name' 	=> 'CUSTOMER_CATEGORY',
							'Value' => $data['user']['customercategory']
						),
						array(
							'Name' 	=> 'DEVICE_FINGERPRINT_ID',
							'Value' => $data['user']['thmetrix']
						)
					);

					foreach($extrainfofields as $eiatt => $eivals) {
						$extrainfo = $doc->createElement('ExtraInfo');
						$person->appendChild($extrainfo);
						foreach($eivals as $eivalatt => $eivalval) {
							$extrainfoval = $doc->createElement($eivalatt, $eivalval);
							$extrainfo->appendChild($extrainfoval);
						}
					}
		return $doc->saveXML();

	}

	public function s1_s2_b2b($data) {

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}
			$customer = $doc->createElement('Customer');
			$customeratt = $doc->createAttribute('Reference');
			$customeratt->value = $data['byjuno']['id_prefix'] . $data['byjuno']['ref'];
			$customer->appendChild($customeratt);
			$request->appendChild($customer);
				$company = $doc->createElement('Company');
				$customer->appendChild($company);

					$lang = get_locale();
					$lang = explode('_', $lang);
					$lang = (isset($lang[0]) && $lang[0]) ? strtolower($lang[0]) : 'de';

					$elements = array(
						$doc->createElement( 'CompanyName1', htmlspecialchars( $data['user']['billing_company'] ) ),
						$doc->createElement( 'Language', $lang )
					);
					foreach($elements as $element) {
						$company->appendChild($element);
					}

					$orderingperson = $doc->createElement( 'OrderingPerson' );
					$company->appendChild($orderingperson);
					$person = $doc->createElement( 'Person' );
					$orderingperson->appendChild($person);

					$elements = array(
						$doc->createElement('LastName', htmlspecialchars( $data['user']['billing_lastname'] ) ),
						$doc->createElement('FirstName', htmlspecialchars( $data['user']['billing_firstname'] ) ),
						$doc->createElement('Gender', $data['user']['gender']),
						$doc->createElement('DateOfBirth', $data['user']['birthday'])
					);

					foreach($elements as $element) {
						$person->appendChild($element);
					}

					$address = $doc->createElement('CurrentAddress');
					$company->appendChild($address);
						$elements = array(
							$doc->createElement('FirstLine', htmlspecialchars( $data['user']['billing_address'] ) ),
							$doc->createElement('HouseNumber', (isset($data['user']['billing_houseno']) && $data['user']['billing_houseno']) ? $data['user']['billing_houseno'] : ''),
							$doc->createElement('CountryCode', (isset($data['user']['billing_country']) && $data['user']['billing_country']) ? $data['user']['billing_country'] : 'CH'),
							$doc->createElement('PostCode', $data['user']['billing_postcode']),
							$doc->createElement('Town', htmlspecialchars( $data['user']['billing_city'] ) )
						);
						foreach($elements as $element) {
							$address->appendChild($element);
						}
					$commnumbers= $doc->createElement('CommunicationNumbers');
					$company->appendChild($commnumbers);
						$elements = array(
							$doc->createElement('TelephonePrivate'),
							$doc->createElement('TelephoneOffice'),
							$doc->createElement('Fax'),
							$doc->createElement('Mobile', $data['user']['phone']),
							$doc->createElement('Email', $data['user']['email'])
						);
						foreach($elements as $element) {
							$commnumbers->appendChild($element);
						}
					$extrainfofields = array(
						array(
							'Name' 	=> 'ORDERCLOSED',
							'Value' => 'NO'
						),
						// array(
						// 	'Name' 	=> 'ORDERID',
						// 	'Value' => isset($data['orderid']) && $data['orderid'] ? $data['byjuno']['id_prefix'] . $data['orderid'] : ''
						// ),
						array(
							'Name' 	=> 'ORDERAMOUNT',
							'Value' => $data['user']['ordertotal']
						),
						array(
							'Name' 	=> 'ORDERCURRENCY',
							'Value' => $data['user']['currency'] ? $data['user']['currency'] : 'CHF'
						),
						array(
							'Name' 	=> 'IP',
							'Value' => $data['user']['ip'] ? $data['user']['ip'] : $_SERVER['REMOTE_ADDR']
						),
						array(
							'Name' => 'DELIVERY_COMPANYNAME',
							'Value' => htmlspecialchars( $data['user']['billing_company'] )
						),
						array(
							'Name' => 'REGISTERNUMBER',
							'Value' => htmlspecialchars( $data['user']['billing_company_reg'] )
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_firstname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_LASTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_lastname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTLINE',
							'Value' => htmlspecialchars( rtrim($data['user']['shipping_address'].' '.$data['user']['shipping_houseno'], ' ') )
						),
						array(
							'Name' 	=> 'DELIVERY_COUNTRYCODE',
							'Value' => $data['user']['shipping_country']
						),
						array(
							'Name' 	=> 'DELIVERY_POSTCODE',
							'Value' => $data['user']['shipping_postcode']
						),
						array(
							'Name' 	=> 'DELIVERY_TOWN',
							'Value' => htmlspecialchars( $data['user']['shipping_city'] )
						),
						array(
							'Name' 	=> 'CUSTOMER_CATEGORY',
							'Value' => $data['user']['customercategory']
						),
						array(
							'Name' 	=> 'DEVICE_FINGERPRINT_ID',
							'Value' => $data['user']['thmetrix']
						)
					);

					foreach($extrainfofields as $eiatt => $eivals) {
						$extrainfo = $doc->createElement('ExtraInfo');
						$company->appendChild($extrainfo);
						foreach($eivals as $eivalatt => $eivalval) {
							$extrainfoval = $doc->createElement($eivalatt, $eivalval);
							$extrainfo->appendChild($extrainfoval);
						}
					}
		return $doc->saveXML();

	}

	function s3($data) {

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}
			$customer = $doc->createElement('Customer');
			$customeratt = $doc->createAttribute('Reference');
			$customeratt->value = $data['byjuno']['id_prefix'] . $data['byjuno']['ref'];
			$customer->appendChild($customeratt);
				$request->appendChild($customer);
					$person = $doc->createElement('Person');
					$customer->appendChild($person);
						$elements = array(
							$doc->createElement('LastName', htmlspecialchars( $data['user']['billing_lastname'] ) ),
							$doc->createElement('FirstName', htmlspecialchars( $data['user']['billing_firstname'] ) ),
							$doc->createElement('Gender', $data['user']['gender']),
							$doc->createElement('DateOfBirth', $data['user']['birthday'])
						);
						$lang = get_locale();
						$lang = explode('_', $lang);
						$lang = (isset($lang[0]) && $lang[0]) ? strtolower($lang[0]) : 'de';
						$elements[] = $doc->createElement('Language', $lang);
						foreach($elements as $element) {
							$person->appendChild($element);
						}
						$address = $doc->createElement('CurrentAddress');
						$person->appendChild($address);
							$elements = array(
								$doc->createElement('FirstLine', htmlspecialchars( $data['user']['billing_address'] ) ),
								$doc->createElement('HouseNumber', (isset($data['user']['billing_houseno']) && $data['user']['billing_houseno']) ? $data['user']['billing_houseno'] : ''),
								$doc->createElement('CountryCode', (isset($data['user']['billing_country']) && $data['user']['billing_country']) ? $data['user']['billing_country'] : 'CH'),
								$doc->createElement('PostCode', $data['user']['billing_postcode']),
								$doc->createElement('Town', htmlspecialchars( $data['user']['billing_city'] ) )
							);
							foreach($elements as $element) {
								$address->appendChild($element);
							}
						$commnumbers= $doc->createElement('CommunicationNumbers');
						$person->appendChild($commnumbers);
							$elements = array(
								$doc->createElement('TelephonePrivate'),
								$doc->createElement('TelephoneOffice'),
								$doc->createElement('Fax'),
								$doc->createElement('Mobile', $data['user']['phone']),
								$doc->createElement('Email', $data['user']['email'])
							);
							foreach($elements as $element) {
								$commnumbers->appendChild($element);
							}
							$extrainfofields = array(
								array(
									'Name' 	=> 'ORDERCLOSED',
									'Value' => 'YES'
								),
								array(
									'Name' 	=> 'ORDERID',
									'Value' => $data['byjuno']['id_prefix'] . $data['user']['orderid']
								),
								array(
									'Name' 	=> 'ORDERAMOUNT',
									'Value' => $data['user']['ordertotal']
								),
								array(
									'Name' 	=> 'ORDERCURRENCY',
									'Value' => $data['user']['currency'] ? $data['user']['currency'] : 'CHF'
								),
								array(
									'Name' 	=> 'IP',
									'Value' => $data['user']['ip'] ? $data['user']['ip'] : $_SERVER['REMOTE_ADDR']
								),
								array(
									'Name' 	=> 'PAYMENTMETHOD',
									'Value' => isset( $data['byjuno']['paymentmethod'] ) && $data['byjuno']['paymentmethod'] ? $data['byjuno']['paymentmethod'] : 'INVOICE'
								),
								array(
									'Name' 	=> 'RISKOWNER',
									'Value' => $data['byjuno']['riskowner']
								),
								array(
									'Name' 	=> 'TRANSACTIONNUMBER',
									'Value' => $data['user']['transactionnumber']
								),
								array(
									'Name' 	=> 'DELIVERY_FIRSTNAME',
									'Value' => htmlspecialchars( $data['user']['shipping_firstname'] )
								),
								array(
									'Name' 	=> 'DELIVERY_LASTNAME',
									'Value' => htmlspecialchars( $data['user']['shipping_lastname'] )
								),
								array(
									'Name' 	=> 'DELIVERY_FIRSTLINE',
									'Value' => htmlspecialchars( rtrim($data['user']['shipping_address'].' '.$data['user']['shipping_houseno'], ' ') )
								),
								array(
									'Name' 	=> 'DELIVERY_COUNTRYCODE',
									'Value' => $data['user']['shipping_country']
								),
								array(
									'Name' 	=> 'DELIVERY_POSTCODE',
									'Value' => $data['user']['shipping_postcode']
								),
								array(
									'Name' 	=> 'DELIVERY_TOWN',
									'Value' => htmlspecialchars( $data['user']['shipping_city'] )
								),
								array(
									'Name' 	=> 'CUSTOMER_CATEGORY',
									'Value' => $data['user']['customercategory']
								),
								array(
									'Name' 	=> 'REPAYMENTTYPE',
									'Value' => $data['byjuno']['repaymenttype']
								),
								array(
									'Name' 	=> 'PAPER_INVOICE',
									'Value' => $data['user']['paper_invoice']
								)
							);

							foreach($extrainfofields as $eiatt => $eivals) {
								$extrainfo = $doc->createElement('ExtraInfo');
								$person->appendChild($extrainfo);
								foreach($eivals as $eivalatt => $eivalval) {
									$extrainfoval = $doc->createElement($eivalatt, $eivalval);
									$extrainfo->appendChild($extrainfoval);
								}
							}

		return $doc->saveXML();

	}

	public function s3_b2b($data) {

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}
			$customer = $doc->createElement('Customer');
			$customeratt = $doc->createAttribute('Reference');
			$customeratt->value = $data['byjuno']['id_prefix'] . $data['byjuno']['ref'];
			$customer->appendChild($customeratt);
			$request->appendChild($customer);
				$company = $doc->createElement('Company');
				$customer->appendChild($company);

					$lang = get_locale();
					$lang = explode('_', $lang);
					$lang = (isset($lang[0]) && $lang[0]) ? strtolower($lang[0]) : 'de';

					$elements = array(
						$doc->createElement( 'CompanyName1', htmlspecialchars( $data['user']['billing_company'] ) ),
						$doc->createElement( 'Language', $lang )
					);
					foreach($elements as $element) {
						$company->appendChild($element);
					}

					$orderingperson = $doc->createElement( 'OrderingPerson' );
					$company->appendChild($orderingperson);
					$person = $doc->createElement( 'Person' );
					$orderingperson->appendChild($person);

					$elements = array(
						$doc->createElement('LastName', htmlspecialchars( $data['user']['billing_lastname'] ) ),
						$doc->createElement('FirstName', htmlspecialchars( $data['user']['billing_firstname'] ) ),
						$doc->createElement('Gender', $data['user']['gender']),
						$doc->createElement('DateOfBirth', $data['user']['birthday'])
					);

					foreach($elements as $element) {
						$person->appendChild($element);
					}

					$address = $doc->createElement('CurrentAddress');
					$company->appendChild($address);
						$elements = array(
							$doc->createElement('FirstLine', htmlspecialchars( $data['user']['billing_address'] ) ),
							$doc->createElement('HouseNumber', (isset($data['user']['billing_houseno']) && $data['user']['billing_houseno']) ? $data['user']['billing_houseno'] : ''),
							$doc->createElement('CountryCode', (isset($data['user']['billing_country']) && $data['user']['billing_country']) ? $data['user']['billing_country'] : 'CH'),
							$doc->createElement('PostCode', $data['user']['billing_postcode']),
							$doc->createElement('Town', htmlspecialchars( $data['user']['billing_city'] ) )
						);
						foreach($elements as $element) {
							$address->appendChild($element);
						}
					$commnumbers= $doc->createElement('CommunicationNumbers');
					$company->appendChild($commnumbers);
						$elements = array(
							$doc->createElement('TelephonePrivate'),
							$doc->createElement('TelephoneOffice'),
							$doc->createElement('Fax'),
							$doc->createElement('Mobile', $data['user']['phone']),
							$doc->createElement('Email', $data['user']['email'])
						);
						foreach($elements as $element) {
							$commnumbers->appendChild($element);
						}

					$extrainfofields = array(
						array(
							'Name' 	=> 'ORDERCLOSED',
							'Value' => 'YES'
						),
						array(
							'Name' 	=> 'ORDERID',
							'Value' => $data['byjuno']['id_prefix'] . $data['user']['orderid']
						),
						array(
							'Name' 	=> 'ORDERAMOUNT',
							'Value' => $data['user']['ordertotal']
						),
						array(
							'Name' 	=> 'ORDERCURRENCY',
							'Value' => $data['user']['currency'] ? $data['user']['currency'] : 'CHF'
						),
						array(
							'Name' 	=> 'IP',
							'Value' => $data['user']['ip'] ? $data['user']['ip'] : $_SERVER['REMOTE_ADDR']
						),
						array(
							'Name' 	=> 'PAYMENTMETHOD',
							'Value' => 'INVOICE'
						),
						array(
							'Name' 	=> 'RISKOWNER',
							'Value' => $data['byjuno']['riskowner']
						),
						array(
							'Name' 	=> 'TRANSACTIONNUMBER',
							'Value' => $data['user']['transactionnumber']
						),
						array(
							'Name' => 'DELIVERY_COMPANYNAME',
							'Value' => htmlspecialchars( $data['user']['billing_company'] )
						),
						array(
							'Name' => 'REGISTERNUMBER',
							'Value' => htmlspecialchars( $data['user']['billing_company_reg'] )
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_firstname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_LASTNAME',
							'Value' => htmlspecialchars( $data['user']['shipping_lastname'] )
						),
						array(
							'Name' 	=> 'DELIVERY_FIRSTLINE',
							'Value' => htmlspecialchars( rtrim($data['user']['shipping_address'].' '.$data['user']['shipping_houseno'], ' ') )
						),
						array(
							'Name' 	=> 'DELIVERY_COUNTRYCODE',
							'Value' => $data['user']['shipping_country']
						),
						array(
							'Name' 	=> 'DELIVERY_POSTCODE',
							'Value' => $data['user']['shipping_postcode']
						),
						array(
							'Name' 	=> 'DELIVERY_TOWN',
							'Value' => htmlspecialchars( $data['user']['shipping_city'] )
						),
						array(
							'Name' 	=> 'CUSTOMER_CATEGORY',
							'Value' => $data['user']['customercategory']
						),
						array(
							'Name' 	=> 'REPAYMENTTYPE',
							'Value' => $data['byjuno']['repaymenttype']
						),
						array(
							'Name' 	=> 'PAPER_INVOICE',
							'Value' => $data['user']['paper_invoice']
						)
					);

					foreach($extrainfofields as $eiatt => $eivals) {
						$extrainfo = $doc->createElement('ExtraInfo');
						$company->appendChild($extrainfo);
						foreach($eivals as $eivalatt => $eivalval) {
							$extrainfoval = $doc->createElement($eivalatt, $eivalval);
							$extrainfo->appendChild($extrainfoval);
						}
					}
		return $doc->saveXML();

	}

	function s4($data) {

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}
			$transaction = $doc->createElement('Transaction');
			$request->appendChild($transaction);
				$elements = array(
					$doc->createElement('OrderId', $data['byjuno']['id_prefix'] . $data['order']['id']),
					$doc->createElement('ClientRef', $data['byjuno']['id_prefix'] . $data['byjuno']['ref']),
					$doc->createElement('TransactionType', 'CHARGE'),
					$doc->createElement('TransactionDate', $data['order']['date']),
					$doc->createElement('TransactionAmount', $data['order']['total']),
					$doc->createElement('TransactionCurrency', $data['order']['currency']),
					$doc->createElement('Additional1', 'INVOICE'),
					$doc->createElement('Additional2', $data['order']['id']),
					$doc->createElement('OpenBalance', $data['order']['total']),
					$doc->createElement('PartialDelivery', 'N'),
				);
				foreach($elements as $element) {
					$transaction->appendChild($element);
				}

		return $doc->saveXML();

	}

	// function s5($data, $type=NULL) {
	//
	// 	global $woocommerce, $wpdb;
	//
	// 	$openbalance = $data['order']['total'];
	//
	// 	switch($type) {
	//
	// 		case 'partial':
	// 			$initialtotal = $data['order']['initialtotal'];
	// 			$difference = abs( floatval( $initialtotal ) - floatval( $openbalance ) );
	// 			$partial = 'Y';
	// 		break;
	//
	// 		case 'total':
	// 			$difference = $openbalance;
	// 			$openbalance = 0;
	// 			$partial = 'N';
	// 		break;
	//
	// 	}
	//
	// 	$doc = new DOMDocument('1.0', 'UTF-8');
	// 	$doc->preserveWhiteSpace = false;
	// 	$doc->formatOutput = true;
	// 	$request = $doc->createElement('Request');
	// 	$requestatts = array(
	// 		'ClientId'  => $data['byjuno']['clientid'],
	// 		'Email' 	=> $data['byjuno']['email'],
	// 		'Password'  => $data['byjuno']['pass'],
	// 		'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
	// 		'UserID'	=> $data['byjuno']['user'],
	// 		'Version'	=> '1.42',
	// 		'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
	// 		'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
	// 	);
	// 	foreach($requestatts as $requestatt => $requestval) {
	// 		$requestatt = $doc->createAttribute($requestatt);
	// 		$requestatt->value = $requestval;
	// 		$request->appendChild($requestatt);
	// 		$doc->appendChild($request);
	// 	}
	//
	// 		$transaction = $doc->createElement('Transaction');
	// 		$request->appendChild($transaction);
	// 			$elements = array(
	// 				$doc->createElement('OrderId', $data['byjuno']['id_prefix'] . $data['order']['id']),
	// 				$doc->createElement('ClientRef', $data['byjuno']['id_prefix'] . $data['byjuno']['ref']),
	// 				$doc->createElement('TransactionType', 'CANCEL'),
	// 				$doc->createElement('TransactionDate', date('Y-m-d')),
	// 				$doc->createElement('TransactionAmount', $difference),
	// 				$doc->createElement('TransactionCurrency', $data['order']['currency']),
	// 				$doc->createElement('Additional1', 'INVOICE'),
	// 				$doc->createElement('Additional2', $data['order']['id']),
	// 				$doc->createElement('OpenBalance', $openbalance),
	// 				$doc->createElement('PartialDelivery', $partial),
	// 			);
	// 			foreach($elements as $element) {
	// 				$transaction->appendChild($element);
	// 			}
	//
	// 	return $doc->saveXML();
	//
	// }

	function s5($data, $type=NULL) {

		global $woocommerce, $wpdb;

		$openbalance = $data['order']['total'];

		switch($type) {

			case 'partial':
				$initialtotal = $data['order']['initialtotal'];
				$difference = abs( floatval( $initialtotal ) - floatval( $openbalance ) );
				$partial = 'Y';
			break;

			case 'refund':
				$difference = $data['order']['refund'];
				$partial = 'Y';
			break;

			case 'total':
				$difference = $openbalance;
				$openbalance = 0;
				$partial = 'N';
			break;

		}

		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->preserveWhiteSpace = false;
		$doc->formatOutput = true;
		$request = $doc->createElement('Request');
		$requestatts = array(
			'ClientId'  => $data['byjuno']['clientid'],
			'Email' 	=> $data['byjuno']['email'],
			'Password'  => $data['byjuno']['pass'],
			'RequestId' => $data['byjuno']['id_prefix'] . $data['byjuno']['request'],
			'UserID'	=> $data['byjuno']['user'],
			'Version'	=> '1.42',
			'noNamespaceSchemaLocation' => 'http://site.intrum.ch/schema/CreditDecisionRequest140.xsd',
			'xsi'		=> 'http://www.w3.org/2001/XMLSchema-instance'
		);
		foreach($requestatts as $requestatt => $requestval) {
			$requestatt = $doc->createAttribute($requestatt);
			$requestatt->value = $requestval;
			$request->appendChild($requestatt);
			$doc->appendChild($request);
		}

			$transaction = $doc->createElement('Transaction');
			$request->appendChild($transaction);
				$elements = array(
					$doc->createElement('OrderId', $data['byjuno']['id_prefix'] . $data['order']['id']),
					$doc->createElement('ClientRef', $data['byjuno']['id_prefix'] . $data['byjuno']['ref']),
					$doc->createElement('TransactionType', 'CANCEL'),
					$doc->createElement('TransactionDate', date('Y-m-d')),
					$doc->createElement('TransactionAmount', $difference),
					$doc->createElement('TransactionCurrency', $data['order']['currency']),
					$doc->createElement('Additional1', 'INVOICE'),
					$doc->createElement('Additional2', $data['order']['id']),
					$doc->createElement('OpenBalance', $openbalance),
					$doc->createElement('PartialDelivery', $partial),
				);
				foreach($elements as $element) {
					$transaction->appendChild($element);
				}

		return $doc->saveXML();

	}

	public function byjuno_test_form() {
		$fields = array(
			'byjuno-test-first-name' => array(
				'type' 	=> 'text',
				'label' => 'First Name*'
			),
			'byjuno-test-last-name' => array(
				'type' 	=> 'text',
				'label' => 'Last Name*'
			),
			'byjuno-test-street' => array(
				'type' 	=> 'text',
				'label' => 'Street*'
			),
			'byjuno-test-street-number' => array(
				'type' 	=> 'text',
				'label' => 'House Number*'
			),
			'byjuno-test-postcode' => array(
				'type' 	=> 'text',
				'label' => 'Postcode*'
			),
			'byjuno-test-city' => array(
				'type' 	=> 'text',
				'label' => 'City*'
			),
			'byjuno-test-region' => array(
				'type' 	=> 'text',
				'label' => 'Region/County/Province/Canton'
			),
			'byjuno-test-country' => array(
				'type' 	  => 'text',
				'label'   => 'Country*',
				'default' => 'CH'
			),
			'byjuno-test-gender' => array(
				'type' 		=> 'select',
				'options' 	=> array(
					'2' => 'Female',
					'1' => 'Male'
				)
			),
			'byjuno-test-birthdate' => array(
				'type' 	  => 'text',
				'label'   => 'Birthdate',
				'default' => '01.01.1970'
			),
		);

		ob_start();

?>
		<div class="byjuno-test-container">
			<?php foreach($fields as $id => $field) { ?>
			<div class="byjuno-test-column byjuno-test-half">
				<?php
				switch($field['type']) {
					case 'text':
				?>
				<input type="text" id="<?php echo $id; ?>" placeholder="<?php echo $field['label']; ?>" value="<?php echo isset($field['default']) && $field['default'] ? $field['default'] : ''; ?>" />
				<?php
					break;
					case 'select':
				?>
				<select id="<?php echo $id; ?>">
					<?php foreach($field['options'] as $value => $label) { ?>
					<option value="<?php echo $value; ?>"><?php echo $label; ?></option>
					<?php } ?>
				</select>
				<?php
					break;
				}
				?>
			</div>
			<?php } ?>
			<div class="byjuno-test-column byjuno-test-full" style="text-align:center;">
				<button id="byjuno-test-perform" class="button button-primary">Submit</button>
			</div>
			<div class="clear"></div>
			<div class="byjuno-test-column byjuno-test-full" style="text-align:center;">
				<div id="byjuno-test-preloader"><div class="byjuno-preloader"></div></div>
				<div id="byjuno-test-response"></div>
			</div>
			<div class="clear"></div>
		</div>
<?php

		return ob_get_clean();

	}

}

?>
