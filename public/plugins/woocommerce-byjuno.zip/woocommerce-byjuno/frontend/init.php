<?php
/**
* @package WooCommerce Byjuno
* @author  Adrian Emil Tudorache
* @license GPL-2.0+
* @link    https://www.tudorache.me/
**/

if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

$files = array(
    'views/byjuno.views.class.php',
    'controllers/byjuno-main.class.php',
    'controllers/byjuno-config.class.php',
    'controllers/byjuno-requests.class.php',
    'controllers/byjuno-wc-gateway.class.php',
    'controllers/byjuno-custom-address-fields.class.php'
);
foreach( $files as $file ) {
    require_once( $file );
}
?>
